```python
from django.urls import include, path, re_path
from transit_odp.users.views.invitations import AcceptInvite

# Define the app name for the invitations feature
app_name = "invitations"

# URL patterns for the invitations app
urlpatterns = [
    # URL pattern to override the default invitation acceptance route
    re_path(
        # Regular expression for accept-invite URL with a unique key
        r"^accept-invite/(?P<key>\w+)/?$",
        # The view class handling the invitation acceptance
        AcceptInvite.as_view(),
        # URL name for reverse URL matching
        name="accept-invite"
    ),
    # Include the default django-invitations app URL patterns
    path("", include("invitations.urls")),
]
```

from django.urls import include, path, re_path

from transit_odp.users.views.invitations import AcceptInvite

app_name = "invitations"

# django-invitations routes
urlpatterns = [
    # Override invitation routes
    re_path(
        r"^accept-invite/(?P<key>\w+)/?$", AcceptInvite.as_view(), name="accept-invite"
    ),
    path("", include("invitations.urls")),
]
