```python
from django.urls import include, path, re_path

from transit_odp.users.views.account import (
    EmailView,
    PasswordChangeDoneView,
    PasswordChangeView,
)
from transit_odp.users.views.auth import (
    ConfirmEmailView,
    EmailVerificationSentView,
    LoginView,
    LogoutSuccessView,
    PasswordResetDoneView,
    PasswordResetFromKeyView,
    PasswordResetView,
    SignupView,
)

# URL configuration for user-related paths in a Django project.
# This includes paths for account management and authentication.
urlpatterns = [
    # Custom views
    
    # Path for logout success page.
    path(
        "logout-success/",
        view=LogoutSuccessView.as_view(),
        name="account_logout_success",
    ),
    
    # Override specific AllAuth views
    
    # Path for the login page.
    path("login/", view=LoginView.as_view(), name="account_login"),
    
    # Path for the signup page.
    path("signup/", view=SignupView.as_view(), name="account_signup"),
    
    # Path for changing the password.
    path(
        "password/change/",
        view=PasswordChangeView.as_view(),
        name="account_change_password",
    ),
    
    # Path for the password change done page.
    path(
        "password/change/done/",
        view=PasswordChangeDoneView.as_view(),
        name="account_change_password_done",
    ),
    
    # email
    
    # Path for the email management page.
    path("email/", view=EmailView.as_view(), name="account_email"),
    
    # Path for the email verification sent page.
    path(
        "confirm-email/",
        EmailVerificationSentView.as_view(),
        name="account_email_verification_sent",
    ),
    
    # Path for confirming the email with a key.
    path(
        "confirm-email/<str:key>/",
        ConfirmEmailView.as_view(),
        name="account_confirm_email",
    ),
    
    # password reset
    
    # Path for initiating a password reset.
    re_path(
        r"^password/reset/$", PasswordResetView.as_view(), name="account_reset_password"
    ),
    
    # Path for the password reset done page.
    re_path(
        r"^password/reset/done/$",
        PasswordResetDoneView.as_view(),
        name="account_reset_password_done",
    ),
    
    # Path for resetting the password using a key.
    re_path(
        r"^password/reset/key/(?P<uidb36>[0-9A-Za-z]+)-(?P<key>.+)/$",
        PasswordResetFromKeyView.as_view(),
        name="account_reset_password_from_key",
    ),
    
    # Include AllAuth views
    path("", include("allauth.urls")),
]
```

from django.urls import include, path, re_path

from transit_odp.users.views.account import (
    EmailView,
    PasswordChangeDoneView,
    PasswordChangeView,
)
from transit_odp.users.views.auth import (
    ConfirmEmailView,
    EmailVerificationSentView,
    LoginView,
    LogoutSuccessView,
    PasswordResetDoneView,
    PasswordResetFromKeyView,
    PasswordResetView,
    SignupView,
)

urlpatterns = [
    # Custom views
    path(
        "logout-success/",
        view=LogoutSuccessView.as_view(),
        name="account_logout_success",
    ),
    # Override specific AllAuth views
    path("login/", view=LoginView.as_view(), name="account_login"),
    path("signup/", view=SignupView.as_view(), name="account_signup"),
    path(
        "password/change/",
        view=PasswordChangeView.as_view(),
        name="account_change_password",
    ),
    path(
        "password/change/done/",
        view=PasswordChangeDoneView.as_view(),
        name="account_change_password_done",
    ),
    # email
    path("email/", view=EmailView.as_view(), name="account_email"),
    path(
        "confirm-email/",
        EmailVerificationSentView.as_view(),
        name="account_email_verification_sent",
    ),
    path(
        "confirm-email/<str:key>/",
        ConfirmEmailView.as_view(),
        name="account_confirm_email",
    ),
    # password reset
    re_path(
        r"^password/reset/$", PasswordResetView.as_view(), name="account_reset_password"
    ),
    re_path(
        r"^password/reset/done/$",
        PasswordResetDoneView.as_view(),
        name="account_reset_password_done",
    ),
    re_path(
        r"^password/reset/key/(?P<uidb36>[0-9A-Za-z]+)-(?P<key>.+)/$",
        PasswordResetFromKeyView.as_view(),
        name="account_reset_password_from_key",
    ),
    # Include AllAuth views
    path("", include("allauth.urls")),
]
