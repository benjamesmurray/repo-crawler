```python
from django.apps import AppConfig

class FrontendConfig(AppConfig):
    """
    Configuration class for the 'frontend' Django app.

    This class sets up the application name and its human-readable verbose name.
    It inherits from Django's AppConfig class.

    Attributes:
        name (str): The name of the application.
        verbose_name (str): A human-readable name for the application.
    """
    name = "transit_odp.frontend"
    verbose_name = "Frontend"
```

from django.apps import AppConfig


class FrontendConfig(AppConfig):
    name = "transit_odp.frontend"
    verbose_name = "Frontend"
