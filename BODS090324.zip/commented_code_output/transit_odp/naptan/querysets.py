```python
from django.db import models
from django.db.models import Count, F

class AdminAreaQuerySet(models.QuerySet):
    """
    A custom queryset for performing queries related to the AdminArea model.
    """

    def get_active_org(self):
        """
        Filters the queryset to exclude any admin areas where the related organisation is not active.

        :return: QuerySet of admin areas linked to active organisations.
        """
        return self.exclude(revisions__dataset__organisation__is_active=False)

    def has_published_datasets(self):
        """
        Filters the queryset to include only admin areas that have at least one published dataset.

        :return: QuerySet of admin areas with published datasets.
        """
        return self.add_published_dataset_count().filter(published_dataset_count__gt=0)

    def add_dataset_count(self):
        """
        Annotates the queryset with the total number of unique datasets which index
        the admin area.

        Note this includes datasets where the admin area is found in previous revisions
        as well as draft revisions.

        :return: QuerySet with an added annotation for dataset count.
        """
        return self.annotate(dataset_count=Count("revisions__dataset", distinct=True))

    def add_published_dataset_count(self):
        """
        Annotates the queryset with the total number of unique datasets which index the
        admin area.

        Note this only looks at the latest, published revision of the dataset.

        :return: QuerySet with an added annotation for published dataset count.
        """
        return self.annotate(
            published_dataset_count=Count("revisions__live_revision_dataset")
        )

class StopPointQuerySet(models.QuerySet):
    """
    A custom queryset for performing queries related to the StopPoint model.
    """

    def add_district_name(self):
        """
        Annotates the queryset with the name of the district associated with each stop point.

        :return: QuerySet with an added annotation for district name.
        """
        return self.annotate(district_name=F("locality__district__name"))

class LocalityQuerySet(models.QuerySet):
    """
    A custom queryset for performing queries related to the Locality model.
    """

    def add_district_name(self):
        """
        Annotates the queryset with the name of the district associated with each locality.

        :return: QuerySet with an added annotation for district name.
        """
        return self.annotate(district_name=F("district__name"))

class FlexibleZoneQuerySet(models.QuerySet):
    """
    A custom queryset for performing queries related to the FlexibleZone model.
    """
    pass
```

from django.db import models
from django.db.models import Count, F


class AdminAreaQuerySet(models.QuerySet):
    def get_active_org(self):
        return self.exclude(revisions__dataset__organisation__is_active=False)

    def has_published_datasets(self):
        return self.add_published_dataset_count().filter(published_dataset_count__gt=0)

    def add_dataset_count(self):
        """Annotate queryset with the total number of unique datasets which index
        the admin area.

        Note this includes datasets where the admin area is found in previous revisions
        as well as draft revisions.
        """
        return self.annotate(dataset_count=Count("revisions__dataset", distinct=True))

    def add_published_dataset_count(self):
        """Annotate queryset with the total number of unique datasets which index the
        admin area.

        Note this only looks at the latest, published revision of the dataset.
        """
        return self.annotate(
            published_dataset_count=Count("revisions__live_revision_dataset")
        )


class StopPointQuerySet(models.QuerySet):
    def add_district_name(self):
        return self.annotate(district_name=F("locality__district__name"))


class LocalityQuerySet(models.QuerySet):
    def add_district_name(self):
        return self.annotate(district_name=F("district__name"))


class FlexibleZoneQuerySet(models.QuerySet):
    pass
