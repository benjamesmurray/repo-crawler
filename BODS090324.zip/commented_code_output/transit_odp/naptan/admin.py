```python
from django.contrib import admin
from transit_odp.naptan.models import AdminArea, Locality, StopPoint

@admin.register(Locality)
class LocalityAdmin(admin.ModelAdmin):
    """
    Django admin model for Locality.
    
    Customizes the admin interface for Locality objects, including the display
    of list, search fields, and disabling the add, delete, and change permissions.
    """
    list_per_page = 30
    search_fields = ["gazetteer_id", "name"]
    list_display = ("gazetteer_id", "name", "easting", "northing")
    list_display_links = ("gazetteer_id", "name")

    def has_delete_permission(self, request, instance=None):
        """Disallow deletion of Locality objects."""
        return False

    def has_add_permission(self, request, instance=None):
        """Disallow addition of new Locality objects."""
        return False

    def has_change_permission(self, request, instance=None):
        """Disallow changes to Locality objects."""
        return False

@admin.register(AdminArea)
class AdminAreaAdmin(admin.ModelAdmin):
    """
    Django admin model for AdminArea.
    
    Customizes the admin interface for AdminArea objects, including the display
    of list, search fields, and disabling the add and delete permissions.
    Change permission is allowed.
    """
    list_per_page = 30
    search_fields = ["atco_code"]
    list_display = ("id", "name", "traveline_region_id", "atco_code", "ui_lta")
    list_display_links = ("id", "name")
    readonly_fields = ("name", "traveline_region_id", "atco_code")

    def has_delete_permission(self, request, instance=None):
        """Disallow deletion of AdminArea objects."""
        return False

    def has_add_permission(self, request, instance=None):
        """Disallow addition of new AdminArea objects."""
        return False

    def has_change_permission(self, request, instance=None):
        """Allow changes to AdminArea objects."""
        return True

@admin.register(StopPoint)
class StopPointAdmin(admin.ModelAdmin):
    """
    Django admin model for StopPoint.
    
    Customizes the admin interface for StopPoint objects, including the display
    of list, search fields, and disabling the add, delete, and change permissions.
    It also provides custom methods to display related fields.
    """
    list_per_page = 30
    search_fields = ["atco_code"]
    list_display = (
        "atco_code",
        "naptan_code",
        "common_name",
        "street",
        "indicator",
        "latitude",
        "longitude",
        "locality_name",
        "admin_area_name",
        "stop_areas",
    )
    exclude = ("locality", "admin_area", "location")
    readonly_fields = (
        "atco_code",
        "naptan_code",
        "common_name",
        "street",
        "indicator",
        "latitude",
        "longitude",
        "locality_name",
        "admin_area_name",
        "stop_areas",
    )

    def get_queryset(self, request):
        """Optimize queryset with select_related for related objects."""
        return super().get_queryset(request).select_related("admin_area", "locality")

    def locality_name(self, instance):
        """Return the name of the locality related to the StopPoint."""
        if instance.locality is None:
            return None
        return instance.locality.name

    def admin_area_name(self, instance):
        """Return the name of the admin area related to the StopPoint."""
        if instance.admin_area is None:
            return None
        return instance.admin_area.name

    def latitude(self, instance):
        """Return the latitude from the StopPoint's location."""
        return instance.location[-1]

    def longitude(self, instance):
        """Return the longitude from the StopPoint's location."""
        return instance.location[0]

    def has_delete_permission(self, request, instance=None):
        """Disallow deletion of StopPoint objects."""
        return False

    def has_add_permission(self, request, instance=None):
        """Disallow addition of new StopPoint objects."""
        return False

    def has_change_permission(self, request, instance=None):
        """Disallow changes to StopPoint objects."""
        return False
```

from django.contrib import admin

from transit_odp.naptan.models import AdminArea, Locality, StopPoint


@admin.register(Locality)
class LocalityAdmin(admin.ModelAdmin):
    list_per_page = 30
    search_fields = ["gazetteer_id", "name"]
    list_display = ("gazetteer_id", "name", "easting", "northing")
    list_display_links = ("gazetteer_id", "name")

    def has_delete_permission(self, request, instance=None):
        return False

    def has_add_permission(self, request, instance=None):
        return False

    def has_change_permission(self, request, instance=None):
        return False


@admin.register(AdminArea)
class AdminAreaAdmin(admin.ModelAdmin):
    list_per_page = 30
    search_fields = ["atco_code"]
    list_display = ("id", "name", "traveline_region_id", "atco_code", "ui_lta")
    list_display_links = ("id", "name")
    readonly_fields = ("name", "traveline_region_id", "atco_code")

    def has_delete_permission(self, request, instance=None):
        return False

    def has_add_permission(self, request, instance=None):
        return False

    def has_change_permission(self, request, instance=None):
        return True


@admin.register(StopPoint)
class StopPointAdmin(admin.ModelAdmin):
    list_per_page = 30
    search_fields = ["atco_code"]
    list_display = (
        "atco_code",
        "naptan_code",
        "common_name",
        "street",
        "indicator",
        "latitude",
        "longitude",
        "locality_name",
        "admin_area_name",
        "stop_areas",
    )
    exclude = ("locality", "admin_area", "location")
    readonly_fields = (
        "atco_code",
        "naptan_code",
        "common_name",
        "street",
        "indicator",
        "latitude",
        "longitude",
        "locality_name",
        "admin_area_name",
        "stop_areas",
    )

    def get_queryset(self, request):
        return super().get_queryset(request).select_related("admin_area", "locality")

    def locality_name(self, instance):
        if instance.locality is None:
            return None
        return instance.locality.name

    def admin_area_name(self, instance):
        if instance.admin_area is None:
            return None
        return instance.admin_area.name

    def latitude(self, instance):
        return instance.location[-1]

    def longitude(self, instance):
        return instance.location[0]

    def has_delete_permission(self, request, instance=None):
        return False

    def has_add_permission(self, request, instance=None):
        return False

    def has_change_permission(self, request, instance=None):
        return False
