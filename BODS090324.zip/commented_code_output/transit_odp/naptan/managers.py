```python
from django.db import models

from transit_odp.naptan.querysets import (
    AdminAreaQuerySet,
    LocalityQuerySet,
    StopPointQuerySet,
    FlexibleZoneQuerySet,
)

class AdminAreaManager(models.Manager.from_queryset(AdminAreaQuerySet)):
    """
    A custom manager for AdminArea models that extends from the base Manager class
    and uses AdminAreaQuerySet for queryset methods.
    """
    pass


class StopPointManager(models.Manager.from_queryset(StopPointQuerySet)):
    """
    A custom manager for StopPoint models that extends from the base Manager class
    and uses StopPointQuerySet for queryset methods.
    """
    pass


class LocalityManager(models.Manager.from_queryset(LocalityQuerySet)):
    """
    A custom manager for Locality models that extends from the base Manager class
    and uses LocalityQuerySet for queryset methods.
    """
    pass


class FlexibleZoneManager(models.Manager.from_queryset(FlexibleZoneQuerySet)):
    """
    A custom manager for FlexibleZone models that extends from the base Manager class
    and uses FlexibleZoneQuerySet for queryset methods.
    """
    pass
```

from django.db import models

from transit_odp.naptan.querysets import (
    AdminAreaQuerySet,
    LocalityQuerySet,
    StopPointQuerySet,
    FlexibleZoneQuerySet,
)


class AdminAreaManager(models.Manager.from_queryset(AdminAreaQuerySet)):
    pass


class StopPointManager(models.Manager.from_queryset(StopPointQuerySet)):
    pass


class LocalityManager(models.Manager.from_queryset(LocalityQuerySet)):
    pass


class FlexibleZoneManager(models.Manager.from_queryset(FlexibleZoneQuerySet)):
    pass
