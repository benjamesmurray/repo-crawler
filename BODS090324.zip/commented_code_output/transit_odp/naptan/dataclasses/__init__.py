```python
from .naptan import StopPoint
from .nptg import NationalPublicTransportGazetteer, NptgLocality, Region

# A list of publicly accessible objects of that module, as interpreted by import *.
__all__ = [
    "NationalPublicTransportGazetteer",
    "NptgLocality",
    "Region",
    "StopPoint",
]
```

from .naptan import StopPoint
from .nptg import NationalPublicTransportGazetteer, NptgLocality, Region

__all__ = [
    "NationalPublicTransportGazetteer",
    "NptgLocality",
    "Region",
    "StopPoint",
]
