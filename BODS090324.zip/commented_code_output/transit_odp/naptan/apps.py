```python
from __future__ import unicode_literals

from django.apps import AppConfig

class NaptanConfig(AppConfig):
    """
    Configuration class for the NaPTAN app within the Django project.

    This class inherits from Django's AppConfig and sets the name attribute
    to the application's dotted Python path, which Django uses to locate the
    application's code.

    Attributes:
        name (str): The full Python path to the application.
    """
    name = "transit_odp.naptan"
```

from __future__ import unicode_literals

from django.apps import AppConfig


class NaptanConfig(AppConfig):
    name = "transit_odp.naptan"
