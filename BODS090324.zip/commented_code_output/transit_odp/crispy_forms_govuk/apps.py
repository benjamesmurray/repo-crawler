```python
from django.apps import AppConfig

class CrispyFormsGovukConfig(AppConfig):
    """
    Configuration class for the 'Crispy Forms Govuk' Django app.

    This class sets up the Django app with the appropriate name and verbose name,
    which can be used for admin and debugging purposes.

    Attributes:
        name (str): The full Python path to the application.
        verbose_name (str): A human-readable name for the application.
    """
    name = "transit_odp.crispy_forms_govuk"
    verbose_name = "Crispy Forms Govuk"
```

from django.apps import AppConfig


class CrispyFormsGovukConfig(AppConfig):
    name = "transit_odp.crispy_forms_govuk"
    verbose_name = "Crispy Forms Govuk"
