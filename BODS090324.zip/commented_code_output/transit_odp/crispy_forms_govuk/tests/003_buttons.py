```python
import os

from crispy_forms.layout import ButtonHolder, Layout
from crispy_forms_govuk.layout import ButtonElement, ButtonSubmit, LinkButton
from tests.forms import BasicForm, EmptyForm
from tests.utils import write_output  # noqa: F401

def test_buttonelement(output_test_path, render_output, rendered_template, helper, client):
    """
    Test the rendering of a ButtonElement within a form layout.
    
    :param output_test_path: The path where the test output HTML should be written.
    :param render_output: A function to render the expected output.
    :param rendered_template: A function to render the actual template.
    :param helper: The form helper instance used to manage form rendering.
    :param client: The test client instance.
    :return: None, but asserts that the expected HTML matches the actual rendered HTML.
    """
    # Setup
    form = BasicForm()
    helper.layout = Layout("event", ButtonElement("copy", "copy", content="Copy"))

    expected = render_output(os.path.join(output_test_path, "test_buttonelement.html"))

    # Test
    actual = rendered_template(form, helper=helper)
    # write_output(output_test_path, "test_buttongroup_act.html", actual)
    # write_output(output_test_path, "test_buttongroup_out.html", expected)

    # Assert
    assert expected == actual

def test_buttonsubmit(output_test_path, render_output, rendered_template, helper, client):
    """
    Test the rendering of a ButtonSubmit within a form layout.
    
    :param output_test_path: The path where the test output HTML should be written.
    :param render_output: A function to render the expected output.
    :param rendered_template: A function to render the actual template.
    :param helper: The form helper instance used to manage form rendering.
    :param client: The test client instance.
    :return: None, but asserts that the expected HTML matches the actual rendered HTML.
    """
    # Setup
    form = BasicForm()
    helper.layout = Layout(
        "event", ButtonSubmit("save", "save", content="Save and continue")
    )

    expected = render_output(os.path.join(output_test_path, "test_buttonsubmit.html"))

    # Test
    actual = rendered_template(form, helper=helper)

    # Assert
    assert expected == actual

def test_cancellinkbutton(output_test_path, render_output, rendered_template, helper, client):
    """
    Test the rendering of a LinkButton used as a cancel button within a form layout.
    
    :param output_test_path: The path where the test output HTML should be written.
    :param render_output: A function to render the expected output.
    :param rendered_template: A function to render the actual template.
    :param helper: The form helper instance used to manage form rendering.
    :param client: The test client instance.
    :return: None, but asserts that the expected HTML matches the actual rendered HTML.
    """
    # Setup
    form = EmptyForm()
    helper.layout = Layout(
        ButtonHolder(
            ButtonSubmit("submit", "submit", content="Confirm"),
            LinkButton(url="/"),
        )
    )

    expected = render_output(
        os.path.join(output_test_path, "test_cancellinkbutton.html")
    )

    # Test
    actual = rendered_template(form, helper=helper)

    # Assert
    assert expected == actual
```

import os

from crispy_forms.layout import ButtonHolder, Layout
from crispy_forms_govuk.layout import ButtonElement, ButtonSubmit, LinkButton
from tests.forms import BasicForm, EmptyForm
from tests.utils import write_output  # noqa: F401


def test_buttonelement(
    output_test_path, render_output, rendered_template, helper, client
):
    # Setup
    form = BasicForm()
    helper.layout = Layout("event", ButtonElement("copy", "copy", content="Copy"))

    expected = render_output(os.path.join(output_test_path, "test_buttonelement.html"))

    # Test
    actual = rendered_template(form, helper=helper)
    # write_output(output_test_path, "test_buttongroup_act.html", actual)
    # write_output(output_test_path, "test_buttongroup_out.html", expected)

    # Assert
    assert expected == actual


def test_buttonsubmit(
    output_test_path, render_output, rendered_template, helper, client
):
    # Setup
    form = BasicForm()
    helper.layout = Layout(
        "event", ButtonSubmit("save", "save", content="Save and continue")
    )

    expected = render_output(os.path.join(output_test_path, "test_buttonsubmit.html"))

    # Test
    actual = rendered_template(form, helper=helper)

    # Assert
    assert expected == actual


def test_cancellinkbutton(
    output_test_path, render_output, rendered_template, helper, client
):
    # Setup
    form = EmptyForm()
    helper.layout = Layout(
        ButtonHolder(
            ButtonSubmit("submit", "submit", content="Confirm"),
            LinkButton(url="/"),
        )
    )

    expected = render_output(
        os.path.join(output_test_path, "test_cancellinkbutton.html")
    )

    # Test
    actual = rendered_template(form, helper=helper)

    # Assert
    assert expected == actual
