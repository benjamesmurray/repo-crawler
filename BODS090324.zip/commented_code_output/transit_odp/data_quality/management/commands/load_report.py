```python
import argparse

from django.core.files import File
from django.core.management.base import BaseCommand

from transit_odp.data_quality.models import DataQualityReport
from transit_odp.data_quality.tasks import run_dqs_report_etl_pipeline
from transit_odp.organisation.models import DatasetRevision


class Command(BaseCommand):
    """
    Custom management command to load a data quality report for a specified
    DatasetRevision.

    This command allows for updating or creating a DataQualityReport instance
    associated with a DatasetRevision and triggers an ETL pipeline to process
    the report data.
    """
    help = "Loads the report"

    def add_arguments(self, parser):
        """
        Adds command-line arguments to the management command.

        :param parser: The argument parser instance to which the arguments should be added.
        """
        parser.add_argument(
            "revision_id",
            type=int,
            help="The id of the DatasetRevision to attach the report",
            choices=list(DatasetRevision.objects.values_list("id", flat=True)),
        )
        parser.add_argument(
            "report",
            type=argparse.FileType("r"),
            help="The JSON report file to be processed",
        )

    def handle(self, *args, **options):
        """
        The actual logic of the command.

        Retrieves the specified DatasetRevision, updates or creates the associated
        DataQualityReport, and initiates the ETL pipeline for the report.

        :param args: Variable length argument list.
        :param options: Arbitrary keyword arguments containing all the command-line
                        arguments.
        """
        revision_id = options["revision_id"]
        report_file = options["report"]

        revision = DatasetRevision.objects.get(id=revision_id)

        report, created = DataQualityReport.objects.update_or_create(
            revision=revision, defaults={"file": File(report_file)}
        )

        # Output the result of the report creation or update to the console
        self.stdout.write(
            self.style.SUCCESS(
                f'{"Created" if created else "Updated"} report: {report}'
            )
        )

        # Inform the user that the ETL task is being run
        self.stdout.write(self.style.SUCCESS("Running ETL task"))
        # Trigger the ETL pipeline for processing the report data
        run_dqs_report_etl_pipeline(report.id)
```

import argparse

from django.core.files import File
from django.core.management.base import BaseCommand

from transit_odp.data_quality.models import DataQualityReport
from transit_odp.data_quality.tasks import run_dqs_report_etl_pipeline
from transit_odp.organisation.models import DatasetRevision


class Command(BaseCommand):
    help = "Loads the report"

    def add_arguments(self, parser):
        parser.add_argument(
            "revision_id",
            type=int,
            help="The id of the DatasetRevision to attach the report",
            choices=list(DatasetRevision.objects.values_list("id", flat=True)),
        )
        parser.add_argument(
            "report",
            type=argparse.FileType("r"),
            help="The JSON report",
        )

    def handle(self, *args, **options):
        revision_id = options["revision_id"]
        report_file = options["report"]

        revision = DatasetRevision.objects.get(id=revision_id)

        report, created = DataQualityReport.objects.update_or_create(
            revision=revision, defaults={"file": File(report_file)}
        )

        self.stdout.write(
            self.style.SUCCESS(
                f'{"Created" if created else "Updated"} report: {report}'
            )
        )

        self.stdout.write(self.style.SUCCESS("Running ETL task"))
        run_dqs_report_etl_pipeline(report.id)
