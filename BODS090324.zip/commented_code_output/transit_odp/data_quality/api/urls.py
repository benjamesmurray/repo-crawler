```python
from django.urls import include, path
from rest_framework.routers import DefaultRouter

# Importing the views from the data_quality application's API
from transit_odp.data_quality.api import views

# Define the app namespace
app_name = "dq-api"

# Initialize a default router for registering the viewsets
router = DefaultRouter()

# Register the ServiceLinkViewSet with the router
router.register(r"service_link", views.ServiceLinkViewSet, "service_link")

# Register the ServicePatternViewSet with the router
router.register(r"service_pattern", views.ServicePatternViewSet, "service_pattern")

# Register the StopPointViewSet with the router
router.register(r"stop_point", views.StopPointViewSet, "stop_point")

# Define the URL patterns for the data quality API using the registered routers
urlpatterns = [
    # Including all URLs from the router in the application's URL patterns
    path("", include(router.urls)),
]
```

from django.urls import include, path
from rest_framework.routers import DefaultRouter

from transit_odp.data_quality.api import views

app_name = "dq-api"

router = DefaultRouter()
router.register(r"service_link", views.ServiceLinkViewSet, "service_link")
router.register(r"service_pattern", views.ServicePatternViewSet, "service_pattern")
router.register(r"stop_point", views.StopPointViewSet, "stop_point")

urlpatterns = [
    path("", include(router.urls)),
]
