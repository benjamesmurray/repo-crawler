```python
from transit_odp.data_quality.tables.base import (
    StopNameTimingPatternTable,
    VehicleJourneyTable,
)

class TimingLastWarningDetailTable(StopNameTimingPatternTable):
    """
    A table for displaying warning details about the last stop in a timing pattern
    that is not designated as a timing point.
    """
    def __init__(self, *args, **kwargs):
        """
        Initialize the TimingLastWarningDetailTable with a custom warning message
        for the last affected stop.
        """
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"{self.last_effected_stop.name} is the last stop in a timing "
            "pattern but is not designated a timing point"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        """
        Meta subclass that inherits from StopNameTimingPatternTable.Meta.
        """
        pass


class TimingLastWarningVehicleTable(VehicleJourneyTable):
    """
    A table for displaying vehicle journey information related to the last timing
    warning.
    """
    class Meta(VehicleJourneyTable.Meta):
        """
        Meta subclass that inherits from VehicleJourneyTable.Meta.
        """
        pass


class TimingFirstWarningDetailTable(StopNameTimingPatternTable):
    """
    A table for displaying warning details about the first stop in a timing pattern
    that is not designated as a timing point.
    """
    def __init__(self, *args, **kwargs):
        """
        Initialize the TimingFirstWarningDetailTable with a custom warning message
        for the first affected stop.
        """
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"{self.first_effected_stop.name} is the first stop in a timing "
            "pattern but is not designated a timing point"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        """
        Meta subclass that inherits from StopNameTimingPatternTable.Meta.
        """
        pass


class TimingFirstWarningVehicleTable(VehicleJourneyTable):
    """
    A table for displaying vehicle journey information related to the first timing
    warning.
    """
    class Meta(VehicleJourneyTable.Meta):
        """
        Meta subclass that inherits from VehicleJourneyTable.Meta.
        """
        pass
```

from transit_odp.data_quality.tables.base import (
    StopNameTimingPatternTable,
    VehicleJourneyTable,
)


class TimingLastWarningDetailTable(StopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"{self.last_effected_stop.name} is the last stop in a timing "
            "pattern but is not designated a timing point"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        pass


class TimingLastWarningVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass


class TimingFirstWarningDetailTable(StopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"{self.first_effected_stop.name} is the first stop in a timing "
            "pattern but is not designated a timing point"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        pass


class TimingFirstWarningVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass
