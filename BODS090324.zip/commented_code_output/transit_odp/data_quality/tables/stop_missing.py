```python
from transit_odp.data_quality.tables import (
    StopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)

class MissingStopWarningListTable(TimingPatternListTable):
    """
    A table representation for a list of missing stop warnings, inheriting from TimingPatternListTable.
    """
    class Meta(TimingPatternListTable.Meta):
        """
        Meta subclass inheriting from TimingPatternListTable.Meta.
        """
        pass


class MissingStopWarningDetailTable(StopNameTimingPatternTable):
    """
    Detailed table representation for a specific missing stop warning, inheriting from StopNameTimingPatternTable.
    """
    def __init__(self, *args, **kwargs):
        """
        Initializes the MissingStopWarningDetailTable with a custom warning message.
        
        :param *args: Variable length argument list.
        :param **kwargs: Arbitrary keyword arguments.
        """
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"Next timing point after "
            f"{self.first_effected_stop.name} is missing or "
            f"is greater than 15 minutes away"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        """
        Meta subclass inheriting from StopNameTimingPatternTable.Meta.
        """
        pass


class MissingStopWarningVehicleTable(VehicleJourneyTable):
    """
    Table representation for vehicle journeys associated with missing stop warnings, inheriting from VehicleJourneyTable.
    """
    class Meta(VehicleJourneyTable.Meta):
        """
        Meta subclass inheriting from VehicleJourneyTable.Meta.
        """
        pass
```

from transit_odp.data_quality.tables import (
    StopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)


class MissingStopWarningListTable(TimingPatternListTable):
    class Meta(TimingPatternListTable.Meta):
        pass


class MissingStopWarningDetailTable(StopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"Next timing point after "
            f"{self.first_effected_stop.name} is missing or "
            f"is greater than 15 minutes away"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        pass


class MissingStopWarningVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass
