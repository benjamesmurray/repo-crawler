```python
import django_tables2 as tables
from django.utils.html import format_html

from transit_odp.data_quality.tables.base import (
    JourneyListTable,
    StopNameTimingPatternTable,
    VehicleJourneyTimingPatternTable,
)

class BackwardDateRangeWarningListTable(JourneyListTable):
    """
    A table for displaying a list of warnings related to backward date ranges.

    Inherits from JourneyListTable and adds specific columns and rendering logic
    for the backward date range warnings.
    """
    line = tables.Column(
        verbose_name="Line",
        orderable=False,
    )

    class Meta(JourneyListTable.Meta):
        """
        Meta class to inherit the properties from JourneyListTable.Meta.
        """
        pass

    def render_message(self, value, record):
        """
        Render the message column as a hyperlink.

        Args:
            value: The value of the message field.
            record: The record containing the message and URL.

        Returns:
            A formatted HTML string with a hyperlink.
        """
        return format_html(
            """
            <a class="govuk-link" href="{}">{}</div>
            """,
            record.get_absolute_url(),
            record.message,
        )


class BackwardDateRangeWarningDetailTable(VehicleJourneyTimingPatternTable):
    """
    A detailed table for displaying information about a specific backward date range warning.

    Inherits from VehicleJourneyTimingPatternTable and uses the Meta properties
    from StopNameTimingPatternTable.
    """

    class Meta(StopNameTimingPatternTable.Meta):
        """
        Meta class to inherit the properties from StopNameTimingPatternTable.Meta.
        """
        pass

    def __init__(self, *args, **kwargs):
        """
        Initialize the table with a formatted warning message.

        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        super().__init__(*args, **kwargs)
        self.warning_message = format_html(self.warning_message)
```

import django_tables2 as tables
from django.utils.html import format_html

from transit_odp.data_quality.tables.base import (
    JourneyListTable,
    StopNameTimingPatternTable,
    VehicleJourneyTimingPatternTable,
)


class BackwardDateRangeWarningListTable(JourneyListTable):
    line = tables.Column(
        verbose_name="Line",
        orderable=False,
    )

    class Meta(JourneyListTable.Meta):
        pass

    def render_message(self, value, record):
        return format_html(
            """
            <a class="govuk-link" href="{}">{}</div>
            """,
            record.get_absolute_url(),
            record.message,
        )


class BackwardDateRangeWarningDetailTable(VehicleJourneyTimingPatternTable):
    class Meta(StopNameTimingPatternTable.Meta):
        pass

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.warning_message = format_html(self.warning_message)
