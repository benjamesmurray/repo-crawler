```python
import django_tables2 as tables
from transit_odp.data_quality.tables import WarningListBaseTable

class IncorrectNOCListTable(WarningListBaseTable):
    """
    A table for displaying a list of warnings related to incorrect NOC (National Operator Code) codes.

    Inherits from WarningListBaseTable which provides the basic structure for warning tables.

    Attributes:
        message: A column in the table to display the summary of the warning. This is not orderable
                 and can handle empty values.
    """
    
    # Column for displaying the summary of the warning
    message = tables.Column(verbose_name="Summary", orderable=False, empty_values=())

    class Meta(WarningListBaseTable.Meta):
        """
        Meta options for IncorrectNOCListTable.

        Inherits all meta options from WarningListBaseTable.Meta and specifies the order in which
        the columns appear in the table.
        """
        # Define the sequence of columns to be displayed in the table
        sequence = ("message",)
```

import django_tables2 as tables

from transit_odp.data_quality.tables import WarningListBaseTable


class IncorrectNOCListTable(WarningListBaseTable):
    message = tables.Column(verbose_name="Summary", orderable=False, empty_values=())

    class Meta(WarningListBaseTable.Meta):
        sequence = ("message",)
