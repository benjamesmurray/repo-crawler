```python
import django_tables2 as tables

from transit_odp.data_quality.tables.base import (
    BaseStopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)

class PickUpDropOffListTable(TimingPatternListTable):
    """
    A table to list timing patterns with additional column for line.
    
    Inherits from TimingPatternListTable and adds a 'line' column.
    """
    line = tables.Column(verbose_name="Line", orderable=False)

    class Meta(TimingPatternListTable.Meta):
        """
        Meta subclass to define additional properties for the table.
        
        Sets the sequence of columns, starting with 'line' followed by 'message'.
        """
        sequence = ("line", "message")


class LastStopPickUpOnlyDetail(BaseStopNameTimingPatternTable):
    """
    A table detailing timing patterns where the last stop is pick-up only.
    
    Extends BaseStopNameTimingPatternTable with specific functionality for stops
    that are pick-up only.
    """
    def __init__(self, *args, **kwargs):
        """
        Initialize the table with custom row attributes.
        
        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        row_attrs = {
            "class": lambda record: "effected"
            if record.position in list(self.effected_stop_positions)
            else ""
        }
        kwargs.pop("effected_stop_positions", None)
        self.effected_stops = kwargs.pop("effected_stops")
        self.last_effected_stop = self.effected_stops.latest("position")
        self.effected_stop_positions = [self.last_effected_stop.position]
        self.warning_message = (
            f"{self.last_effected_stop.name} is the last "
            "stop in a timing pattern but is designated as pick up only"
        )
        super().__init__(*args, row_attrs=row_attrs, **kwargs)

    class Meta(BaseStopNameTimingPatternTable.Meta):
        """
        Meta subclass to inherit properties from the BaseStopNameTimingPatternTable.
        """
        pass


class FirstStopDropOffOnlyDetail(BaseStopNameTimingPatternTable):
    """
    A table detailing timing patterns where the first stop is drop-off only.
    
    Extends BaseStopNameTimingPatternTable with specific functionality for stops
    that are drop-off only.
    """
    def __init__(self, *args, **kwargs):
        """
        Initialize the table with custom row attributes.
        
        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        row_attrs = {
            "class": lambda record: "effected"
            if record.position in list(self.effected_stop_positions)
            else ""
        }
        kwargs.pop("effected_stop_positions", None)
        self.effected_stops = kwargs.pop("effected_stops")
        self.first_effected_stop = self.effected_stops.earliest("position")
        self.effected_stop_positions = [self.first_effected_stop.position]
        self.warning_message = (
            f"{self.first_effected_stop.name} is "
            "the first stop in a timing pattern but is designated as set down only"
        )
        super().__init__(*args, row_attrs=row_attrs, **kwargs)

    class Meta(BaseStopNameTimingPatternTable.Meta):
        """
        Meta subclass to inherit properties from the BaseStopNameTimingPatternTable.
        """
        pass


class LastStopPickUpOnlyVehicleTable(VehicleJourneyTable):
    """
    A table for vehicle journeys with the last stop being pick-up only.
    
    Inherits from VehicleJourneyTable without adding additional functionality.
    """
    class Meta(VehicleJourneyTable.Meta):
        """
        Meta subclass to inherit properties from the VehicleJourneyTable.
        """
        pass


class FirstStopDropOffOnlyVehicleTable(VehicleJourneyTable):
    """
    A table for vehicle journeys with the first stop being drop-off only.
    
    Inherits from VehicleJourneyTable without adding additional functionality.
    """
    class Meta(VehicleJourneyTable.Meta):
        """
        Meta subclass to inherit properties from the VehicleJourneyTable.
        """
        pass
```

import django_tables2 as tables

from transit_odp.data_quality.tables.base import (
    BaseStopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)


class PickUpDropOffListTable(TimingPatternListTable):
    line = tables.Column(verbose_name="Line", orderable=False)

    class Meta(TimingPatternListTable.Meta):
        sequence = ("line", "message")


class LastStopPickUpOnlyDetail(BaseStopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        row_attrs = {
            "class": lambda record: "effected"
            if record.position in list(self.effected_stop_positions)
            else ""
        }
        kwargs.pop("effected_stop_positions", None)
        self.effected_stops = kwargs.pop("effected_stops")
        self.last_effected_stop = self.effected_stops.latest("position")
        self.effected_stop_positions = [self.last_effected_stop.position]
        self.warning_message = (
            f"{self.last_effected_stop.name} is the last "
            "stop in a timing pattern but is designated as pick up only"
        )
        super().__init__(*args, row_attrs=row_attrs, **kwargs)

    class Meta(BaseStopNameTimingPatternTable.Meta):
        pass


class FirstStopDropOffOnlyDetail(BaseStopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        row_attrs = {
            "class": lambda record: "effected"
            if record.position in list(self.effected_stop_positions)
            else ""
        }
        kwargs.pop("effected_stop_positions", None)
        self.effected_stops = kwargs.pop("effected_stops")
        self.first_effected_stop = self.effected_stops.earliest("position")
        self.effected_stop_positions = [self.first_effected_stop.position]
        self.warning_message = (
            f"{self.first_effected_stop.name} is "
            "the first stop in a timing pattern but is designated as set down only"
        )
        super().__init__(*args, row_attrs=row_attrs, **kwargs)

    class Meta(BaseStopNameTimingPatternTable.Meta):
        pass


class LastStopPickUpOnlyVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass


class FirstStopDropOffOnlyVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass
