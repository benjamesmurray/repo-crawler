```python
from transit_odp.data_quality.tables.base import (
    JourneyLineListTable,
    VehicleJourneyTimingPatternTable,
)

class DuplicateJourneyListTable(JourneyLineListTable):
    """
    A table for displaying a list of duplicate journeys.
    
    This table extends JourneyLineListTable and overrides the initialization
    method to correct the journey count for duplicates.
    """
    
    class Meta(JourneyLineListTable.Meta):
        """Inherit the Meta class from JourneyLineListTable."""
        pass

    def __init__(self, *args, **kwargs):
        """
        Initializes the DuplicateJourneyListTable with a corrected journey count.
        
        The count is obtained from the queryset to reflect the actual number of
        duplicates, instead of the summary which may double count.
        
        :param args: Variable length argument list.
        :param kwargs: Arbitrary keyword arguments, expects 'data' to be provided.
        """
        # Override init since DataQualityReportSummary double counts duplicates
        # i.e. original + duplicate is 2 journeys but 1 duplicate
        # Deduplication occurs in the queryset so to get the header to show the
        # correct count we just count the queryset and replace the count that
        # comes from the summary.
        qs = kwargs["data"]
        kwargs["count"] = qs.count()
        super().__init__(*args, **kwargs)


class DuplicateJourneyWarningTimingTable(VehicleJourneyTimingPatternTable):
    """
    A table for displaying timing patterns with a warning for duplicate journeys.
    
    This table extends VehicleJourneyTimingPatternTable and adds a caption to
    indicate that a journey is included in the data more than once.
    """
    
    caption_end = "is included in your data more than once."

    class Meta(VehicleJourneyTimingPatternTable.Meta):
        """Inherit the Meta class from VehicleJourneyTimingPatternTable."""
        pass
```

from transit_odp.data_quality.tables.base import (
    JourneyLineListTable,
    VehicleJourneyTimingPatternTable,
)


class DuplicateJourneyListTable(JourneyLineListTable):
    class Meta(JourneyLineListTable.Meta):
        pass

    def __init__(self, *args, **kwargs):
        # Override init since DataQualityReportSummary double counts duplicates
        # i.e. original + duplicate is 2 journeys but 1 duplicate
        # Deduplication occurs in the queryset so to get the header to show the
        # correct count we just count the queryset and replace the count that
        # comes from the summary.
        qs = kwargs["data"]
        kwargs["count"] = qs.count()
        super().__init__(*args, **kwargs)


class DuplicateJourneyWarningTimingTable(VehicleJourneyTimingPatternTable):
    caption_end = "is included in your data more than once."

    class Meta(VehicleJourneyTimingPatternTable.Meta):
        pass
