```python
from transit_odp.data_quality.tables.base import (
    StopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)

class StopRepeatedWarningListTable(TimingPatternListTable):
    """
    A table that inherits from TimingPatternListTable and represents a list
    of timing patterns where a stop is repeated.
    """
    class Meta(TimingPatternListTable.Meta):
        pass


class StopRepeatedWarningDetailTable(StopNameTimingPatternTable):
    """
    A detailed table that inherits from StopNameTimingPatternTable and provides
    additional information about repeated stops within a timing pattern.
    
    The table includes a warning message indicating the first affected stop and
    the number of times it is repeated.
    """
    def __init__(self, *args, **kwargs):
        """
        Initializes the StopRepeatedWarningDetailTable with a custom warning message
        about the repetition of a stop.
        
        :param args: Arguments passed to the parent class constructor.
        :param kwargs: Keyword arguments passed to the parent class constructor.
        """
        super().__init__(*args, **kwargs)
        count = self.effected_stops.count()
        self.warning_message = (
            f"{self.first_effected_stop.name} is repeated {count} times on a route"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        pass


class StopRepeatedWarningVehicleTable(VehicleJourneyTable):
    """
    A table that inherits from VehicleJourneyTable and represents vehicle journeys
    associated with repeated stop warnings.
    """
    class Meta(VehicleJourneyTable.Meta):
        pass
```

from transit_odp.data_quality.tables.base import (
    StopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)


class StopRepeatedWarningListTable(TimingPatternListTable):
    class Meta(TimingPatternListTable.Meta):
        pass


class StopRepeatedWarningDetailTable(StopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        count = self.effected_stops.count()
        self.warning_message = (
            f"{self.first_effected_stop.name} is repeated {count} times on a route"
        )

    class Meta(StopNameTimingPatternTable.Meta):
        pass


class StopRepeatedWarningVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass
