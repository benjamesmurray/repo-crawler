```python
import django_tables2 as tables
from django.utils.html import format_html

from transit_odp.common.tables import GovUkTable
from transit_odp.data_quality.tables.base import (
    BaseStopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)

class BackwardTimingsListTable(TimingPatternListTable):
    """
    A table for displaying the list of timing patterns with backward timings.
    
    Attributes:
        message: A column to display the message about the backward timing pattern.
    """
    
    message = tables.Column(
        verbose_name="Timing pattern", orderable=False, empty_values=()
    )

    def render_message(self, value, record):
        """
        Renders the message for each timing pattern indicating the stops between which 
        backward timing was detected.
        
        Parameters:
            value: The value to be rendered (unused in this method).
            record: The record for the current row in the table.
        
        Returns:
            An HTML string to display as a hyperlink with the backward timing message.
        """
        first_effected_stop = record.from_stop.service_pattern_stop.stop.name
        last_effected_stop = record.to_stop.service_pattern_stop.stop.name
        message = (
            f"Backward timing between {first_effected_stop} and {last_effected_stop}"
        )

        return format_html(
            """
            <a class="govuk-link" href="{}">{}</div>
            """,
            record.get_absolute_url(),
            message,
        )

    class Meta(GovUkTable.Meta):
        """
        Meta subclass to define table-specific options.
        """
        sequence = ("line", "message")


class BackwardTimingsWarningTable(BaseStopNameTimingPatternTable):
    """
    A table for displaying warnings about backward timings between stops.
    
    The table is initialized with the positions of affected stops and the stops themselves,
    which are used to construct the warning message.
    """
    
    def __init__(self, *args, **kwargs):
        """
        Initializes the BackwardTimingsWarningTable with specific attributes for affected stops.
        
        Parameters:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments, expects 'effected_stop_positions' and 
                      'effected_stops' to be provided among others.
        """
        self.effected_stop_positions = list(kwargs.pop("effected_stop_positions"))
        self.first_effected_stop, self.last_effected_stop = kwargs.pop("effected_stops")
        self.warning_message = (
            f"Backward timing was detected between "
            f"{self.first_effected_stop.service_pattern_stop.stop.name} and "
            f"{self.last_effected_stop.service_pattern_stop.stop.name}"
        )
        row_attrs = {
            "class": lambda record: "effected"
            if record.position in self.effected_stop_positions
            else ""
        }
        super().__init__(*args, row_attrs=row_attrs, **kwargs)

    class Meta(BaseStopNameTimingPatternTable.Meta):
        """
        Meta subclass to define table-specific options.
        """
        pass


class BackwardTimingVehicleTable(VehicleJourneyTable):
    """
    A table for displaying vehicle journeys with backward timings.
    """
    
    class Meta(VehicleJourneyTable.Meta):
        """
        Meta subclass to define table-specific options.
        """
        pass
```

import django_tables2 as tables
from django.utils.html import format_html

from transit_odp.common.tables import GovUkTable
from transit_odp.data_quality.tables.base import (
    BaseStopNameTimingPatternTable,
    TimingPatternListTable,
    VehicleJourneyTable,
)


class BackwardTimingsListTable(TimingPatternListTable):
    message = tables.Column(
        verbose_name="Timing pattern", orderable=False, empty_values=()
    )

    def render_message(self, value, record):
        first_effected_stop = record.from_stop.service_pattern_stop.stop.name
        last_effected_stop = record.to_stop.service_pattern_stop.stop.name
        message = (
            f"Backward timing between {first_effected_stop} and {last_effected_stop}"
        )

        return format_html(
            """
            <a class="govuk-link" href="{}">{}</div>
            """,
            record.get_absolute_url(),
            message,
        )

    # If leave out Meta, formatting goes weird even though it's inheriting from
    # JourneyListTable
    class Meta(GovUkTable.Meta):
        sequence = ("line", "message")


class BackwardTimingsWarningTable(BaseStopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        self.effected_stop_positions = list(kwargs.pop("effected_stop_positions"))
        self.first_effected_stop, self.last_effected_stop = kwargs.pop("effected_stops")
        self.warning_message = (
            f"Backward timing was detected between "
            f"{self.first_effected_stop.service_pattern_stop.stop.name} and "
            f"{self.last_effected_stop.service_pattern_stop.stop.name}"
        )
        row_attrs = {
            "class": lambda record: "effected"
            if record.position in self.effected_stop_positions
            else ""
        }
        super().__init__(*args, row_attrs=row_attrs, **kwargs)

    class Meta(BaseStopNameTimingPatternTable.Meta):
        pass


class BackwardTimingVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass
