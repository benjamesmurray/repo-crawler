```python
from transit_odp.data_quality.tables.fast_timings import (
    FastTimingWarningTimingTable,
    FastTimingWarningVehicleTable,
)

# Technically these dont need to be defined but defining them anyway to be explicit

class FastLinkWarningTimingTable(FastTimingWarningTimingTable):
    """
    A table for displaying fast link timing warnings.
    
    Inherits from FastTimingWarningTimingTable and uses its Meta class.
    No additional attributes or methods are defined.
    """
    
    class Meta(FastTimingWarningTimingTable.Meta):
        """
        Meta class inheriting from FastTimingWarningTimingTable's Meta.
        
        This is used to define model-specific options for the table.
        """
        pass


class FastLinkWarningVehicleTable(FastTimingWarningVehicleTable):
    """
    A table for displaying fast link vehicle warnings.
    
    Inherits from FastTimingWarningVehicleTable and uses its Meta class.
    No additional attributes or methods are defined.
    """
    
    class Meta(FastTimingWarningVehicleTable.Meta):
        """
        Meta class inheriting from FastTimingWarningVehicleTable's Meta.
        
        This is used to define model-specific options for the table.
        """
        pass
```

from transit_odp.data_quality.tables.fast_timings import (
    FastTimingWarningTimingTable,
    FastTimingWarningVehicleTable,
)

# Technically these dont need to be defined but defining them anyway to be explicit


class FastLinkWarningTimingTable(FastTimingWarningTimingTable):
    class Meta(FastTimingWarningTimingTable.Meta):
        pass


class FastLinkWarningVehicleTable(FastTimingWarningVehicleTable):
    class Meta(FastTimingWarningVehicleTable.Meta):
        pass
