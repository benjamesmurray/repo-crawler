```python
from transit_odp.data_quality.tables.base import (
    StopNameTimingPatternTable,
    VehicleJourneyTable,
)

class FastTimingWarningTimingTable(StopNameTimingPatternTable):
    """
    A table representation for fast timing warnings related to timing patterns.
    
    This table inherits from StopNameTimingPatternTable and adds a warning message
    specific to the fast timing warning, indicating that the travel speed between
    two stops exceeds a threshold (70 mph in this case).
    """
    
    def __init__(self, *args, **kwargs):
        """
        Initialize the FastTimingWarningTimingTable with a custom warning message.
        
        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"Timing pattern requires travel "
            f"between {self.first_effected_stop.name} and "
            f"{self.last_effected_stop.name} over a speed of 70 mph."
        )

    class Meta(StopNameTimingPatternTable.Meta):
        """
        Meta subclass that inherits from StopNameTimingPatternTable.Meta.
        
        This allows the specification of metadata for the table class.
        """
        pass


class FastTimingWarningVehicleTable(VehicleJourneyTable):
    """
    A table representation for fast timing warnings related to vehicle journeys.
    
    This table inherits from VehicleJourneyTable and uses the metadata defined
    in the parent class.
    """
    
    class Meta(VehicleJourneyTable.Meta):
        """
        Meta subclass that inherits from VehicleJourneyTable.Meta.
        
        This allows the specification of metadata for the table class.
        """
        pass
```

from transit_odp.data_quality.tables.base import (
    StopNameTimingPatternTable,
    VehicleJourneyTable,
)


class FastTimingWarningTimingTable(StopNameTimingPatternTable):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.warning_message = (
            f"Timing pattern requires travel "
            f"between {self.first_effected_stop.name} and "
            f"{self.last_effected_stop.name} over a speed of 70 mph."
        )

    class Meta(StopNameTimingPatternTable.Meta):
        pass


class FastTimingWarningVehicleTable(VehicleJourneyTable):
    class Meta(VehicleJourneyTable.Meta):
        pass
