```python
import logging

from django.core.files.base import ContentFile
from tenacity import before_log, retry, stop_after_attempt, wait_random_exponential

from transit_odp.data_quality.dqs.client import DQSClient
from transit_odp.pipelines.exceptions import PipelineException
from transit_odp.pipelines.models import DataQualityTask

logger = logging.getLogger(__name__)


def get_data_quality_task_or_pipeline_error(pk):
    """
    Retrieve a DataQualityTask by its primary key or raise a PipelineException if not found.

    :param pk: The primary key of the DataQualityTask to retrieve.
    :return: The DataQualityTask instance.
    :raises PipelineException: If the DataQualityTask does not exist.
    """
    try:
        task = DataQualityTask.objects.get(id=pk)
    except DataQualityTask.DoesNotExist as exc:
        message = f"DataQualityTask {pk} does not exist."
        logger.exception(message, exc_info=True)
        raise PipelineException(message) from exc
    else:
        return task


@retry(
    reraise=True,
    wait=wait_random_exponential(multiplier=1, max=4),
    stop=stop_after_attempt(3),
    before=before_log(logger, logging.DEBUG),
)
def get_dqs_task_status(task_id):
    """
    Get the status of a task from the DQS client with retrying on failure.

    :param task_id: The ID of the task to check the status of.
    :return: The status of the task.
    """
    dqs = DQSClient()
    return dqs.get_status(task_id)


def create_dqs_report(task_id):
    """
    Download a data quality report from DQS client for the given task ID.

    :param task_id: The ID of the task for which to download the report.
    :return: A ContentFile containing the report data.
    """
    dqs = DQSClient()
    data = dqs.download(task_id)
    logger.info(f"DQS report downloaded successfully for {task_id}")
    return ContentFile(data)


@retry(
    reraise=True,
    wait=wait_random_exponential(multiplier=0.5, max=10),
    stop=stop_after_attempt(5),
    before=before_log(logger, logging.DEBUG),
)
def upload_file_to_dqs(file_):
    """
    Upload a file to DQS client with retrying on failure.

    :param file_: The file to be uploaded.
    :return: The UUID of the report as returned by the DQS client.
    """
    logger.info(f"Uploading {file_.name} to DQS")
    dqs = DQSClient()
    report_uuid = dqs.upload(file_)
    return report_uuid
```

import logging

from django.core.files.base import ContentFile
from tenacity import before_log, retry, stop_after_attempt, wait_random_exponential

from transit_odp.data_quality.dqs.client import DQSClient
from transit_odp.pipelines.exceptions import PipelineException
from transit_odp.pipelines.models import DataQualityTask

logger = logging.getLogger(__name__)


def get_data_quality_task_or_pipeline_error(pk):
    try:
        task = DataQualityTask.objects.get(id=pk)
    except DataQualityTask.DoesNotExist as exc:
        message = f"DataQualityTask {pk} does not exist."
        logger.exception(message, exc_info=True)
        raise PipelineException(message) from exc
    else:
        return task


@retry(
    reraise=True,
    wait=wait_random_exponential(multiplier=1, max=4),
    stop=stop_after_attempt(3),
    before=before_log(logger, logging.DEBUG),
)
def get_dqs_task_status(task_id):
    dqs = DQSClient()
    return dqs.get_status(task_id)


def create_dqs_report(task_id):
    dqs = DQSClient()
    data = dqs.download(task_id)
    logger.info(f"DQS report downloaded successfully for {task_id}")
    return ContentFile(data)


@retry(
    reraise=True,
    wait=wait_random_exponential(multiplier=0.5, max=10),
    stop=stop_after_attempt(5),
    before=before_log(logger, logging.DEBUG),
)
def upload_file_to_dqs(file_):
    logger.info(f"Uploading {file_.name} to DQS")
    dqs = DQSClient()
    report_uuid = dqs.upload(file_)
    return report_uuid
