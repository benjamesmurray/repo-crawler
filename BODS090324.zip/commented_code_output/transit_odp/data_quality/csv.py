```python
import csv
import io
from typing import List

from django.db.models.expressions import Value
from django.db.models.fields import CharField

from transit_odp.data_quality.constants import Observation


class ObservationCSV:
    """
    A class to represent a CSV file containing a list of observations.

    Attributes:
        report_id: The ID of the report these observations belong to.
        observations: A list of Observation instances to be included in the CSV.

    Methods:
        to_csv(): Returns a CSV string of the observation data.
        get_rows(observation): Returns a list of rows for a single observation type.
    """

    def __init__(self, report_id, observations: List[Observation]):
        """
        Initializes the ObservationCSV instance.

        Parameters:
            report_id: The unique identifier for the report.
            observations: A list of Observation objects to be converted to CSV.
        """
        self._report_id = report_id
        self._observation_types = observations

    def to_csv(self):
        """
        Converts the observations to a CSV formatted string.

        Returns:
            A string representing the contents of the CSV file.
        """
        string_ = io.StringIO()
        writer = csv.writer(string_, quoting=csv.QUOTE_ALL)
        writer.writerow(["Importance", "Line", "Observation", "Detail"])

        observations = [o for o in self._observation_types if o.model]
        observations.sort(key=lambda o: o.level.name, reverse=True)
        for o in observations:
            rows = self.get_rows(o)
            writer.writerows(rows)

        string_.seek(0)
        return string_

    def get_rows(self, observation: Observation):
        """
        Retrieves rows for a given observation type.

        Parameters:
            observation: An Observation instance for which rows are to be generated.

        Returns:
            A list of tuples, each representing a row of CSV data.
        """
        qs = observation.model.objects.filter(report_id=self._report_id)

        if hasattr(qs, "get_csv_queryset"):
            qs = qs.get_csv_queryset()

        qs = qs.annotate(
            importance=Value(observation.level.value, output_field=CharField()),
            observation=Value(observation.title, output_field=CharField()),
        )

        if hasattr(qs, "add_line"):
            qs = qs.add_line(self._report_id)
        else:
            qs = qs.annotate(line=Value("", output_field=CharField()))

        if hasattr(qs, "add_message"):
            qs = qs.add_message()
        else:
            qs = qs.annotate(message=Value("", output_field=CharField()))

        return list(qs.values_list("importance", "line", "observation", "message"))
```

import csv
import io
from typing import List

from django.db.models.expressions import Value
from django.db.models.fields import CharField

from transit_odp.data_quality.constants import Observation


class ObservationCSV:
    def __init__(self, report_id, observations: List[Observation]):
        self._report_id = report_id
        self._observation_types = observations

    def to_csv(self):
        string_ = io.StringIO()
        writer = csv.writer(string_, quoting=csv.QUOTE_ALL)
        writer.writerow(["Importance", "Line", "Observation", "Detail"])

        observations = [o for o in self._observation_types if o.model]
        observations.sort(key=lambda o: o.level.name, reverse=True)
        for o in observations:
            rows = self.get_rows(o)
            writer.writerows(rows)

        string_.seek(0)
        return string_

    def get_rows(self, observation: Observation):
        qs = observation.model.objects.filter(report_id=self._report_id)

        if hasattr(qs, "get_csv_queryset"):
            qs = qs.get_csv_queryset()

        qs = qs.annotate(
            importance=Value(observation.level.value, output_field=CharField()),
            observation=Value(observation.title, output_field=CharField()),
        )

        if hasattr(qs, "add_line"):
            qs = qs.add_line(self._report_id)
        else:
            qs = qs.annotate(line=Value("", output_field=CharField()))

        if hasattr(qs, "add_message"):
            qs = qs.add_message()
        else:
            qs = qs.annotate(message=Value("", output_field=CharField()))

        return list(qs.values_list("importance", "line", "observation", "message"))
