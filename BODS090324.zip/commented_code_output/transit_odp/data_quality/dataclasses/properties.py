```python
from dataclasses import dataclass
from typing import List, final

@dataclass
class Properties:
    """
    Base properties class that holds common feature attributes.

    Attributes:
        feature_name (str): The name of the feature.
    """
    feature_name: str


@final
@dataclass
class StopProperties(Properties):
    """
    Represents the properties specific to a stop, inheriting from Properties.

    Attributes:
        atco_code (str): A unique identifier for the stop.
        bearing (int): The compass bearing that the vehicle will be facing when at the stop.
        synthetic (bool): A flag indicating if the stop is a synthetic (not physical) stop.
        type (str): The type of the stop (e.g., bus, tram).
    """
    atco_code: str
    bearing: int
    synthetic: bool
    type: str


@final
@dataclass
class ServicePatternProperties(Properties):
    """
    Represents properties of a service pattern, inheriting from Properties.

    Attributes:
        length_m (float): The length of the service pattern in meters.
        line (str): The line associated with the service pattern.
        route_shape (bool): A flag indicating if the service pattern has a defined route shape.
        service_links (List[str]): A list of identifiers for the service links in the pattern.
        stops (List[str]): A list of identifiers for the stops in the pattern.
        timing_patterns (List[str]): A list of identifiers for the timing patterns in the pattern.
    """
    length_m: float
    line: str
    route_shape: bool
    service_links: List[str]
    stops: List[str]
    timing_patterns: List[str]


@final
@dataclass
class ServiceLinkProperties(Properties):
    """
    Represents properties of a service link, inheriting from Properties.

    Attributes:
        from_stop (str): The identifier of the stop where the service link starts.
        length_m (float): The length of the service link in meters.
        route_shape (bool): A flag indicating if the service link has a defined route shape.
        service_patterns (List[str]): A list of identifiers for the service patterns that include this link.
        to_stop (str): The identifier of the stop where the service link ends.
    """
    from_stop: str
    length_m: float
    route_shape: bool
    service_patterns: List[str]
    to_stop: str
```

from dataclasses import dataclass
from typing import List, final


@dataclass
class Properties:
    feature_name: str


@final
@dataclass
class StopProperties(Properties):
    atco_code: str
    bearing: int
    synthetic: bool
    type: str


@final
@dataclass
class ServicePatternProperties(Properties):
    length_m: float
    line: str
    route_shape: bool
    service_links: List[str]
    stops: List[str]
    timing_patterns: List[str]


@final
@dataclass
class ServiceLinkProperties(Properties):
    from_stop: str
    length_m: float
    route_shape: bool
    service_patterns: List[str]
    to_stop: str
