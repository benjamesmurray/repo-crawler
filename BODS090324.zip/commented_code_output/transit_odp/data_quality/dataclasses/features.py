```python
from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List

from .properties import (
    Properties,
    ServiceLinkProperties,
    ServicePatternProperties,
    StopProperties,
)


@dataclass
class Geometry:
    """
    Represents the geometric information of a feature, including its coordinates and type.
    """
    coordinates: List[List]
    type: str


@dataclass
class Feature:
    """
    Represents a geographic feature with a geometry, identifier, and associated properties.
    """
    geometry: Geometry
    id: str
    properties: Properties

    @classmethod
    def from_dict(cls, feature):
        """
        Creates an instance of Feature from a dictionary representation.
        
        :param feature: A dictionary containing the keys 'id', 'geometry', and 'properties'.
        :return: An instance of Feature.
        """
        Properties = cls.__dataclass_fields__["properties"].type
        properties = Properties(**feature["properties"])
        geometry = Geometry(**feature["geometry"])
        return cls(id=feature["id"], geometry=geometry, properties=properties)


@dataclass
class Stop(Feature):
    """
    Represents a stop feature with specific properties for a stop.
    """
    properties: StopProperties


@dataclass
class ServicePattern(Feature):
    """
    Represents a service pattern feature with specific properties for a service pattern.
    """
    properties: ServicePatternProperties


@dataclass
class ServiceLink(Feature):
    """
    Represents a service link feature with specific properties for a service link.
    """
    properties: ServiceLinkProperties


@dataclass
class Operator:
    """
    Represents a public transport operator with an identifier and name.
    """
    id: str
    name: str


@dataclass
class Line:
    """
    Represents a public transport line with an identifier and name.
    """
    id: str
    name: str


@dataclass
class Timing:
    """
    Represents the timing information for a specific point along a service pattern.
    
    It includes arrival and departure times, allowance flags for pickup and setdown,
    and optionally distance and speed information.
    """
    arrival_time_secs: int
    departure_time_secs: int
    pickup_allowed: bool
    setdown_allowed: bool
    timing_point: bool
    distance: int = None
    speed: int = None

    @property
    def arrival(self):
        """
        Converts the arrival time from seconds to a timedelta object.
        
        :return: A timedelta object representing the arrival time.
        """
        return timedelta(seconds=self.arrival_time_secs)

    @property
    def departure(self):
        """
        Converts the departure time from seconds to a timedelta object.
        
        :return: A timedelta object representing the departure time.
        """
        return timedelta(seconds=self.departure_time_secs)


@dataclass
class TimingPattern:
    """
    Represents a timing pattern which is a sequence of timings for a service pattern.
    
    It includes an identifier, a reference to a service pattern, a list of timings,
    and a list of associated vehicle journeys.
    """
    id: str
    service_pattern: str
    timings: List[Timing]
    vehicle_journeys: List[str]

    @classmethod
    def from_dict(cls, timing_pattern):
        """
        Creates an instance of TimingPattern from a dictionary representation.
        
        :param timing_pattern: A dictionary containing the keys 'id', 'service_pattern', 'timings', and 'vehicle_journeys'.
        :return: An instance of TimingPattern.
        """
        timings = [Timing(**t) for t in timing_pattern["timings"]]
        return cls(
            id=timing_pattern["id"],
            service_pattern=timing_pattern["service_pattern"],
            timings=timings,
            vehicle_journeys=timing_pattern["vehicle_journeys"],
        )


@dataclass
class VehicleJourney:
    """
    Represents a vehicle journey with an identifier, timing pattern reference,
    start time in seconds, feature name, headsign, and a list of operational dates.
    """
    id: str
    timing_pattern: str
    start: int
    feature_name: str
    headsign: str
    dates: List[str]

    @property
    def start_time(self) -> datetime.time:
        """
        Converts the start time from seconds to a datetime.time object.
        
        :return: A datetime.time object representing the start time.
        """
        if self.start > 0:
            date = datetime.min
        else:
            # negative start would cause OverflowError using datetime.min
            date = datetime.min + timedelta(days=1)

        date_time = date + timedelta(seconds=self.start)
        return date_time.time()

    @property
    def datetime_dates(self) -> List[datetime.date]:
        """
        Converts the list of operational dates from ISO format strings to datetime.date objects.
        
        :return: A list of datetime.date objects representing the operational dates.
        """
        return [datetime.fromisoformat(d).date() for d in self.dates]
```

from dataclasses import dataclass
from datetime import datetime, timedelta
from typing import List

from .properties import (
    Properties,
    ServiceLinkProperties,
    ServicePatternProperties,
    StopProperties,
)


@dataclass
class Geometry:
    coordinates: List[List]
    type: str


@dataclass
class Feature:
    geometry: Geometry
    id: str
    properties: Properties

    @classmethod
    def from_dict(cls, feature):
        Properties = cls.__dataclass_fields__["properties"].type
        properties = Properties(**feature["properties"])
        geometry = Geometry(**feature["geometry"])
        return cls(id=feature["id"], geometry=geometry, properties=properties)


@dataclass
class Stop(Feature):
    properties: StopProperties


@dataclass
class ServicePattern(Feature):
    properties: ServicePatternProperties


@dataclass
class ServiceLink(Feature):
    properties: ServiceLinkProperties


@dataclass
class Operator:
    id: str
    name: str


@dataclass
class Line:
    id: str
    name: str


@dataclass
class Timing:
    arrival_time_secs: int
    departure_time_secs: int
    pickup_allowed: bool
    setdown_allowed: bool
    timing_point: bool
    distance: int = None
    speed: int = None

    @property
    def arrival(self):
        return timedelta(seconds=self.arrival_time_secs)

    @property
    def departure(self):
        return timedelta(seconds=self.departure_time_secs)


@dataclass
class TimingPattern:
    id: str
    service_pattern: str
    timings: List[Timing]
    vehicle_journeys: List[str]

    @classmethod
    def from_dict(cls, timing_pattern):
        timings = [Timing(**t) for t in timing_pattern["timings"]]
        return cls(
            id=timing_pattern["id"],
            service_pattern=timing_pattern["service_pattern"],
            timings=timings,
            vehicle_journeys=timing_pattern["vehicle_journeys"],
        )


@dataclass
class VehicleJourney:
    id: str
    timing_pattern: str
    start: int
    feature_name: str
    headsign: str
    dates: List[str]

    @property
    def start_time(self) -> datetime.time:
        """
        Return the `start` seconds as a datetime.time object.
        """
        if self.start > 0:
            date = datetime.min
        else:
            # negative start would cause OverflowError using datetime.min
            date = datetime.min + timedelta(days=1)

        date_time = date + timedelta(seconds=self.start)
        return date_time.time()

    @property
    def datetime_dates(self) -> List[datetime.date]:
        return [datetime.fromisoformat(d).date() for d in self.dates]
