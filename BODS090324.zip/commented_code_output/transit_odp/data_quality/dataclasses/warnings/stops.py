```python
from dataclasses import dataclass
from typing import List

from transit_odp.data_quality.dataclasses.warnings.base import BaseWarning

@dataclass
class StopMissingNaptan(BaseWarning):
    """
    Represents a warning for a stop that is missing a NaPTAN code.

    Attributes:
        service_patterns: A list of service patterns associated with the warning.
    """
    service_patterns: List[str]


@dataclass
class StopIncorrectType(BaseWarning):
    """
    Represents a warning for a stop that has an incorrect type.

    Attributes:
        stop_type: The incorrect type of the stop.
        service_patterns: A list of service patterns associated with the warning.
    """
    stop_type: str
    service_patterns: List[str]


@dataclass
class StopServiceLinkMissing(BaseWarning):
    """
    Represents a warning for a missing service link between two stops.

    Attributes:
        from_stop: The identifier of the starting stop of the missing link.
        to_stop: The identifier of the ending stop of the missing link.
        stops: A list of stops associated with the missing link.
        service_patterns: A list of service patterns associated with the warning.
    """
    from_stop: str
    to_stop: str
    stops: List[str]
    service_patterns: List[str]
```

from dataclasses import dataclass
from typing import List

from transit_odp.data_quality.dataclasses.warnings.base import BaseWarning


@dataclass
class StopMissingNaptan(BaseWarning):
    service_patterns: List[str]


@dataclass
class StopIncorrectType(BaseWarning):
    stop_type: str
    service_patterns: List[str]


@dataclass
class StopServiceLinkMissing(BaseWarning):
    from_stop: str
    to_stop: str
    stops: List[str]
    service_patterns: List[str]
