```python
from dataclasses import dataclass
from typing import List

@dataclass
class BaseWarning:
    """
    A base class for different types of warnings that can be issued.

    Attributes:
        id (str): A unique identifier for the warning.
        warning_type (str): A string representing the type of warning.
    """
    id: str
    warning_type: str

@dataclass
class SchemaNotTXC24(BaseWarning):
    """
    A warning indicating that the schema is not compliant with TXC24 standards.

    Inherits all attributes from BaseWarning without adding new ones.
    """
    pass

@dataclass
class IncorrectNOC(BaseWarning):
    """
    A warning indicating that there are incorrect NOC values.

    Attributes:
        nocs (List[str]): A list of NOC (National Operator Code) strings that are incorrect.
    """
    nocs: List[str]
```

from dataclasses import dataclass
from typing import List


@dataclass
class BaseWarning:
    id: str
    warning_type: str


@dataclass
class SchemaNotTXC24(BaseWarning):
    pass


@dataclass
class IncorrectNOC(BaseWarning):
    nocs: List[str]
