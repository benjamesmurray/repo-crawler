```python
from dataclasses import dataclass
from typing import List

from .base import BaseWarning

@dataclass
class LineBaseWarning(BaseWarning):
    """
    A base warning class for issues related to line-based data in a transportation system.

    Attributes:
        journeys (List[str]): A list of journey identifiers that the warning is associated with.
    """
    journeys: List[str]


@dataclass
class LineExpired(LineBaseWarning):
    """
    A warning indicating that a line has expired.
    
    Inherits all attributes from LineBaseWarning without adding any new ones.
    """
    pass


@dataclass
class LineMissingBlockID(LineBaseWarning):
    """
    A warning indicating that a line is missing a block ID.
    
    Inherits all attributes from LineBaseWarning without adding any new ones.
    """
    pass
```

from dataclasses import dataclass
from typing import List

from .base import BaseWarning


@dataclass
class LineBaseWarning(BaseWarning):
    journeys: List[str]


@dataclass
class LineExpired(LineBaseWarning):
    pass


@dataclass
class LineMissingBlockID(LineBaseWarning):
    pass
