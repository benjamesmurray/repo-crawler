```python
from dataclasses import dataclass
from typing import List

from transit_odp.data_quality.dataclasses.warnings.base import BaseWarning


@dataclass
class TimingBaseWarning(BaseWarning):
    """
    A base warning class for timing-related warnings.

    Attributes:
        none (bool): Indicates if no timings are available.
        all (bool): Indicates if all timings are affected.
        indexes (List[int]): A list of indexes of the affected timings.
    """
    none: bool
    all: bool
    indexes: List[int]


@dataclass
class TimingSpeedWarning(BaseWarning):
    """
    A warning related to the speed of timings.

    Attributes:
        indexes (List[int]): A list of indexes of the affected timings.
        entities (List[str]): A list of entities associated with the warning.
    """
    indexes: List[int]
    entities: List[str]


@dataclass
class TimingSlow(TimingSpeedWarning):
    """
    A warning indicating that the timings are slower than expected.
    """
    pass


@dataclass
class TimingFast(TimingSpeedWarning):
    """
    A warning indicating that the timings are faster than expected.
    """
    pass


@dataclass
class TimingSpeedLinkWarning(BaseWarning):
    """
    A warning related to the speed of timings between service links.

    Attributes:
        indexes (List[int]): A list of indexes of the affected timings.
        service_link (str): The service link associated with the warning.
    """
    indexes: List[int]
    service_link: str


@dataclass
class TimingFastLink(TimingSpeedLinkWarning):
    """
    A warning indicating that the timings between service links are faster than expected.
    """
    pass


@dataclass
class TimingSlowLink(TimingSpeedLinkWarning):
    """
    A warning indicating that the timings between service links are slower than expected.
    """
    pass


@dataclass
class TimingMissingPoint(BaseWarning):
    """
    A warning for when a timing point is missing.

    Attributes:
        missing_stop (str): The identifier of the missing stop.
        indexes (List[int]): A list of indexes where the timing point is missing.
    """
    missing_stop: str
    indexes: List[int]


@dataclass
class TimingMissingPoint15(TimingMissingPoint):
    """
    A specific warning for when a timing point is missing, specific to a certain standard.
    """
    pass


@dataclass
class TimingBackwards(TimingBaseWarning):
    """
    A warning for when timings appear to be going backwards.
    """
    pass


@dataclass
class TimingPickUp(TimingBaseWarning):
    """
    A warning for when there are issues with pick-up timings.
    """
    pass


@dataclass
class TimingDropOff(TimingBaseWarning):
    """
    A warning for when there are issues with drop-off timings.
    """
    pass


@dataclass
class TimingMultiple(TimingBaseWarning):
    """
    A warning for when multiple timing issues are detected.
    """
    pass


@dataclass
class TimingNone(TimingBaseWarning):
    """
    A warning for when no timing information is provided.
    """
    pass


@dataclass
class TimingFirst(TimingBaseWarning):
    """
    A warning for when the first timing is affected.
    """
    pass


@dataclass
class TimingLast(TimingBaseWarning):
    """
    A warning for when the last timing is affected.
    """
    pass
```

from dataclasses import dataclass
from typing import List

from transit_odp.data_quality.dataclasses.warnings.base import BaseWarning


@dataclass
class TimingBaseWarning(BaseWarning):
    none: bool
    all: bool
    indexes: List[int]


@dataclass
class TimingSpeedWarning(BaseWarning):
    indexes: List[int]
    entities: List[str]


@dataclass
class TimingSlow(TimingSpeedWarning):
    pass


@dataclass
class TimingFast(TimingSpeedWarning):
    pass


@dataclass
class TimingSpeedLinkWarning(BaseWarning):
    indexes: List[int]
    service_link: str


@dataclass
class TimingFastLink(TimingSpeedLinkWarning):
    pass


@dataclass
class TimingSlowLink(TimingSpeedLinkWarning):
    pass


@dataclass
class TimingMissingPoint(BaseWarning):
    missing_stop: str
    indexes: List[int]


@dataclass
class TimingMissingPoint15(TimingMissingPoint):
    pass


@dataclass
class TimingBackwards(TimingBaseWarning):
    pass


@dataclass
class TimingPickUp(TimingBaseWarning):
    pass


@dataclass
class TimingDropOff(TimingBaseWarning):
    pass


@dataclass
class TimingMultiple(TimingBaseWarning):
    pass


@dataclass
class TimingNone(TimingBaseWarning):
    pass


@dataclass
class TimingFirst(TimingBaseWarning):
    pass


@dataclass
class TimingLast(TimingBaseWarning):
    pass
