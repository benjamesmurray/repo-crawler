```python
from dataclasses import dataclass
from typing import List

from transit_odp.data_quality.dataclasses.warnings.base import BaseWarning

@dataclass
class JourneyInappropriateStop(BaseWarning):
    """
    Warning for when a journey includes a stop that is deemed inappropriate for the journey's stop type.
    
    Attributes:
        stop_type: A string indicating the type of the stop that is inappropriate.
        vehicle_journeys: A list of strings representing the vehicle journeys that include the inappropriate stop.
    """
    stop_type: str
    vehicle_journeys: List[str]


@dataclass
class JourneyStopVariant(BaseWarning):
    """
    Warning for when a journey includes a variant of a stop.
    
    Attributes:
        vehicle_journeys: A list of strings representing the vehicle journeys that include the stop variant.
    """
    vehicle_journeys: List[str]


@dataclass
class JourneysWithoutHeadsign(BaseWarning):
    """
    Warning for journeys that do not have a headsign.
    """
    pass


@dataclass
class JourneyBackwardsDateRange(BaseWarning):
    """
    Warning for when a journey's date range is backwards, indicating the start date is after the end date.
    
    Attributes:
        start: A string representing the start date of the journey.
        end: A string representing the end date of the journey.
    """
    start: str
    end: str


@dataclass
class JourneyDuplicate(BaseWarning):
    """
    Warning for when a journey is identified as a duplicate of another journey.
    
    Attributes:
        duplicate: A string identifying the duplicate journey.
    """
    duplicate: str


@dataclass
class JourneyConflict(BaseWarning):
    """
    Warning for when there is a conflict in a journey's scheduling or routing.
    
    Attributes:
        conflict: A string describing the nature of the conflict.
        stops: A list of strings representing the stops involved in the conflict.
    """
    conflict: str
    stops: List[str]


@dataclass
class JourneyPartialTimingOverlap(BaseWarning):
    """
    Warning for when there is a partial timing overlap in a journey's schedule.
    
    Attributes:
        conflict: A string describing the nature of the timing overlap.
        stops: A list of strings representing the stops involved in the timing overlap.
    """
    conflict: str
    stops: List[str]
```

from dataclasses import dataclass
from typing import List

from transit_odp.data_quality.dataclasses.warnings.base import BaseWarning


@dataclass
class JourneyInappropriateStop(BaseWarning):
    stop_type: str
    vehicle_journeys: List[str]


@dataclass
class JourneyStopVariant(BaseWarning):
    vehicle_journeys: List[str]


@dataclass
class JourneysWithoutHeadsign(BaseWarning):
    pass


@dataclass
class JourneyBackwardsDateRange(BaseWarning):
    start: str
    end: str


@dataclass
class JourneyDuplicate(BaseWarning):
    duplicate: str


@dataclass
class JourneyConflict(BaseWarning):
    conflict: str
    stops: List[str]


@dataclass
class JourneyPartialTimingOverlap(BaseWarning):
    conflict: str
    stops: List[str]
