```python
from django.conf import settings
from django.template.defaultfilters import date
from django.utils import timezone

# Tuple containing string identifiers for operation and non-operation days.
OPERATION_DAYS = ("DaysOfOperation", "DaysOfNonOperation")

# List of standard bank holidays in the UK.
BANK_HOLIDAYS = [
    "ChristmasEve",
    "NewYearsEve",
    "ChristmasDay",
    "ChristmasDayHoliday",
    "BoxingDay",
    "BoxingDayHoliday",
    "NewYearsDay",
    "NewYearsDayHoliday",
    "GoodFriday",
    "EasterMonday",
    "MayDay",
    "SpringBank",
    "LateSummerBankHolidayNotScotland",
]

# List of bank holidays specific to Scotland.
SCOTTISH_BANK_HOLIDAYS = [
    "StAndrewsDay",
    "StAndrewsDayHoliday",
    "Jan2ndScotland",
    "Jan2ndScotlandHoliday",
    "AugustBankHolidayScotland",
]

# List of other public holidays.
OTHER_PUBLIC_HOLIDAYS = ["OtherPublicHoliday"]

def get_important_note():
    """
    Retrieve an important note about data rejection based on PTI enforced date.
    
    Returns:
        A string containing the important note if the PTI enforced date is in the future,
        otherwise an empty string.
    """
    pti_enforced_date = settings.PTI_ENFORCED_DATE
    if pti_enforced_date.date() > timezone.localdate():
        important_note = (
            "Data containing this observation will be rejected by "
            f'BODS after {date(pti_enforced_date, "jS F, Y")}'
        )
    else:
        important_note = ""

    return important_note

# Reference URL to the PTI PDF document.
REF_URL = settings.PTI_PDF_URL

# Prefix for referencing a section in the BODS PTI profile document.
REF_PREFIX = "Please refer to section "

# Suffix for referencing a section in the BODS PTI profile document.
REF_SUFFIX = " in the BODS PTI profile v1.1 document: "

# String to be used when no specific section reference is provided.
NO_REF = "Please refer to the BODS PTI profile v1.1 document: "

# String identifier for a flexible service.
FLEXIBLE_SERVICE = "FlexibleService"

# String identifier for a standard service.
STANDARD_SERVICE = "StandardService"
```

from django.conf import settings
from django.template.defaultfilters import date
from django.utils import timezone

OPERATION_DAYS = ("DaysOfOperation", "DaysOfNonOperation")
BANK_HOLIDAYS = [
    "ChristmasEve",
    "NewYearsEve",
    "ChristmasDay",
    "ChristmasDayHoliday",
    "BoxingDay",
    "BoxingDayHoliday",
    "NewYearsDay",
    "NewYearsDayHoliday",
    "GoodFriday",
    "EasterMonday",
    "MayDay",
    "SpringBank",
    "LateSummerBankHolidayNotScotland",
]
SCOTTISH_BANK_HOLIDAYS = [
    "StAndrewsDay",
    "StAndrewsDayHoliday",
    "Jan2ndScotland",
    "Jan2ndScotlandHoliday",
    "AugustBankHolidayScotland",
]
OTHER_PUBLIC_HOLIDAYS = ["OtherPublicHoliday"]


def get_important_note():
    pti_enforced_date = settings.PTI_ENFORCED_DATE
    if pti_enforced_date.date() > timezone.localdate():
        important_note = (
            "Data containing this observation will be rejected by "
            f'BODS after {date(pti_enforced_date, "jS F, Y")}'
        )
    else:
        important_note = ""

    return important_note


REF_URL = settings.PTI_PDF_URL
REF_PREFIX = "Please refer to section "
REF_SUFFIX = " in the BODS PTI profile v1.1 document: "
NO_REF = "Please refer to the BODS PTI profile v1.1 document: "

FLEXIBLE_SERVICE = "FlexibleService"
STANDARD_SERVICE = "StandardService"
