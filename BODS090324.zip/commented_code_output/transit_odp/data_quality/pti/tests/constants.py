```python
# XML header constants for the TransXChange document format
TXC_START = (
    """<?xml version="1.0" encoding="UTF-8"?>"""
    """<TransXChange xmlns="http://www.transxchange.org.uk/" """
    """xml:lang="en" SchemaVersion="2.4">"""
    )
"""
This constant represents the start of a TransXChange XML document, which includes the XML declaration 
and the opening tag of the TransXChange element with necessary attributes such as the XML namespace, 
language, and schema version.
"""

TXC_END = "</TransXChange>"
"""
This constant represents the end of a TransXChange XML document, which is the closing tag of the 
TransXChange element.
"""
```

TXC_START = (
    """<?xml version="1.0" encoding="UTF-8"?>"""
    """<TransXChange xmlns="http://www.transxchange.org.uk/" """
    """xml:lang="en" SchemaVersion="2.4">"""
)
TXC_END = "</TransXChange>"
