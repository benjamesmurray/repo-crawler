```python
from django.apps import AppConfig

class DataQualityConfig(AppConfig):
    """Django application configuration for the data quality app.

    This class configures the data quality application within a Django project.
    It sets the name of the application, which is used by Django to identify it.

    Attributes:
        name (str): The name of the application.
    """
    name = "transit_odp.data_quality"
```

from django.apps import AppConfig


class DataQualityConfig(AppConfig):
    name = "transit_odp.data_quality"
