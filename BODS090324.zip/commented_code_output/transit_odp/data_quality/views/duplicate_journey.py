```python
from transit_odp.data_quality.constants import DuplicateJourneyObservation
from transit_odp.data_quality.models.warnings import JourneyDuplicateWarning
from transit_odp.data_quality.tables import DuplicateJourneyWarningTimingTable
from transit_odp.data_quality.tables.duplicate_journey import DuplicateJourneyListTable
from transit_odp.data_quality.views.base import JourneyListBaseView, OneTableDetailView

class DuplicateJourneyListView(JourneyListBaseView):
    """
    A view that lists duplicate journey warnings.

    Attributes:
        data: Holds the constants related to the DuplicateJourneyObservation.
        model: The model associated with journey duplicate warnings.
        table_class: The table used to render the duplicate journey list.
    """
    data = DuplicateJourneyObservation
    model = JourneyDuplicateWarning
    table_class = DuplicateJourneyListTable

    def get_queryset(self):
        """
        Enhances the base queryset with additional information needed for the view.
        
        Returns:
            A queryset that includes messages, line information, and deduplication applied.
        """
        return super().get_queryset().add_message().add_line().apply_deduplication()

    def get_context_data(self, **kwargs):
        """
        Adds additional context for the duplicate journey list view.

        Args:
            **kwargs: Keyword arguments from the base context.

        Returns:
            The updated context dictionary.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": "The following duplicate journeys have been observed.",
            }
        )
        return context


class DuplicateJourneyDetailView(OneTableDetailView):
    """
    A detailed view for a specific duplicate journey warning.

    Attributes:
        data: Holds the constants related to the DuplicateJourneyObservation.
        model: The model associated with journey duplicate warnings.
        tables: A list containing the table used to render the duplicate journey detail.
    """
    data = DuplicateJourneyObservation
    model = JourneyDuplicateWarning
    tables = [DuplicateJourneyWarningTimingTable]

    def get_context_data(self, **kwargs):
        """
        Adds additional context for the duplicate journey detail view.

        Args:
            **kwargs: Keyword arguments from the base context.

        Returns:
            The updated context dictionary with an added subtitle.
        """
        kwargs.update({"subtitle_end": "is duplicated"})
        context = super().get_context_data(**kwargs)
        return context
```

from transit_odp.data_quality.constants import DuplicateJourneyObservation
from transit_odp.data_quality.models.warnings import JourneyDuplicateWarning
from transit_odp.data_quality.tables import DuplicateJourneyWarningTimingTable
from transit_odp.data_quality.tables.duplicate_journey import DuplicateJourneyListTable
from transit_odp.data_quality.views.base import JourneyListBaseView, OneTableDetailView


class DuplicateJourneyListView(JourneyListBaseView):
    data = DuplicateJourneyObservation
    model = JourneyDuplicateWarning
    table_class = DuplicateJourneyListTable

    def get_queryset(self):
        return super().get_queryset().add_message().add_line().apply_deduplication()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": "The following duplicate journeys have been observed.",
            }
        )
        return context


class DuplicateJourneyDetailView(OneTableDetailView):
    data = DuplicateJourneyObservation
    model = JourneyDuplicateWarning
    # awkward to have a MultiTableView with only one table,
    # but maintains similarity with other detail views
    tables = [DuplicateJourneyWarningTimingTable]

    def get_context_data(self, **kwargs):
        kwargs.update({"subtitle_end": "is duplicated"})
        context = super().get_context_data(**kwargs)
        return context
