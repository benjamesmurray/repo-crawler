```python
from django.db.models import F

from transit_odp.data_quality.constants import IncorrectStopTypeObservation
from transit_odp.data_quality.models.warnings import JourneyStopInappropriateWarning
from transit_odp.data_quality.tables import (
    StopIncorrectTypeListTable,
    StopIncorrectTypeWarningTimingTable,
    StopIncorrectTypeWarningVehicleTable,
)
from transit_odp.data_quality.views.base import JourneyListBaseView, TwoTableDetailView


class IncorrectStopTypeListView(JourneyListBaseView):
    """
    A view that lists journeys with inappropriate stop types.
    
    Attributes:
        data: The observation data related to incorrect stop types.
        model: The model associated with the journey stop warnings.
        table_class: The class defining how the list table should be rendered.
    """
    data = IncorrectStopTypeObservation
    model = JourneyStopInappropriateWarning
    table_class = StopIncorrectTypeListTable

    def get_queryset(self):
        """
        Returns a queryset annotated with line and message data for the stops.
        """
        return super().get_queryset().add_line().add_message()

    def get_context_data(self, **kwargs):
        """
        Returns the context data for the template to render the list view.
        
        Extends the base context with title, definition, preamble, and extra_info.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have incorrect "
                    "stop type."
                ),
                "extra_info": self.data.extra_info,
            }
        )
        return context


class IncorrectStopTypeDetailView(TwoTableDetailView):
    """
    A detailed view that provides information about a specific warning related to 
    incorrect stop types, using two tables for display.
    
    Attributes:
        data: The observation data related to incorrect stop types.
        model: The model associated with the journey stop warnings.
        tables: A list of table classes defining how the detail tables should be rendered.
    """
    data = IncorrectStopTypeObservation
    model = JourneyStopInappropriateWarning
    tables = [StopIncorrectTypeWarningTimingTable, StopIncorrectTypeWarningVehicleTable]

    def get_queryset1(self):
        """
        Returns a queryset for the first table, annotating each item with the stop type.
        """
        stops_with_name_and_position = super().get_queryset1()
        # TODO: add as queryset method?
        return stops_with_name_and_position.annotate(
            stop_type=F("service_pattern_stop__stop__type")
        )

    def get_table1_kwargs(self):
        """
        Returns keyword arguments for the first table, including a custom warning message.
        
        The warning message is constructed using the stop's name and type.
        """
        kwargs = super().get_table1_kwargs()
        stop = self.warning.stop
        stop_type = self.warning.stop_type
        kwargs[
            "warning_message"
        ] = f"Journeys are using {stop.name} of type {stop_type}"
        return kwargs

    def get_context_data(self, **kwargs):
        """
        Returns the context data for the template to render the detailed view.
        
        Extends the base context with a title and subtitle that includes the service name,
        stop name, and stop type.
        """
        context = super().get_context_data(**kwargs)
        warning = self.warning
        stop = warning.stop
        stop_type = warning.stop_type
        # TODO: add get_service_name method to one of the parent models?
        service_name = warning.get_timing_pattern().service_pattern.service.name

        context["title"] = self.data.title
        context[
            "subtitle"
        ] = f'Line {service_name} Uses stop {stop.name} of type "{stop_type}"'
        return context
```

from django.db.models import F

from transit_odp.data_quality.constants import IncorrectStopTypeObservation
from transit_odp.data_quality.models.warnings import JourneyStopInappropriateWarning
from transit_odp.data_quality.tables import (
    StopIncorrectTypeListTable,
    StopIncorrectTypeWarningTimingTable,
    StopIncorrectTypeWarningVehicleTable,
)
from transit_odp.data_quality.views.base import JourneyListBaseView, TwoTableDetailView


class IncorrectStopTypeListView(JourneyListBaseView):
    data = IncorrectStopTypeObservation
    model = JourneyStopInappropriateWarning
    table_class = StopIncorrectTypeListTable

    def get_queryset(self):
        return super().get_queryset().add_line().add_message()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have incorrect "
                    "stop type."
                ),
                "extra_info": self.data.extra_info,
            }
        )
        return context


class IncorrectStopTypeDetailView(TwoTableDetailView):
    data = IncorrectStopTypeObservation
    model = JourneyStopInappropriateWarning
    tables = [StopIncorrectTypeWarningTimingTable, StopIncorrectTypeWarningVehicleTable]

    def get_queryset1(self):
        stops_with_name_and_position = super().get_queryset1()
        # TODO: add as queryset method?
        return stops_with_name_and_position.annotate(
            stop_type=F("service_pattern_stop__stop__type")
        )

    def get_table1_kwargs(self):
        kwargs = super().get_table1_kwargs()
        stop = self.warning.stop
        stop_type = self.warning.stop_type
        kwargs[
            "warning_message"
        ] = f"Journeys are using {stop.name} of type {stop_type}"
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        warning = self.warning
        stop = warning.stop
        stop_type = warning.stop_type
        # TODO: add get_service_name method to one of the parent models?
        service_name = warning.get_timing_pattern().service_pattern.service.name

        context["title"] = self.data.title
        context[
            "subtitle"
        ] = f'Line {service_name} Uses stop {stop.name} of type "{stop_type}"'
        return context
