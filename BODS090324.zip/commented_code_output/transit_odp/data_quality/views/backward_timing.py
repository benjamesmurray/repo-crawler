```python
from transit_odp.data_quality import constants
from transit_odp.data_quality.tables import (
    BackwardTimingsListTable,
    BackwardTimingsWarningTable,
    BackwardTimingVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)

class BackwardTimingListView(TimingPatternsListBaseView):
    """
    A view that lists timing patterns with backward timings, extending the base view.

    Attributes:
        data: A constant holding configuration data for the view.
        model: The model associated with the backward timings.
        table_class: The class used to render the table of backward timing patterns.
    """
    data = constants.BackwardsTimingObservation
    model = data.model
    table_class = BackwardTimingsListTable

    def get_context_data(self, **kwargs):
        """
        Extends the base context data with the title, definition, and preamble.

        Parameters:
            **kwargs: Keyword arguments passed to the base method.

        Returns:
            A dictionary containing context data for the view.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have backwards "
                    "timing."
                ),
            }
        )
        return context


class BackwardTimingDetailView(TwoTableDetailView):
    """
    A detailed view for a specific instance of backward timing, showing related tables.

    Attributes:
        data: A constant holding configuration data for the view.
        model: The model associated with the backward timings.
        tables: A list of table classes used to render the detailed information.
    """
    data = constants.BackwardsTimingObservation
    model = data.model
    tables = [BackwardTimingsWarningTable, BackwardTimingVehicleTable]

    def get_context_data(self, **kwargs):
        """
        Extends the base context data with a title and subtitle specific to the detail view.

        Parameters:
            **kwargs: Keyword arguments passed to the base method.

        Returns:
            A dictionary containing context data for the view.
        """
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context
```

from transit_odp.data_quality import constants
from transit_odp.data_quality.tables import (
    BackwardTimingsListTable,
    BackwardTimingsWarningTable,
    BackwardTimingVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)


class BackwardTimingListView(TimingPatternsListBaseView):
    data = constants.BackwardsTimingObservation
    model = data.model
    table_class = BackwardTimingsListTable

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have backwards "
                    "timing."
                ),
            }
        )
        return context


class BackwardTimingDetailView(TwoTableDetailView):
    data = constants.BackwardsTimingObservation
    model = data.model
    tables = [BackwardTimingsWarningTable, BackwardTimingVehicleTable]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context
