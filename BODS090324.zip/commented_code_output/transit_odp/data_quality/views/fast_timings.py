```python
from transit_odp.data_quality.constants import FastTimingPointObservation
from transit_odp.data_quality.models.warnings import FastTimingWarning
from transit_odp.data_quality.tables.fast_timings import (
    FastTimingWarningTimingTable,
    FastTimingWarningVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)

class FastTimingDetailView(TwoTableDetailView):
    """
    A detailed view for Fast Timing warnings that uses two tables to display data.

    Attributes:
        data: A constant that contains metadata about the FastTimingPointObservation.
        model: The model associated with Fast Timing warnings.
        tables: A list of tables used to present warning details.
    """
    data = FastTimingPointObservation
    model = FastTimingWarning
    tables = [FastTimingWarningTimingTable, FastTimingWarningVehicleTable]

    def get_context_data(self, **kwargs):
        """
        Extends the base context with a title and subtitle for the view.

        Args:
            **kwargs: Keyword arguments passed to the base implementation.

        Returns:
            A dictionary containing context data for this view.
        """
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context


class FastTimingListView(TimingPatternsListBaseView):
    """
    A list view for Fast Timing warnings that provides additional context data.

    Attributes:
        data: A constant that contains metadata about the FastTimingPointObservation.
        model: The model associated with Fast Timing warnings.
    """
    data = FastTimingPointObservation
    model = FastTimingWarning

    def get_queryset(self):
        """
        Retrieves the queryset for the view, with additional line and message annotations.

        Returns:
            A queryset annotated with line and message information.
        """
        return super().get_queryset().add_line().add_message()

    def get_context_data(self, **kwargs):
        """
        Extends the base context with a title, definition, and preamble for the view.

        Args:
            **kwargs: Keyword arguments passed to the base implementation.

        Returns:
            A dictionary containing context data for this view.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have "
                    "fast timing links."
                ),
            }
        )
        return context
```

from transit_odp.data_quality.constants import FastTimingPointObservation
from transit_odp.data_quality.models.warnings import FastTimingWarning
from transit_odp.data_quality.tables.fast_timings import (
    FastTimingWarningTimingTable,
    FastTimingWarningVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)


class FastTimingDetailView(TwoTableDetailView):
    data = FastTimingPointObservation
    model = FastTimingWarning
    tables = [FastTimingWarningTimingTable, FastTimingWarningVehicleTable]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context


class FastTimingListView(TimingPatternsListBaseView):
    data = FastTimingPointObservation
    model = FastTimingWarning

    def get_queryset(self):
        return super().get_queryset().add_line().add_message()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have "
                    "fast timing links."
                ),
            }
        )
        return context
