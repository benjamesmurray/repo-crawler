```python
from transit_odp.data_quality.constants import NoTimingPointFor15MinutesObservation
from transit_odp.data_quality.models.warnings import TimingMissingPointWarning
from transit_odp.data_quality.tables import (
    MissingStopWarningDetailTable,
    MissingStopWarningVehicleTable,
)
from transit_odp.data_quality.tables.base import TimingPatternListTable
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)

class MissingStopListView(TimingPatternsListBaseView):
    """
    View for listing timing patterns with missing stops.
    
    Attributes:
        data: A constant that defines the observation being checked.
        model: The model associated with the warning for missing timing points.
        table_class: The class used to render the timing pattern list table.
    """
    data = NoTimingPointFor15MinutesObservation
    model = TimingMissingPointWarning
    table_class = TimingPatternListTable

    def get_queryset(self):
        """
        Returns the queryset for the view after applying select_related and custom methods.
        
        Extends the base queryset to include related service information and additional
        annotations for message and line.
        """
        return (
            super()
            .get_queryset()
            .select_related("timing_pattern__service_pattern__service")
            .add_message()
            .add_line()
        )

    def get_context_data(self, **kwargs):
        """
        Adds additional context data to the view.

        Args:
            **kwargs: Keyword arguments that are passed to the base implementation.
        
        Returns:
            A dictionary containing context data for the view.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to "
                    "have timing point(s) missing."
                ),
                "observation": self.data,
            }
        )
        return context


class MissingStopDetailView(TwoTableDetailView):
    """
    Detailed view for a specific instance of the missing stop warning.
    
    Attributes:
        data: A constant that defines the observation being checked.
        model: The model associated with the warning for missing timing points.
        tables: A list of table classes used to render the detail and vehicle tables.
    """
    data = NoTimingPointFor15MinutesObservation
    model = TimingMissingPointWarning
    tables = [MissingStopWarningDetailTable, MissingStopWarningVehicleTable]

    def get_context_data(self, **kwargs):
        """
        Adds additional context data to the detailed view.

        Args:
            **kwargs: Keyword arguments that are passed to the base implementation.
        
        Returns:
            A dictionary containing context data for the detailed view.
        """
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context
```

from transit_odp.data_quality.constants import NoTimingPointFor15MinutesObservation
from transit_odp.data_quality.models.warnings import TimingMissingPointWarning
from transit_odp.data_quality.tables import (
    MissingStopWarningDetailTable,
    MissingStopWarningVehicleTable,
)
from transit_odp.data_quality.tables.base import TimingPatternListTable
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)


class MissingStopListView(TimingPatternsListBaseView):
    data = NoTimingPointFor15MinutesObservation
    model = TimingMissingPointWarning
    table_class = TimingPatternListTable

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .select_related("timing_pattern__service_pattern__service")
            .add_message()
            .add_line()
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to "
                    "have timing point(s) missing."
                ),
                "observation": self.data,
            }
        )
        return context


class MissingStopDetailView(TwoTableDetailView):
    data = NoTimingPointFor15MinutesObservation
    model = TimingMissingPointWarning
    tables = [MissingStopWarningDetailTable, MissingStopWarningVehicleTable]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context
