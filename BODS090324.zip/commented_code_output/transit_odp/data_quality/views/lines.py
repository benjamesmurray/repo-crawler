```python
from django.views.generic.detail import DetailView
from django_hosts import reverse

import config
from transit_odp.data_quality.constants import ExpiredLines, MissingBlockNumber
from transit_odp.data_quality.models.warnings import (
    LineExpiredWarning,
    LineMissingBlockIDWarning,
)
from transit_odp.data_quality.tables.base import JourneyLineListTable
from transit_odp.data_quality.tables.lines import (
    LineExpiredListTable,
    LineWarningDetailTable,
)
from transit_odp.data_quality.views.base import JourneyListBaseView


class LineExpiredListView(JourneyListBaseView):
    """
    A view that lists expired lines warnings.

    Attributes:
        data: Contains constants related to expired lines.
        model: The model associated with the expired lines warning.
        table_class: The table used to render expired lines warning data.
    """
    data = ExpiredLines
    model = LineExpiredWarning
    table_class = LineExpiredListTable

    def get_queryset(self):
        """Extends the base queryset with additional fields related to lines and messages."""
        return super().get_queryset().add_line().add_message()

    def get_context_data(self, **kwargs):
        """Adds title and definition to the context data for rendering."""
        context = super().get_context_data(**kwargs)
        context.update({"title": self.data.title, "definition": self.data.text})
        return context


class LineMissingBlockIDListView(JourneyListBaseView):
    """
    A view that lists missing block ID warnings for lines.

    Attributes:
        data: Contains constants related to missing block numbers.
        model: The model associated with the missing block ID warning.
        table_class: The table used to render journey line list data.
    """
    data = MissingBlockNumber
    model = LineMissingBlockIDWarning
    table_class = JourneyLineListTable

    def get_queryset(self):
        """
        Extends the base queryset with additional fields related to lines and messages,
        and orders the results by line.
        """
        return super().get_queryset().add_line().add_message().order_by("line")

    def get_context_data(self, **kwargs):
        """Adds title and definition to the context data for rendering."""
        context = super().get_context_data(**kwargs)
        context.update({"title": self.data.title, "definition": self.data.text})
        return context


class LineMissingBlockIDDetailView(DetailView):
    """
    A detailed view for a specific missing block ID warning.
    
    Attributes:
        template_name: Specifies the path to the template used for rendering the detail view.
        pk_url_kwarg: The name of the URL keyword argument that contains the primary key.
    """
    template_name = "data_quality/line_detail.html"
    pk_url_kwarg = "warning_pk"

    def get_queryset(self):
        """Filters the queryset based on the report ID passed via URL kwargs."""
        report_id = self.kwargs.get("report_id")
        return LineMissingBlockIDWarning.objects.filter(report_id=report_id)

    def get_context_data(self, **kwargs):
        """Adds specific context data for rendering the detail view of a missing block ID warning."""
        context = super().get_context_data(**kwargs)

        timing_pattern = self.object.vehicle_journeys.first().timing_pattern
        journeys = (
            self.object.vehicle_journeys.all()
            .add_first_date()
            .add_line_name()
            .add_first_stop()
        )

        table = LineWarningDetailTable(journeys)
        table.paginate(page=self.request.GET.get("page", 1), per_page=10)

        api_url = reverse("dq-api:api-root", host=config.hosts.PUBLISH_HOST)
        back_url = reverse(
            MissingBlockNumber.list_url_name,
            kwargs={
                "pk": self.kwargs.get("pk"),
                "pk1": self.kwargs.get("pk1"),
                "report_id": self.kwargs.get("report_id"),
            },
            host=config.hosts.PUBLISH_HOST,
        )

        context.update(
            {
                "title": MissingBlockNumber.title,
                "subtitle": (
                    f"Line {self.object.service.name} has at least one journey "
                    "which has missing Block Number(s)"
                ),
                "api_root": api_url,
                "back_url": back_url,
                "table": table,
                "report_date": self.object.report.created,
                "service_pattern_id": timing_pattern.service_pattern_id,
                "service_link_id": "",
                "stop_ids": "",
                "affected_stop_ids": "",
            }
        )
        return context
```

from django.views.generic.detail import DetailView
from django_hosts import reverse

import config
from transit_odp.data_quality.constants import ExpiredLines, MissingBlockNumber
from transit_odp.data_quality.models.warnings import (
    LineExpiredWarning,
    LineMissingBlockIDWarning,
)
from transit_odp.data_quality.tables.base import JourneyLineListTable
from transit_odp.data_quality.tables.lines import (
    LineExpiredListTable,
    LineWarningDetailTable,
)
from transit_odp.data_quality.views.base import JourneyListBaseView


class LineExpiredListView(JourneyListBaseView):
    data = ExpiredLines
    model = LineExpiredWarning
    table_class = LineExpiredListTable

    def get_queryset(self):
        return super().get_queryset().add_line().add_message()

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({"title": self.data.title, "definition": self.data.text})
        return context


class LineMissingBlockIDListView(JourneyListBaseView):
    data = MissingBlockNumber
    model = LineMissingBlockIDWarning
    table_class = JourneyLineListTable

    def get_queryset(self):
        return super().get_queryset().add_line().add_message().order_by("line")

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({"title": self.data.title, "definition": self.data.text})
        return context


class LineMissingBlockIDDetailView(DetailView):
    template_name = "data_quality/line_detail.html"
    pk_url_kwarg = "warning_pk"

    def get_queryset(self):
        report_id = self.kwargs.get("report_id")
        return LineMissingBlockIDWarning.objects.filter(report_id=report_id)

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)

        timing_pattern = self.object.vehicle_journeys.first().timing_pattern
        journeys = (
            self.object.vehicle_journeys.all()
            .add_first_date()
            .add_line_name()
            .add_first_stop()
        )

        table = LineWarningDetailTable(journeys)
        table.paginate(page=self.request.GET.get("page", 1), per_page=10)

        api_url = reverse("dq-api:api-root", host=config.hosts.PUBLISH_HOST)
        back_url = reverse(
            MissingBlockNumber.list_url_name,
            kwargs={
                "pk": self.kwargs.get("pk"),
                "pk1": self.kwargs.get("pk1"),
                "report_id": self.kwargs.get("report_id"),
            },
            host=config.hosts.PUBLISH_HOST,
        )

        context.update(
            {
                "title": MissingBlockNumber.title,
                "subtitle": (
                    f"Line {self.object.service.name} has at least one journey "
                    "which has missing Block Number(s)"
                ),
                "api_root": api_url,
                "back_url": back_url,
                "table": table,
                "report_date": self.object.report.created,
                "service_pattern_id": timing_pattern.service_pattern_id,
                "service_link_id": "",
                "stop_ids": "",
                "affected_stop_ids": "",
            }
        )
        return context
