```python
from transit_odp.data_quality.constants import IncorrectNocObservation
from transit_odp.data_quality.models.warnings import IncorrectNOCWarning
from transit_odp.data_quality.tables.incorrect_noc import IncorrectNOCListTable
from transit_odp.data_quality.views.base import WarningListBaseView

class IncorrectNOCListView(WarningListBaseView):
    """
    A view that lists incorrect National Operator Codes (NOCs) warnings.
    
    Attributes:
        data: A reference to the IncorrectNocObservation containing metadata.
        model: The IncorrectNOCWarning model that the view will interact with.
        table_class: The IncorrectNOCListTable class used to render the table.
    """
    
    data = IncorrectNocObservation
    model = IncorrectNOCWarning
    table_class = IncorrectNOCListTable

    def get_queryset(self):
        """
        Extends the base queryset to include a message for each incorrect NOC entry.
        
        Returns:
            A queryset that is extended with a message for each entry.
        """
        qs = super().get_queryset()
        return qs.add_message()

    def get_table_kwargs(self):
        """
        Extends the table keyword arguments with a verbose name for the message column.
        
        Returns:
            A dictionary containing updated keyword arguments for the table.
        """
        kwargs = super().get_table_kwargs()
        kwargs.update({"message_col_verbose_name": "Summary"})
        return kwargs

    def get_context_data(self, **kwargs):
        """
        Extends the context data with title, definition, and preamble for the view.
        
        Returns:
            A dictionary containing the context data for the view.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "The following data sets have been observed to have incorrect "
                    "national operator code(s)."
                ),
            }
        )
        return context
```

from transit_odp.data_quality.constants import IncorrectNocObservation
from transit_odp.data_quality.models.warnings import IncorrectNOCWarning
from transit_odp.data_quality.tables.incorrect_noc import IncorrectNOCListTable
from transit_odp.data_quality.views.base import WarningListBaseView


class IncorrectNOCListView(WarningListBaseView):
    data = IncorrectNocObservation
    model = IncorrectNOCWarning
    table_class = IncorrectNOCListTable

    def get_queryset(self):
        qs = super().get_queryset()
        return qs.add_message()

    def get_table_kwargs(self):
        kwargs = super().get_table_kwargs()
        kwargs.update({"message_col_verbose_name": "Summary"})
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "The following data sets have been observed to have incorrect "
                    "national operator code(s)."
                ),
            }
        )
        return context
