```python
from transit_odp.data_quality.constants import StopNotInNaptanObservation
from transit_odp.data_quality.models.warnings import StopMissingNaptanWarning
from transit_odp.data_quality.tables import (
    StopMissingNaptanListTable,
    StopMissingNaptanWarningTimingTable,
    StopMissingNaptanWarningVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)


class StopMissingNaptanListView(TimingPatternsListBaseView):
    """
    A view that lists timing patterns with stops that are not in the National Public
    Transport Access Nodes (NaPTAN) database.

    Attributes:
        data: The observation data related to stops not being in NaPTAN.
        model: The warning model associated with missing NaPTAN stops.
        table_class: The table class used to render the list of timing patterns.
    """
    data = StopNotInNaptanObservation
    model = StopMissingNaptanWarning
    table_class = StopMissingNaptanListTable

    def get_queryset(self):
        """
        Retrieves a queryset of warnings with service patterns that exclude null
        service patterns and include additional message and line information.

        Returns:
            A queryset of StopMissingNaptanWarning instances.
        """
        # The synthetic stop can appear in multiple service patterns, here we just pick
        # an arbitrary service pattern to help the user.
        return (
            super()
            .get_queryset()
            .exclude_null_service_patterns()
            .add_message()
            .add_line()
        )

    def get_context_data(self, **kwargs):
        """
        Builds the context data for the template rendering.

        Args:
            **kwargs: Keyword arguments.

        Returns:
            A dictionary containing context data for the view.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "The following timing pattern(s) have been observed to have stops "
                    "that are not in NaPTAN."
                ),
            }
        )
        return context


class StopMissingNaptanDetailView(TwoTableDetailView):
    """
    A detailed view that shows specific information about a stop that is missing
    from the NaPTAN database.

    Attributes:
        data: The observation data related to stops not being in NaPTAN.
        model: The warning model associated with missing NaPTAN stops.
        tables: A list of table classes used to render the detailed information about
                the warning.
    """
    data = StopNotInNaptanObservation
    model = StopMissingNaptanWarning
    tables = [StopMissingNaptanWarningTimingTable, StopMissingNaptanWarningVehicleTable]

    def get_table1_kwargs(self):
        """
        Retrieves additional keyword arguments for the first table rendering.

        Returns:
            A dictionary of keyword arguments for the first table.
        """
        kwargs = super().get_table1_kwargs()
        stop = self.warning.stop
        kwargs[
            "warning_message"
        ] = f"Synthetic stop(s) ({stop.atco_code}) not found in NaPTAN."
        return kwargs

    def get_context_data(self, **kwargs):
        """
        Builds the context data for the template rendering.

        Args:
            **kwargs: Keyword arguments.

        Returns:
            A dictionary containing context data for the detailed view.
        """
        context = super().get_context_data(**kwargs)
        service_name = self.warning.get_service_pattern().service.name

        context["title"] = self.data.title
        context["subtitle"] = (
            f"Line {service_name} has at least one journey where stop(s) are not in "
            f"NaPTAN"
        )
        return context
```

from transit_odp.data_quality.constants import StopNotInNaptanObservation
from transit_odp.data_quality.models.warnings import StopMissingNaptanWarning
from transit_odp.data_quality.tables import (
    StopMissingNaptanListTable,
    StopMissingNaptanWarningTimingTable,
    StopMissingNaptanWarningVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)


class StopMissingNaptanListView(TimingPatternsListBaseView):
    data = StopNotInNaptanObservation
    model = StopMissingNaptanWarning
    table_class = StopMissingNaptanListTable

    def get_queryset(self):
        # The synthetic stop can appear in multiple service patterns, here we just pick
        # an arbitrary service pattern to help the user.
        return (
            super()
            .get_queryset()
            .exclude_null_service_patterns()
            .add_message()
            .add_line()
        )

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "The following timing pattern(s) have been observed to have stops "
                    "that are not in NaPTAN."
                ),
            }
        )
        return context


class StopMissingNaptanDetailView(TwoTableDetailView):
    data = StopNotInNaptanObservation
    model = StopMissingNaptanWarning
    tables = [StopMissingNaptanWarningTimingTable, StopMissingNaptanWarningVehicleTable]

    def get_table1_kwargs(self):
        kwargs = super().get_table1_kwargs()
        stop = self.warning.stop
        kwargs[
            "warning_message"
        ] = f"Synthetic stop(s) ({stop.atco_code}) not found in NaPTAN."
        return kwargs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        service_name = self.warning.get_service_pattern().service.name

        context["title"] = self.data.title
        context["subtitle"] = (
            f"Line {service_name} has at least one journey where stop(s) are not in "
            f"NaPTAN"
        )
        return context
