```python
from transit_odp.data_quality.constants import SlowLinkObservation
from transit_odp.data_quality.models.warnings import SlowLinkWarning
from transit_odp.data_quality.tables import (
    SlowLinkWarningTimingTable,
    SlowLinkWarningVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)

class SlowLinkListView(TimingPatternsListBaseView):
    """
    A view that lists timing patterns with slow links.

    Attributes:
        data: Reference to the SlowLinkObservation constants.
        model: Reference to the SlowLinkWarning model.
    """
    data = SlowLinkObservation
    model = SlowLinkWarning

    def get_queryset(self):
        """
        Retrieves the queryset for slow link warnings with additional information.

        Returns:
            A queryset that includes related line and message data.
        """
        qs = super().get_queryset().add_line().add_message()
        return qs

    def get_context_data(self, **kwargs):
        """
        Adds additional context for the slow link list view.

        Args:
            **kwargs: Keyword arguments passed to the method.

        Returns:
            A dictionary containing context data for the slow link list view.
        """
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have slow "
                    "links."
                ),
            }
        )
        return context


class SlowLinkDetailView(TwoTableDetailView):
    """
    A detailed view for a specific slow link warning, showing associated timing
    patterns and vehicles.

    Attributes:
        data: Reference to the SlowLinkObservation constants.
        model: Reference to the SlowLinkWarning model.
        tables: A list of tables to display related timing and vehicle data.
    """
    data = SlowLinkObservation
    model = SlowLinkWarning
    tables = [SlowLinkWarningTimingTable, SlowLinkWarningVehicleTable]

    def get_context_data(self, **kwargs):
        """
        Adds additional context for the slow link detail view.

        Args:
            **kwargs: Keyword arguments passed to the method.

        Returns:
            A dictionary containing context data for the slow link detail view.
        """
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context
```

from transit_odp.data_quality.constants import SlowLinkObservation
from transit_odp.data_quality.models.warnings import SlowLinkWarning
from transit_odp.data_quality.tables import (
    SlowLinkWarningTimingTable,
    SlowLinkWarningVehicleTable,
)
from transit_odp.data_quality.views.base import (
    TimingPatternsListBaseView,
    TwoTableDetailView,
)


class SlowLinkListView(TimingPatternsListBaseView):
    data = SlowLinkObservation
    model = SlowLinkWarning

    def get_queryset(self):
        qs = super().get_queryset().add_line().add_message()
        # In theory, for SlowLink there's only ever 1 service link,
        # so can implicitly traverse service_links, getting the from_stop and to_stop
        # of the first link But possibly safer to use subquery to get
        # service_link.first(), for example
        return qs

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update(
            {
                "title": self.data.title,
                "definition": self.data.text,
                "preamble": (
                    "Following timing pattern(s) have been observed to have slow "
                    "links."
                ),
            }
        )
        return context


class SlowLinkDetailView(TwoTableDetailView):
    data = SlowLinkObservation
    model = SlowLinkWarning
    tables = [SlowLinkWarningTimingTable, SlowLinkWarningVehicleTable]

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        title = self.data.title
        line_name = self.warning.get_timing_pattern().service_pattern.service.name

        context["title"] = title
        context["subtitle"] = f"Line {line_name} has {title.lower()}"
        return context
