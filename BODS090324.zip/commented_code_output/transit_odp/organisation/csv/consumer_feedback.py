```python
from transit_odp.common.csv import CSVBuilder, CSVColumn
from transit_odp.organisation.models import ConsumerFeedback


class ConsumerFeedbackBaseCSV(CSVBuilder):
    """
    Base CSV builder for consumer feedback that defines the common columns
    and the query set to be used for generating the CSV.
    """

    @property
    def columns(self):
        """
        Defines the columns for the CSV export.

        Returns:
            A list of CSVColumn instances representing the CSV headers and how to access the data.
        """
        return [
            CSVColumn(header="Date", accessor=lambda n: f"{n.date:%d.%m.%y}"),
            CSVColumn(header="Feedback type", accessor="feedback_type"),
            CSVColumn(header="Dataset ID", accessor="dataset_id"),
            CSVColumn(header="DataType", accessor="dataset_type"),
            CSVColumn(header="Description", accessor="feedback"),
            CSVColumn(header="Raised by: Name", accessor="username"),
            CSVColumn(header="Raised by: Email", accessor="email"),
            CSVColumn(
                header="Total number of issues raised on this dataset/feed",
                accessor=lambda n: "-" if n.count is None else str(n.count),
            ),
        ]

    def get_queryset(self):
        """
        Retrieves the query set for the consumer feedback, with additional annotations.

        Returns:
            A ConsumerFeedback queryset with additional fields.
        """
        return (
            ConsumerFeedback.objects.add_date()
            .add_total_issues_per_dataset()
            .add_consumer_details()
            .add_feedback_type()
            .add_dataset_type()
            .order_by("-date")
        )


class ConsumerFeedbackCSV(ConsumerFeedbackBaseCSV):
    """
    CSV builder for consumer feedback specific to an organisation.
    """

    def __init__(self, organisation_id: int):
        """
        Initializes the CSV builder with a specific organisation ID.

        Parameters:
            organisation_id (int): The ID of the organisation to filter feedback for.
        """
        self._organisation_id = organisation_id

    def get_queryset(self):
        """
        Retrieves a filtered query set for the consumer feedback based on the organisation ID.

        Returns:
            A ConsumerFeedback queryset filtered by the organisation ID.
        """
        qs = super().get_queryset()
        return qs.filter(organisation_id=self._organisation_id)


class ConsumerFeedbackAdminCSV(ConsumerFeedbackBaseCSV):
    """
    CSV builder for consumer feedback with additional columns for admin use.
    """

    @property
    def columns(self):
        """
        Extends the base columns with an additional column for the organisation name.

        Returns:
            An extended list of CSVColumn instances including the organisation name.
        """
        columns = super().columns
        columns.insert(
            1, CSVColumn(header="Organisation", accessor="organisation_name")
        )
        return columns

    def get_queryset(self):
        """
        Retrieves the query set for the consumer feedback, with additional annotations for admin.

        Returns:
            A ConsumerFeedback queryset with additional fields for admin use.
        """
        qs = super().get_queryset()
        return qs.add_organisation_name()
```

from transit_odp.common.csv import CSVBuilder, CSVColumn
from transit_odp.organisation.models import ConsumerFeedback


class ConsumerFeedbackBaseCSV(CSVBuilder):
    @property
    def columns(self):
        return [
            CSVColumn(header="Date", accessor=lambda n: f"{n.date:%d.%m.%y}"),
            CSVColumn(header="Feedback type", accessor="feedback_type"),
            CSVColumn(header="Dataset ID", accessor="dataset_id"),
            CSVColumn(header="DataType", accessor="dataset_type"),
            CSVColumn(header="Description", accessor="feedback"),
            CSVColumn(header="Raised by: Name", accessor="username"),
            CSVColumn(header="Raised by: Email", accessor="email"),
            CSVColumn(
                header="Total number of issues raised on this dataset/feed",
                accessor=lambda n: "-" if n.count is None else str(n.count),
            ),
        ]

    def get_queryset(self):
        return (
            ConsumerFeedback.objects.add_date()
            .add_total_issues_per_dataset()
            .add_consumer_details()
            .add_feedback_type()
            .add_dataset_type()
            .order_by("-date")
        )


class ConsumerFeedbackCSV(ConsumerFeedbackBaseCSV):
    def __init__(self, organisation_id: int):
        self._organisation_id = organisation_id

    def get_queryset(self):
        qs = super().get_queryset()
        return qs.filter(organisation_id=self._organisation_id)


class ConsumerFeedbackAdminCSV(ConsumerFeedbackBaseCSV):
    @property
    def columns(self):
        columns = super().columns
        columns.insert(
            1, CSVColumn(header="Organisation", accessor="organisation_name")
        )
        return columns

    def get_queryset(self):
        qs = super().get_queryset()
        return qs.add_organisation_name()
