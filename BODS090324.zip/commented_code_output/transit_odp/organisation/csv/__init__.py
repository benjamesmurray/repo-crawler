```python
class EmptyDataFrame(Exception):
    """Exception raised for errors in the input when the DataFrame is empty.

    Attributes:
        message -- explanation of the error
    """

    def __init__(self, message="DataFrame is empty"):
        self.message = message
        super().__init__(self.message)
```

class EmptyDataFrame(Exception):
    pass
