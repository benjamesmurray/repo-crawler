```python
from django.db import migrations, models

class Migration(migrations.Migration):
    """
    A Django database migration for adding and altering fields on the
    'txcfileattributes' model within the 'organisation' app.

    Attributes:
        dependencies (list): A list of dependencies for this migration.
        operations (list): A list of migration operations to be applied.
    """

    dependencies = [
        ("organisation", "0041_auto_20210506_1717"),
    ]

    operations = [
        migrations.AddField(
            """
            Add a new CharField 'national_operator_code' to the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model to which the field is being added.
                name (str): The name of the field being added.
                field (models.CharField): The field being added to the model, with default value,
                                          maximum length, and a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="national_operator_code",
            field=models.CharField(
                default="", max_length=100, verbose_name="National Operator Code"
            ),
            preserve_default=False,
        ),
        migrations.AlterField(
            """
            Alter the 'creation_datetime' field of the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model whose field is being altered.
                name (str): The name of the field being altered.
                field (models.DateTimeField): The new configuration of the field, with a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="creation_datetime",
            field=models.DateTimeField(verbose_name="File Creation Datetime"),
        ),
        migrations.AlterField(
            """
            Alter the 'filename' field of the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model whose field is being altered.
                name (str): The name of the field being altered.
                field (models.CharField): The new configuration of the field, with a maximum length and a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="filename",
            field=models.CharField(max_length=512, verbose_name="Filename"),
        ),
        migrations.AlterField(
            """
            Alter the 'modification' field of the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model whose field is being altered.
                name (str): The name of the field being altered.
                field (models.CharField): The new configuration of the field, with a maximum length and a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="modification",
            field=models.CharField(max_length=28, verbose_name="Modification"),
        ),
        migrations.AlterField(
            """
            Alter the 'modificaton_datetime' field of the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model whose field is being altered.
                name (str): The name of the field being altered.
                field (models.DateTimeField): The new configuration of the field, with a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="modificaton_datetime",
            field=models.DateTimeField(verbose_name="File Modification Datetime"),
        ),
        migrations.AlterField(
            """
            Alter the 'revision_number' field of the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model whose field is being altered.
                name (str): The name of the field being altered.
                field (models.IntegerField): The new configuration of the field, with a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="revision_number",
            field=models.IntegerField(verbose_name="File Revision Number"),
        ),
        migrations.AlterField(
            """
            Alter the 'schema_version' field of the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model whose field is being altered.
                name (str): The name of the field being altered.
                field (models.CharField): The new configuration of the field, with a maximum length and a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="schema_version",
            field=models.CharField(
                max_length=10, verbose_name="TransXChange Schema Version"
            ),
        ),
        migrations.AlterField(
            """
            Alter the 'service_code' field of the 'txcfileattributes' model.

            Parameters:
                model_name (str): The name of the model whose field is being altered.
                name (str): The name of the field being altered.
                field (models.CharField): The new configuration of the field, with a maximum length and a verbose name.

            No return value.
            """
            model_name="txcfileattributes",
            name="service_code",
            field=models.CharField(max_length=100, verbose_name="Service Code"),
        ),
    ]
```

# Generated by Django 2.2.23 on 2021-05-21 12:50

from django.db import migrations, models


class Migration(migrations.Migration):

    dependencies = [
        ("organisation", "0041_auto_20210506_1717"),
    ]

    operations = [
        migrations.AddField(
            model_name="txcfileattributes",
            name="national_operator_code",
            field=models.CharField(
                default="", max_length=100, verbose_name="National Operator Code"
            ),
            preserve_default=False,
        ),
        migrations.AlterField(
            model_name="txcfileattributes",
            name="creation_datetime",
            field=models.DateTimeField(verbose_name="File Creation Datetime"),
        ),
        migrations.AlterField(
            model_name="txcfileattributes",
            name="filename",
            field=models.CharField(max_length=512, verbose_name="Filename"),
        ),
        migrations.AlterField(
            model_name="txcfileattributes",
            name="modification",
            field=models.CharField(max_length=28, verbose_name="Modification"),
        ),
        migrations.AlterField(
            model_name="txcfileattributes",
            name="modificaton_datetime",
            field=models.DateTimeField(verbose_name="File Modification Datetime"),
        ),
        migrations.AlterField(
            model_name="txcfileattributes",
            name="revision_number",
            field=models.IntegerField(verbose_name="File Revision Number"),
        ),
        migrations.AlterField(
            model_name="txcfileattributes",
            name="schema_version",
            field=models.CharField(
                max_length=10, verbose_name="TransXChange Schema Version"
            ),
        ),
        migrations.AlterField(
            model_name="txcfileattributes",
            name="service_code",
            field=models.CharField(max_length=100, verbose_name="Service Code"),
        ),
    ]
