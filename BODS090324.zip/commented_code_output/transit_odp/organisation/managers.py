```python
import logging
from django.db import models
from transit_odp.organisation.querysets import (
    BODSLicenceQuerySet,
    ConsumerFeedbackQuerySet,
    DatasetQuerySet,
    DatasetRevisionQuerySet,
    OrganisationQuerySet,
    SeasonalServiceQuerySet,
    ServiceCodeExemptionQuerySet,
)

logger = logging.getLogger(__name__)

class OrganisationManager(models.Manager.from_queryset(OrganisationQuerySet)):
    """Manager for Organisation models that provides additional functionality via OrganisationQuerySet."""
    pass

class DatasetManager(models.Manager.from_queryset(DatasetQuerySet)):
    """Manager for Dataset models that provides additional functionality via DatasetQuerySet."""
    pass

class DatasetRevisionManager(models.Manager.from_queryset(DatasetRevisionQuerySet)):
    """Manager for DatasetRevision models that provides additional functionality via DatasetRevisionQuerySet."""
    pass

class ConsumerFeedbackManager(models.Manager.from_queryset(ConsumerFeedbackQuerySet)):
    """Manager for ConsumerFeedback models that provides additional functionality via ConsumerFeedbackQuerySet."""
    pass

class ServiceCodeExemptionManager(models.Manager.from_queryset(ServiceCodeExemptionQuerySet)):
    """Manager for ServiceCodeExemption models that provides additional functionality via ServiceCodeExemptionQuerySet."""
    pass

class BODSLicenceManager(models.Manager.from_queryset(BODSLicenceQuerySet)):
    """Manager for BODSLicence models that provides additional functionality via BODSLicenceQuerySet."""
    pass

class SeasonalServiceManager(models.Manager.from_queryset(SeasonalServiceQuerySet)):
    """Manager for SeasonalService models that provides additional functionality via SeasonalServiceQuerySet."""
    pass
```

import logging

from django.db import models

from transit_odp.organisation.querysets import (
    BODSLicenceQuerySet,
    ConsumerFeedbackQuerySet,
    DatasetQuerySet,
    DatasetRevisionQuerySet,
    OrganisationQuerySet,
    SeasonalServiceQuerySet,
    ServiceCodeExemptionQuerySet,
)

logger = logging.getLogger(__name__)


class OrganisationManager(models.Manager.from_queryset(OrganisationQuerySet)):
    pass


class DatasetManager(models.Manager.from_queryset(DatasetQuerySet)):
    pass


class DatasetRevisionManager(models.Manager.from_queryset(DatasetRevisionQuerySet)):
    pass


class ConsumerFeedbackManager(models.Manager.from_queryset(ConsumerFeedbackQuerySet)):
    pass


class ServiceCodeExemptionManager(
    models.Manager.from_queryset(ServiceCodeExemptionQuerySet)
):
    pass


class BODSLicenceManager(models.Manager.from_queryset(BODSLicenceQuerySet)):
    pass


class SeasonalServiceManager(models.Manager.from_queryset(SeasonalServiceQuerySet)):
    pass
