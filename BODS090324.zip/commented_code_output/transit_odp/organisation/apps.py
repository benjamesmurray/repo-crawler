```python
from django.apps import AppConfig

class OrganisationConfig(AppConfig):
    """
    Configuration class for the 'organisation' app within the 'transit_odp' project.
    
    This class is used for application-specific configuration such as registering signals.
    It inherits from Django's AppConfig.
    
    Attributes:
        name (str): The name of the application.
    """
    name = "transit_odp.organisation"

    def ready(self):
        """
        Overrides the ready method to import signal handlers.
        
        This method is called when the app registry is fully populated and all
        AppConfigs are ready. It is the place to import signal handlers.
        """
        import transit_odp.organisation.receivers  # noqa
```

from django.apps import AppConfig


class OrganisationConfig(AppConfig):
    name = "transit_odp.organisation"

    def ready(self):
        import transit_odp.organisation.receivers  # noqa
