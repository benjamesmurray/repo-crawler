```python
from django.urls import path
from ..views import DeveloperGuidanceHomeView, DeveloperReqView

# Define the app namespace to allow for reverse URL matching
app_name = "guidance"

# URL patterns list that holds the mapping of URL paths to views for the guidance app.
urlpatterns = [
    # URL pattern for the Developer Guidance Home page.
    path(
        "",
        view=DeveloperGuidanceHomeView.as_view(),
        name="developers-home",
    ),
    # URL pattern for the Developer Requirements page.
    path(
        "requirements/",
        view=DeveloperReqView.as_view(),
        name="support-developer",
    ),
]
```

from django.urls import path

from ..views import DeveloperGuidanceHomeView, DeveloperReqView

app_name = "guidance"
urlpatterns = [
    path(
        "",
        view=DeveloperGuidanceHomeView.as_view(),
        name="developers-home",
    ),
    path(
        "requirements/",
        view=DeveloperReqView.as_view(),
        name="support-developer",
    ),
]
