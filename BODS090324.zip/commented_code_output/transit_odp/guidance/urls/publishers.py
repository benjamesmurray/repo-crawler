```python
from django.urls import path

from transit_odp.data_quality.views.glossary import (
    DataQualityGlossaryView,
    DataQualityScoreGuidanceView,
)

from ..views import BusOperatorReqView, LocalAuthorityReqView, SupportOperatorHomeView

# Define the app name for namespacing of URLs.
app_name = "guidance"

# List of URL patterns for the guidance app.
urlpatterns = [
    # URL pattern for the support operator home view.
    path("", view=SupportOperatorHomeView.as_view(), name="operators-home"),
    
    # URL pattern for the local authority requirements view.
    path(
        "local-authority-requirements/",
        view=LocalAuthorityReqView.as_view(),
        name="support-local_authorities",
    ),
    
    # URL pattern for the bus operator requirements view.
    path(
        "operator-requirements/",
        view=BusOperatorReqView.as_view(),
        name="support-bus_operators",
    ),
    
    # URL pattern for the data quality glossary view.
    path(
        "data-quality-definitions/",
        view=DataQualityGlossaryView.as_view(),
        name="dq-definitions",
    ),
    
    # URL pattern for the data quality score guidance view.
    path(
        "score-description/",
        view=DataQualityScoreGuidanceView.as_view(),
        name="dq-score-description",
    ),
]
```

from django.urls import path

from transit_odp.data_quality.views.glossary import (
    DataQualityGlossaryView,
    DataQualityScoreGuidanceView,
)

from ..views import BusOperatorReqView, LocalAuthorityReqView, SupportOperatorHomeView

app_name = "guidance"
urlpatterns = [
    path("", view=SupportOperatorHomeView.as_view(), name="operators-home"),
    path(
        "local-authority-requirements/",
        view=LocalAuthorityReqView.as_view(),
        name="support-local_authorities",
    ),
    path(
        "operator-requirements/",
        view=BusOperatorReqView.as_view(),
        name="support-bus_operators",
    ),
    path(
        "data-quality-definitions/",
        view=DataQualityGlossaryView.as_view(),
        name="dq-definitions",
    ),
    path(
        "score-description/",
        view=DataQualityScoreGuidanceView.as_view(),
        name="dq-score-description",
    ),
]
