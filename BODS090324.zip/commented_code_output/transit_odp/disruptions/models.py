```python
from django.db import models
from django.utils.translation import gettext_lazy as _
from django_extensions.db.fields import CreationDateTimeField, ModificationDateTimeField
from transit_odp.common.fields import CallableStorageFileField
from transit_odp.disruptions.storage import get_sirisx_storage

class DisruptionsDataArchive(models.Model):
    """
    Represents an archive of disruption data in the SIRI-SX XML format.

    Attributes:
        created (CreationDateTimeField): The date and time when the record was created.
        last_updated (ModificationDateTimeField): The date and time when the record was last updated.
        data (CallableStorageFileField): A field pointing to a zip file containing the SIRI-SX XML data.

    The `Meta` class defines the default ordering of records by their creation time in descending order.
    """

    created = CreationDateTimeField(_("created"))
    last_updated = ModificationDateTimeField(_("last_updated"))
    data = CallableStorageFileField(
        storage=get_sirisx_storage,
        help_text=_("A zip file containing an up to date SIRI-SX XML."),
    )

    class Meta:
        get_latest_by = "-created"
        ordering = ("-created",)

    def __repr__(self):
        """
        Represents the string representation of the DisruptionsDataArchive instance.

        Returns:
            str: A string that represents the DisruptionsDataArchive instance, including
                 the creation time, last updated time, and the name of the data file.
        """
        return (
            f"{self.__class__.__name__}(created={self.created!r}, "
            f"last_updated={self.last_updated!r}, data={self.data.name!r})"
        )
```

from django.db import models
from django.utils.translation import gettext_lazy as _
from django_extensions.db.fields import CreationDateTimeField, ModificationDateTimeField
from transit_odp.common.fields import CallableStorageFileField
from transit_odp.disruptions.storage import get_sirisx_storage


class DisruptionsDataArchive(models.Model):
    created = CreationDateTimeField(_("created"))
    last_updated = ModificationDateTimeField(_("last_updated"))
    data = CallableStorageFileField(
        storage=get_sirisx_storage,
        help_text=_("A zip file containing an up to date SIRI-SX XML."),
    )

    class Meta:
        get_latest_by = "-created"
        ordering = ("-created",)

    def __repr__(self):
        return (
            f"{self.__class__.__name__}(created={self.created!r}, "
            f"last_updated={self.last_updated!r}, data={self.data.name!r}, "
            f"data_format={self.data_format!r})"
        )
