```python
from django.apps import AppConfig

class DisruptionsConfig(AppConfig):
    """
    Configuration class for the 'disruptions' app within the 'transit_odp' project.

    Attributes:
        name (str): The full Python path to the application.
        verbose_name (str): The human-readable name for the application.
    """
    name = "transit_odp.disruptions"
    verbose_name = "Disruptions"
```

from django.apps import AppConfig


class DisruptionsConfig(AppConfig):
    name = "transit_odp.disruptions"
    verbose_name = "Disruptions"
