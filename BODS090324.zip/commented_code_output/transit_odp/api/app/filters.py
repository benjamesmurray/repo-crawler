```python
from django_filters import rest_framework as filters
from transit_odp.transmodel.models import ServicePattern

class ServicePatternFilterSet(filters.FilterSet):
    """
    FilterSet for ServicePattern model to filter by line name and service codes.
    
    Attributes:
        line_name: A CharFilter to filter service patterns by exact service name.
        service_codes: A CharFilter to filter service patterns by a list of service codes.
    """
    
    # Filter for matching the exact line name of a service pattern
    line_name = filters.CharFilter(field_name="services__name", lookup_expr="exact")
    
    # Filter for matching service patterns by a list of service codes
    service_codes = filters.CharFilter(
        field_name="services__service_code", method="filter_by_service_codes"
    )

    class Meta:
        """
        Meta class to define the fields and model used in the filter set.
        """
        model = ServicePattern
        fields = ["revision", "line_name", "service_codes"]

    def filter_by_service_codes(self, queryset, name, value):
        """
        Custom filter method to filter the queryset by a list of service codes.
        
        Parameters:
            queryset: The initial queryset to be filtered.
            name: The name of the filter field, not used in this method.
            value: A string containing comma-separated service codes.
        
        Returns:
            A queryset of ServicePattern objects filtered by the given service codes.
        """
        service_codes_list = value.split(",")
        return queryset.filter(services__service_code__in=service_codes_list)
```

from django_filters import rest_framework as filters

from transit_odp.transmodel.models import ServicePattern


class ServicePatternFilterSet(filters.FilterSet):
    line_name = filters.CharFilter(field_name="services__name", lookup_expr="exact")
    service_codes = filters.CharFilter(
        field_name="services__service_code", method="filter_by_service_codes"
    )

    class Meta:
        model = ServicePattern
        fields = ["revision", "line_name", "service_codes"]

    def filter_by_service_codes(self, queryset, name, value):
        service_codes_list = value.split(",")
        return queryset.filter(services__service_code__in=service_codes_list)
