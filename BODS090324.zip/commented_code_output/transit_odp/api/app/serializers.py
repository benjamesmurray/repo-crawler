```python
from rest_framework import serializers
from rest_framework_gis.serializers import GeoFeatureModelSerializer

from transit_odp.naptan.models import StopPoint
from transit_odp.organisation.models import DatasetRevision
from transit_odp.transmodel.models import ServicePattern

class DatasetRevisionSerializer(serializers.ModelSerializer):
    """
    Serializer for DatasetRevision model.
    
    Converts DatasetRevision instances into Python data types and vice versa.
    """
    
    class Meta:
        model = DatasetRevision
        fields = ["id", "dataset", "name"]

class DataQualityTaskStatusSerializer(serializers.Serializer):
    """
    Serializer for representing the status of a data quality task.
    
    Includes fields for status and warning count.
    """
    
    status = serializers.CharField()
    warning_count = serializers.IntegerField()

class StopPointSerializer(GeoFeatureModelSerializer):
    """
    Geo-feature serializer for StopPoint model.
    
    Serializes StopPoint instances including geographic data.
    """
    
    class Meta:
        model = StopPoint
        geo_field = "location"
        fields = ["id", "atco_code", "location", "common_name"]

class ServicePatternSerializer(GeoFeatureModelSerializer):
    """
    Geo-feature serializer for ServicePattern model.
    
    Serializes ServicePattern instances including geographic data.
    Adds a read-only 'service_name' field from an annotation.
    """
    
    class Meta:
        model = ServicePattern
        geo_field = "geom"
        fields = [
            "id",
            "service_pattern_id",
            "revision",
            "origin",
            "destination",
            "description",
            "service_name",
        ]

    service_name = serializers.CharField(read_only=True)  # annotation
```

from rest_framework import serializers
from rest_framework_gis.serializers import GeoFeatureModelSerializer

from transit_odp.naptan.models import StopPoint
from transit_odp.organisation.models import DatasetRevision
from transit_odp.transmodel.models import ServicePattern


class DatasetRevisionSerializer(serializers.ModelSerializer):
    class Meta:
        model = DatasetRevision
        fields = ["id", "dataset", "name"]


class DataQualityTaskStatusSerializer(serializers.Serializer):
    status = serializers.CharField()
    warning_count = serializers.IntegerField()


class StopPointSerializer(GeoFeatureModelSerializer):
    class Meta:
        model = StopPoint
        geo_field = "location"
        fields = ["id", "atco_code", "location", "common_name"]


class ServicePatternSerializer(GeoFeatureModelSerializer):
    class Meta:
        model = ServicePattern
        geo_field = "geom"
        fields = [
            "id",
            "service_pattern_id",
            "revision",
            "origin",
            "destination",
            "description",
            "service_name",
        ]

    service_name = serializers.CharField(read_only=True)  # annotation
