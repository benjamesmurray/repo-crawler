```python
from django.urls import include, re_path
from rest_framework.routers import DefaultRouter
from transit_odp.api.app import views

app_name = "app"

# Initialize the DefaultRouter object which will be used to automatically generate
# URL patterns for the API views.
router = DefaultRouter()

# Register the DatasetRevisionViewSet with the router.
# This creates API endpoints for managing dataset revisions.
router.register(r"revision", views.DatasetRevisionViewSet, "revision")

# Register the StopViewSet with the router.
# This creates API endpoints for stop point data.
router.register(r"stop_point", views.StopViewSet, "stop")

# Register the ServicePatternViewSet with the router.
# This creates API endpoints for service pattern data.
router.register(r"service_pattern", views.ServicePatternViewSet, "service_pattern")

# Register the FareStopsViewSet with the router.
# This creates API endpoints for fare stop data.
router.register(r"fare_stops", views.FareStopsViewSet, "fare_stops")

# Register the DisruptionsInOrganisationView with the router.
# This creates API endpoints for map data related to disruptions in an organisation.
router.register(
    r"organisation_map_data",
    views.DisruptionsInOrganisationView,
    "organisation_map_data",
)

# Register the DisruptionDetailView with the router.
# This creates API endpoints for detailed map data about disruptions.
router.register(
    r"disruption_detail_map_data",
    views.DisruptionDetailView,
    "disruption_detail_map_data",
)

# Define the URL patterns for the API by including the URLs provided by the router.
urlpatterns = [
    re_path("", include(router.urls)),
]
```

from django.urls import include, re_path
from rest_framework.routers import DefaultRouter

from transit_odp.api.app import views

app_name = "app"


router = DefaultRouter()

# TODO - abstract specific revision id out of API e.g.
#  * /dataset/:id/live/...
#  * /dataset/:id/draft/...
router.register(r"revision", views.DatasetRevisionViewSet, "revision")

# APIs for rendering map data
router.register(r"stop_point", views.StopViewSet, "stop")
router.register(r"service_pattern", views.ServicePatternViewSet, "service_pattern")
router.register(r"fare_stops", views.FareStopsViewSet, "fare_stops")
router.register(
    r"organisation_map_data",
    views.DisruptionsInOrganisationView,
    "organisation_map_data",
)
router.register(
    r"disruption_detail_map_data",
    views.DisruptionDetailView,
    "disruption_detail_map_data",
)

urlpatterns = [
    re_path("", include(router.urls)),
]
