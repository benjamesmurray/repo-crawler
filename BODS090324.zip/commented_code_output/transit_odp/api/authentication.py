```python
from rest_framework.authentication import TokenAuthentication


class TokenAuthSupportQueryString(TokenAuthentication):
    """
    Extend the TokenAuthentication class to support authentication through a query string.
    
    This class allows clients to pass the authentication token as a query parameter
    in the URL, as an alternative to the standard Authorization header.
    """

    def authenticate(self, request):
        """
        Attempt to authenticate a user using the query string first, falling back to headers.
        
        Parameters:
        - request: The HttpRequest object containing the client's request data.
        
        Returns:
        - A two-tuple of (user, token) if authentication is successful.
        - None if no authentication is attempted (neither query parameter nor header present).
        - Raises `AuthenticationFailed` if authentication is attempted but fails.
        """
        # Check if API_KEY_PARAM is in the request query params.
        # Give precedence to 'Authorization' header.
        API_KEY_PARAM = "api_key"
        if (
            API_KEY_PARAM in request.query_params
            and "HTTP_AUTHORIZATION" not in request.META
        ):
            return self.authenticate_credentials(
                request.query_params.get(API_KEY_PARAM)
            )
        else:
            return super(TokenAuthSupportQueryString, self).authenticate(request)
```

from rest_framework.authentication import TokenAuthentication


class TokenAuthSupportQueryString(TokenAuthentication):
    """
    Extend the TokenAuthentication class to support querystring authentication
    in the form of "http://www.example.com/?api_key=<token_key>"
    """

    def authenticate(self, request):
        # Check if API_KEY_PARAM is in the request query params.
        # Give precedence to 'Authorization' header.
        API_KEY_PARAM = "api_key"
        if (
            API_KEY_PARAM in request.query_params
            and "HTTP_AUTHORIZATION" not in request.META
        ):
            return self.authenticate_credentials(
                request.query_params.get(API_KEY_PARAM)
            )
        else:
            return super(TokenAuthSupportQueryString, self).authenticate(request)
