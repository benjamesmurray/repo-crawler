```python
from django_filters import rest_framework as filters

from transit_odp.common.filters import ArrayFilter
from transit_odp.organisation.models import Dataset, TXCFileAttributes

class OperatorFilterSet(filters.FilterSet):
    """
    FilterSet for filtering operator datasets based on NOC (National Operator Code) or licence number.
    """
    noc = filters.CharFilter(field_name="nocs__noc")
    licence = filters.CharFilter(field_name="licences__number")


class TimetableFilterSet(filters.FilterSet):
    """
    FilterSet for filtering timetable datasets based on various fields including NOC, line name, and ordering.
    """
    noc = filters.CharFilter(
        field_name="live_revision__txc_file_attributes__national_operator_code"
    )
    line_name = ArrayFilter(
        field_name="live_revision__txc_file_attributes__line_names",
        lookup_expr="contains",
    )
    ordering = filters.OrderingFilter(
        fields=(
            ("live_revision__name", "name"),
            ("id", "id"),
            ("modified", "modified"),
        )
    )

    class Meta:
        """
        Meta class to specify the model and fields to be used for filtering.
        """
        model = Dataset
        fields = ["noc", "line_name"]


class TimetableFileFilterSet(filters.FilterSet):
    """
    FilterSet for filtering TXC file attributes based on NOC and line name.
    """
    class Meta:
        """
        Meta class to specify the model and fields to be used for filtering.
        """
        model = TXCFileAttributes
        fields = ["noc", "line_name"]

    noc = filters.CharFilter(field_name="national_operator_code")
    line_name = ArrayFilter(field_name="line_names", lookup_expr="contains")
```

from django_filters import rest_framework as filters

from transit_odp.common.filters import ArrayFilter
from transit_odp.organisation.models import Dataset, TXCFileAttributes


class OperatorFilterSet(filters.FilterSet):
    noc = filters.CharFilter(field_name="nocs__noc")
    licence = filters.CharFilter(field_name="licences__number")


class TimetableFilterSet(filters.FilterSet):
    noc = filters.CharFilter(
        field_name="live_revision__txc_file_attributes__national_operator_code"
    )
    line_name = ArrayFilter(
        field_name="live_revision__txc_file_attributes__line_names",
        lookup_expr="contains",
    )
    ordering = filters.OrderingFilter(
        fields=(
            ("live_revision__name", "name"),
            ("id", "id"),
            ("modified", "modified"),
        )
    )

    class Meta:
        model = Dataset
        fields = ["noc", "line_name"]


class TimetableFileFilterSet(filters.FilterSet):
    class Meta:
        model = TXCFileAttributes
        fields = ["noc", "line_name"]

    noc = filters.CharFilter(field_name="national_operator_code")
    line_name = ArrayFilter(field_name="line_names", lookup_expr="contains")
