```python
from django.apps import AppConfig

class ApiConfig(AppConfig):
    """Django app configuration for the 'api' app.

    This class configures the 'api' app within a Django project by setting its
    name and verbose name attributes.

    Attributes:
        name (str): The full Python path to the application.
        verbose_name (str): A human-readable name for the application.
    """
    name = "transit_odp.api"
    verbose_name = "Api"
```

from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = "transit_odp.api"
    verbose_name = "Api"
