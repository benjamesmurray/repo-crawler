```python
from rest_framework.permissions import SAFE_METHODS, IsAuthenticated

class IsReadOnlyUser(IsAuthenticated):
    """
    Permission class that allows read-only access to all authenticated users
    but allows write access only to authenticated users who are marked as
    organization users.
    
    Inherits from IsAuthenticated to ensure the user is authenticated before
    checking for additional constraints.
    """

    def has_permission(self, request, view):
        """
        Check if the request should be granted permission.

        Overrides the has_permission method of IsAuthenticated to add an
        additional check for write permissions based on whether the user
        is an organization user or not.

        Parameters:
        - request: The HttpRequest object being processed.
        - view: The View object that the request is being made to.

        Returns:
        - True if the request is a safe method (read-only) or if it's a write
          operation and the user is an organization user. False otherwise.
        """
        is_auth = super().has_permission(request, view)
        if request.method in SAFE_METHODS:
            return is_auth
        return is_auth and request.user.is_org_user
```

from rest_framework.permissions import SAFE_METHODS, IsAuthenticated


class IsReadOnlyUser(IsAuthenticated):
    """
    Editable for organisation users and read only for authenticated non-organisation
    users.
    """

    def has_permission(self, request, view):
        is_auth = super().has_permission(request, view)
        if request.method in SAFE_METHODS:
            return is_auth
        return is_auth and request.user.is_org_user
