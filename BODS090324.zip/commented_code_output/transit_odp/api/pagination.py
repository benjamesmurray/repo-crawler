```python
import rest_framework.pagination
import rest_framework_gis.pagination

class PageNumberPagination(rest_framework.pagination.PageNumberPagination):
    """
    Custom pagination class that extends Django REST Framework's PageNumberPagination.
    
    Attributes:
        page_size (int): The number of items to include in a single page.
        page_size_query_param (str): The query parameter used for the client to specify the page size.
        max_page_size (int): The maximum allowable page size that can be requested by a client.
    """
    page_size = 100
    page_size_query_param = "page_size"
    max_page_size = 1000


class GeoJsonPagination(rest_framework_gis.pagination.GeoJsonPagination):
    """
    Custom pagination class for GeoJSON data that extends rest_framework_gis's GeoJsonPagination.
    
    Attributes:
        page_size (int): The number of items to include in a single page.
        page_size_query_param (str): The query parameter used for the client to specify the page size.
        max_page_size (int): The maximum allowable page size that can be requested by a client.
    """
    page_size = 800
    page_size_query_param = "page_size"
    max_page_size = 10000
```

import rest_framework.pagination
import rest_framework_gis.pagination


class PageNumberPagination(rest_framework.pagination.PageNumberPagination):
    page_size = 100
    page_size_query_param = "page_size"
    max_page_size = 1000


class GeoJsonPagination(rest_framework_gis.pagination.GeoJsonPagination):
    page_size = 800
    page_size_query_param = "page_size"
    max_page_size = 10000
