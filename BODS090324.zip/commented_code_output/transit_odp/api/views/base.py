```python
from django.db.models import Q
from rest_framework import status, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from transit_odp.api.filters import DatasetSearchFilterSet
from transit_odp.api.serializers import DatasetSerializer
from transit_odp.api.validators import (
    validate_api_parameter_keys,
    validate_api_parameter_values,
)
from transit_odp.organisation.constants import DatasetType
from transit_odp.organisation.models import Dataset

valid_parameters = [
    "limit",
    "offset",
    "noc",
    "modifiedDate",
    "adminArea",
    "startDateStart",
    "startDateEnd",
    "endDateStart",
    "endDateEnd",
    "status",
    "search",
    "api_key",
    "format",
    "dqRag",
    "bodsCompliance",
]

class DatasetBaseViewSet(viewsets.ReadOnlyModelViewSet):
    """
    A base viewset for querying datasets with a specific type.
    
    Attributes:
        dataset_type: An integer representing the type of dataset to query.
        permission_classes: A tuple of permission classes the viewset will use.
    """
    dataset_type = DatasetType.TIMETABLE.value
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        """
        Returns a queryset of Dataset objects filtered by dataset_type and additional
        criteria such as being published and belonging to an active organization.
        """
        queryset = (
            Dataset.objects.filter(dataset_type=self.dataset_type)
            .get_published()
            .get_active_org()
            .add_organisation_name()
            .select_related("live_revision")
        )
        return queryset


class DatasetViewSet(DatasetBaseViewSet):
    """
    A viewset for listing and retrieving datasets with additional filtering and
    search capabilities. Inherits from DatasetBaseViewSet.
    
    Attributes:
        permission_classes: A tuple of permission classes the viewset will use.
        serializer_class: The serializer class for transforming queryset results into JSON.
        filterset_class: The class used for filtering the queryset according to query parameters.
        search_fields: A list of fields that will be searched over.
    """
    permission_classes = (IsAuthenticated,)
    serializer_class = DatasetSerializer
    filterset_class = DatasetSearchFilterSet
    search_fields = [
        "live_revision__name",
        "live_revision__description",
        "organisation__name",
        "live_revision__admin_areas__name",
    ]

    def list(self, request, *args, **kwargs):
        """
        Lists the datasets after validating query parameters. If any query parameter
        is invalid, it responds with a 400 Bad Request status.
        
        Parameters:
            request: The HTTP request object containing the query parameters.
        
        Returns:
            A Response object with the list of datasets or an error message.
        """
        # Check for invalid query parameter keys and values
        invalid_parameter_keys = validate_api_parameter_keys(
            self.request.query_params, valid_parameters
        )
        invalid_parameter_values = validate_api_parameter_values(
            self.request.query_params
        )
        
        if len(invalid_parameter_keys) > 0:
            content = {"Unsupported query parameter": invalid_parameter_keys}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)

        if len(invalid_parameter_values) > 0:
            content = {
                "Unsupported query parameter value for": invalid_parameter_values
            }
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        return super().list(self, request, *args, **kwargs)

    def get_queryset(self):
        """
        Overrides the get_queryset method to provide a more complex filtering
        mechanism, including status filtering and keyword searching.
        
        Returns:
            A queryset of Dataset objects that match the filtering criteria.
        """
        # Filter results to only those that are live, error or expired and Published
        qs = (
            Dataset.objects.get_published()
            .get_active_org()
            .add_organisation_name()
            .select_related("live_revision")
            .prefetch_related("organisation__nocs")
            .prefetch_related("live_revision__admin_areas")
            .prefetch_related("live_revision__localities")
            .prefetch_related("live_revision__services")
        )

        # Handle a list of feed status
        status_list = self.request.GET.getlist("status", [])

        if status_list and "" not in status_list:
            status_list = [
                status.replace("published", "live") for status in status_list
            ]
            qs = qs.filter(live_revision__status__in=status_list)

        # Get search terms
        keywords = self.request.GET.get("search", "").strip()

        if keywords:
            qs = qs.filter(
                Q(live_revision__name__icontains=keywords)
                | Q(live_revision__description__icontains=keywords)
                | Q(organisation_name__icontains=keywords)
                | Q(live_revision__admin_areas__name__icontains=keywords)
            )

        # Make the search results distinct since there will be duplicates from the
        # join with admin_areas
        qs = qs.order_by("id").distinct()

        return qs
```

from django.db.models import Q
from rest_framework import status, viewsets
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from transit_odp.api.filters import DatasetSearchFilterSet
from transit_odp.api.serializers import DatasetSerializer
from transit_odp.api.validators import (
    validate_api_parameter_keys,
    validate_api_parameter_values,
)
from transit_odp.organisation.constants import DatasetType
from transit_odp.organisation.models import Dataset

valid_parameters = [
    "limit",
    "offset",
    "noc",
    "modifiedDate",
    "adminArea",
    "startDateStart",
    "startDateEnd",
    "endDateStart",
    "endDateEnd",
    "status",
    "search",
    "api_key",
    "format",
    "dqRag",
    "bodsCompliance",
]


class DatasetBaseViewSet(viewsets.ReadOnlyModelViewSet):
    dataset_type = DatasetType.TIMETABLE.value
    permission_classes = (IsAuthenticated,)

    def get_queryset(self):
        queryset = (
            Dataset.objects.filter(dataset_type=self.dataset_type)
            .get_published()
            .get_active_org()
            .add_organisation_name()
            .select_related("live_revision")
        )
        return queryset


class DatasetViewSet(viewsets.ReadOnlyModelViewSet):
    """
    View feeds
    """

    permission_classes = (IsAuthenticated,)
    serializer_class = DatasetSerializer
    filterset_class = DatasetSearchFilterSet
    search_fields = [
        "live_revision__name",
        "live_revision__description",
        "organisation__name",
        "live_revision__admin_areas__name",
    ]

    def list(self, request, *args, **kwargs):
        # Check for invalid query parameter keys and values
        invalid_parameter_keys = validate_api_parameter_keys(
            self.request.query_params, valid_parameters
        )
        invalid_parameter_values = validate_api_parameter_values(
            self.request.query_params
        )
        # TODO could be refactored to handle invalid keys and values in the
        # same Response
        if len(invalid_parameter_keys) > 0:
            content = {"Unsupported query parameter": invalid_parameter_keys}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)

        if len(invalid_parameter_values) > 0:
            content = {
                "Unsupported query parameter value for": invalid_parameter_values
            }
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        return super().list(self, request, *args, **kwargs)

    def get_queryset(self):
        # Filter results to only those that are live, error or expired and Published
        qs = (
            Dataset.objects.get_published()
            .get_active_org()
            .add_organisation_name()
            .select_related("live_revision")
            .prefetch_related("organisation__nocs")
            .prefetch_related("live_revision__admin_areas")
            .prefetch_related("live_revision__localities")
            .prefetch_related("live_revision__services")
        )

        # Handle a list of feed status
        status_list = self.request.GET.getlist("status", [])

        if status_list and "" not in status_list:
            status_list = [
                status.replace("published", "live") for status in status_list
            ]
            qs = qs.filter(live_revision__status__in=status_list)

        # Get search terms
        keywords = self.request.GET.get("search", "").strip()

        if keywords:
            # TODO - enable full-text search
            # query = SearchQuery(keywords)
            # vector = SearchVector('name', 'description')
            # qs = qs.annotate(search=vector).filter(search=query)
            # qs = qs.annotate(rank=SearchRank(vector, query)).order_by('-rank')
            qs = qs.filter(
                Q(live_revision__name__icontains=keywords)
                | Q(live_revision__description__icontains=keywords)
                | Q(organisation_name__icontains=keywords)
                | Q(live_revision__admin_areas__name__icontains=keywords)
            )

        # Make the search results distinct since there will be duplicates from the
        # join with admin_areas
        qs = qs.order_by("id").distinct()

        return qs
