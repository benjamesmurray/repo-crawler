```python
from rest_framework.viewsets import ReadOnlyModelViewSet

from transit_odp.api.filters.v2 import (
    OperatorFilterSet,
    TimetableFileFilterSet,
    TimetableFilterSet,
)
from transit_odp.api.serializers.v2 import (
    DatafeedSerializer,
    OperatorSerializer,
    TimetableSerializer,
    TXCFileSerializer,
)
from transit_odp.organisation.constants import AVLType, TimetableType
from transit_odp.organisation.models import Dataset, Organisation, TXCFileAttributes


class OperatorViewSet(ReadOnlyModelViewSet):
    """
    ViewSet for browsing a list of operators or retrieving a single operator.
    
    It uses the OperatorSerializer for serialization, filters results based on
    the OperatorFilterSet, and allows ordering by 'id', 'name', and 'short_name'.
    """
    serializer_class = OperatorSerializer
    ordering_fields = ["id", "name", "short_name"]
    filterset_class = OperatorFilterSet

    def get_queryset(self):
        """
        Returns a queryset of active Organisations, prefetching related licences and nocs,
        ordered by 'id'.
        """
        return (
            Organisation.objects.filter(is_active=True)
            .prefetch_related("licences", "nocs")
            .order_by("id")
        )


class DatafeedViewSet(ReadOnlyModelViewSet):
    """
    ViewSet for browsing a list of datafeeds or retrieving a single datafeed.
    
    It uses the DatafeedSerializer for serialization and allows ordering by 'id'
    and 'modified'.
    """
    serializer_class = DatafeedSerializer
    ordering_fields = ["id", "modified"]

    def get_queryset(self):
        """
        Returns a queryset of published Datasets for active Organisations that
        are of AVLType and not dummy datasets, with related 'live_revision' and
        'organisation' preloaded.
        """
        return (
            Dataset.objects.get_published()
            .get_active_org()
            .select_related("live_revision", "organisation")
            .filter(dataset_type=AVLType, is_dummy=False)
        )


class TimetableViewSet(ReadOnlyModelViewSet):
    """
    ViewSet for browsing a list of timetables or retrieving a single timetable.
    
    It uses the TimetableSerializer for serialization and filters results based on
    the TimetableFilterSet.
    """
    serializer_class = TimetableSerializer
    filterset_class = TimetableFilterSet

    def get_queryset(self):
        """
        Returns a queryset of published Datasets for active Organisations that
        are of TimetableType and not dummy datasets, with related 'live_revision'
        and 'organisation' preloaded. It also prefetches related 'txc_file_attributes'
        for the 'live_revision'.
        """
        return (
            Dataset.objects.get_published()
            .get_active_org()
            .select_related("live_revision", "organisation")
            .prefetch_related("live_revision__txc_file_attributes")
            .filter(dataset_type=TimetableType, is_dummy=False)
        )


class TimetableFilesViewSet(ReadOnlyModelViewSet):
    """
    ViewSet for browsing a list of timetable files or retrieving a single timetable file.
    
    It uses the TXCFileSerializer for serialization, filters results based on
    the TimetableFileFilterSet, and allows ordering by 'id', 'operating_period_start_date',
    and 'filename'.
    """
    serializer_class = TXCFileSerializer
    filterset_class = TimetableFileFilterSet
    ordering_fields = ["id", "operating_period_start_date", "filename"]

    def get_queryset(self):
        """
        Returns a queryset of active TXCFileAttributes for live revisions, with
        related 'revision' preloaded.
        """
        return TXCFileAttributes.objects.get_active_live_revisions().select_related(
            "revision"
        )
```

from rest_framework.viewsets import ReadOnlyModelViewSet

from transit_odp.api.filters.v2 import (
    OperatorFilterSet,
    TimetableFileFilterSet,
    TimetableFilterSet,
)
from transit_odp.api.serializers.v2 import (
    DatafeedSerializer,
    OperatorSerializer,
    TimetableSerializer,
    TXCFileSerializer,
)
from transit_odp.organisation.constants import AVLType, TimetableType
from transit_odp.organisation.models import Dataset, Organisation, TXCFileAttributes


class OperatorViewSet(ReadOnlyModelViewSet):
    serializer_class = OperatorSerializer
    ordering_fields = ["id", "name", "short_name"]
    filterset_class = OperatorFilterSet

    def get_queryset(self):
        return (
            Organisation.objects.filter(is_active=True)
            .prefetch_related("licences", "nocs")
            .order_by("id")
        )


class DatafeedViewSet(ReadOnlyModelViewSet):
    serializer_class = DatafeedSerializer
    ordering_fields = ["id", "modified"]

    def get_queryset(self):
        return (
            Dataset.objects.get_published()
            .get_active_org()
            .select_related("live_revision", "organisation")
            .filter(dataset_type=AVLType, is_dummy=False)
        )


class TimetableViewSet(ReadOnlyModelViewSet):
    serializer_class = TimetableSerializer
    filterset_class = TimetableFilterSet

    def get_queryset(self):
        return (
            Dataset.objects.get_published()
            .get_active_org()
            .select_related("live_revision", "organisation")
            .prefetch_related("live_revision__txc_file_attributes")
            .filter(dataset_type=TimetableType, is_dummy=False)
        )


class TimetableFilesViewSet(ReadOnlyModelViewSet):
    serializer_class = TXCFileSerializer
    filterset_class = TimetableFileFilterSet
    ordering_fields = ["id", "operating_period_start_date", "filename"]

    def get_queryset(self):
        return TXCFileAttributes.objects.get_active_live_revisions().select_related(
            "revision"
        )
