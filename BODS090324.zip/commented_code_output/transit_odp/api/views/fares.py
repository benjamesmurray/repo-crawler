```python
from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.gis.geos import Polygon
from django.views.generic import TemplateView
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from transit_odp.api import filters
from transit_odp.api.serializers import FaresDatasetSerializer
from transit_odp.api.validators import (
    validate_api_parameter_keys,
    validate_api_parameter_values,
)
from transit_odp.api.views import DatasetBaseViewSet
from transit_odp.common.utils.get_bounding_box import get_bounding_box
from transit_odp.organisation.constants import DatasetType
from transit_odp.organisation.models import Dataset

FARES = DatasetType.FARES.value

valid_parameters = [
    "limit",
    "offset",
    "noc",
    "boundingBox",
    "api_key",
    "status",
    "format",
]

class FaresDatasetViewset(DatasetBaseViewSet):
    """
    Viewset for handling requests for the Fares Dataset.

    Inherits from DatasetBaseViewSet and sets specific attributes and methods
    for filtering, serializing, and querying Fares Dataset instances.
    """
    dataset_type = FARES
    permission_classes = (IsAuthenticated,)
    serializer_class = FaresDatasetSerializer
    filterset_class = filters.FaresDatasetFilterSet

    def list(self, request, *args, **kwargs):
        """
        List fares datasets with validation of query parameters.

        Validates the query parameter keys and values before listing the datasets.
        Returns a 400 response with information on invalid parameters if found.
        """
        # Check for invalid query parameter keys and values
        invalid_parameter_keys = validate_api_parameter_keys(
            self.request.query_params, valid_parameters
        )
        invalid_parameter_values = validate_api_parameter_values(
            self.request.query_params
        )
        # If invalid keys or values are found, return a 400 response
        if len(invalid_parameter_keys) > 0:
            content = {"Unsupported query parameter": invalid_parameter_keys}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)

        if len(invalid_parameter_values) > 0:
            content = {
                "Unsupported query parameter value for": invalid_parameter_values
            }
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        return super().list(self, request, *args, **kwargs)

    def get_queryset(self):
        """
        Get the queryset of Fares Dataset instances.

        Filters the queryset based on the published status, viewable statuses,
        active organizations, and bounding box if provided in the request.
        Orders and returns the distinct set of dataset instances.
        """
        qs = (
            Dataset.objects.get_published()
            .filter(dataset_type=DatasetType.FARES.value)
            .get_viewable_statuses()
            .get_active_org()
            .add_organisation_name()
            .select_related("live_revision")
            .prefetch_related("organisation__nocs")
            .prefetch_related("live_revision__metadata__faresmetadata__stops")
        )

        status_list = self.request.GET.getlist("status", [])
        if not self.request.resolver_match.kwargs:
            if not status_list or "" in status_list:
                status_list = ["live"]
            elif status_list and "" not in status_list:
                status_list = [
                    status.replace("published", "live") for status in status_list
                ]
            qs = qs.filter(live_revision__status__in=status_list)
        bounding_box = self.request.GET.getlist("boundingBox", [])
        if bounding_box:
            box = get_bounding_box(bounding_box)
            geom = Polygon.from_bbox(box)
            qs = qs.filter(
                live_revision__metadata__faresmetadata__stops__location__within=geom
            )
        qs = qs.order_by("id").distinct()

        return qs


class FaresOpenApiView(LoginRequiredMixin, TemplateView):
    """
    Template view for the Fares OpenAPI documentation.

    Requires user to be logged in and renders the OpenAPI documentation
    for the Fares Dataset API.
    """
    template_name = "swagger_ui/fares.html"
```

from django.contrib.auth.mixins import LoginRequiredMixin
from django.contrib.gis.geos import Polygon
from django.views.generic import TemplateView
from rest_framework import status
from rest_framework.permissions import IsAuthenticated
from rest_framework.response import Response

from transit_odp.api import filters
from transit_odp.api.serializers import FaresDatasetSerializer
from transit_odp.api.validators import (
    validate_api_parameter_keys,
    validate_api_parameter_values,
)
from transit_odp.api.views import DatasetBaseViewSet
from transit_odp.common.utils.get_bounding_box import get_bounding_box
from transit_odp.organisation.constants import DatasetType
from transit_odp.organisation.models import Dataset

FARES = DatasetType.FARES.value

valid_parameters = [
    "limit",
    "offset",
    "noc",
    "boundingBox",
    "api_key",
    "status",
    "format",
]


class FaresDatasetViewset(DatasetBaseViewSet):
    dataset_type = FARES
    permission_classes = (IsAuthenticated,)
    serializer_class = FaresDatasetSerializer
    filterset_class = filters.FaresDatasetFilterSet

    def list(self, request, *args, **kwargs):
        # Check for invalid query parameter keys and values
        invalid_parameter_keys = validate_api_parameter_keys(
            self.request.query_params, valid_parameters
        )
        invalid_parameter_values = validate_api_parameter_values(
            self.request.query_params
        )
        # TODO could be refactored to handle invalid keys and
        # values in the same Response
        if len(invalid_parameter_keys) > 0:
            content = {"Unsupported query parameter": invalid_parameter_keys}
            return Response(content, status=status.HTTP_400_BAD_REQUEST)

        if len(invalid_parameter_values) > 0:
            content = {
                "Unsupported query parameter value for": invalid_parameter_values
            }
            return Response(content, status=status.HTTP_400_BAD_REQUEST)
        return super().list(self, request, *args, **kwargs)

    def get_queryset(self):
        qs = (
            Dataset.objects.get_published()
            .filter(dataset_type=DatasetType.FARES.value)
            .get_viewable_statuses()
            .get_active_org()
            .add_organisation_name()
            .select_related("live_revision")
            .prefetch_related("organisation__nocs")
            .prefetch_related("live_revision__metadata__faresmetadata__stops")
        )

        status_list = self.request.GET.getlist("status", [])
        if not self.request.resolver_match.kwargs:
            if not status_list or "" in status_list:
                status_list = ["live"]
            elif status_list and "" not in status_list:
                status_list = [
                    status.replace("published", "live") for status in status_list
                ]
            qs = qs.filter(live_revision__status__in=status_list)
        bounding_box = self.request.GET.getlist("boundingBox", [])
        if bounding_box:
            box = get_bounding_box(bounding_box)
            geom = Polygon.from_bbox(box)
            qs = qs.filter(
                live_revision__metadata__faresmetadata__stops__location__within=geom
            )
        qs = qs.order_by("id").distinct()

        return qs


class FaresOpenApiView(LoginRequiredMixin, TemplateView):
    """View for Fares Dataset API."""

    template_name = "swagger_ui/fares.html"
