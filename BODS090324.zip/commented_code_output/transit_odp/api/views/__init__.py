```python
from transit_odp.api.views.avl import (
    AVLApiView,
    AVLDetailApiView,
    AVLGTFSRTApiView,
    AVLOpenApiView,
)
from transit_odp.api.views.base import DatasetBaseViewSet, DatasetViewSet
from transit_odp.api.views.fares import FaresDatasetViewset, FaresOpenApiView
from transit_odp.api.views.timetables import TimetablesApiView, TimetablesViewSet
from transit_odp.api.views.disruptions import DisruptionsOpenApiView

# This module provides a list of API views that are available for import elsewhere.
# It includes views for handling different types of datasets such as AVL, Fares,
# Timetables, and Disruptions. Each view is designed to interact with a specific
# type of dataset and provides an interface for operations like retrieval, update,
# or detail view.

__all__ = [
    "AVLApiView",              # Provides API view for AVL (Automatic Vehicle Location) data.
    "AVLGTFSRTApiView",        # Provides API view for AVL data in GTFS Realtime format.
    "AVLOpenApiView",          # Provides an open API view for AVL data.
    "AVLDetailApiView",        # Provides a detailed API view for a single AVL dataset.
    "DatasetBaseViewSet",      # Base viewset for dataset-related API views.
    "DatasetViewSet",          # Provides API viewset for handling generic datasets.
    "FaresDatasetViewset",     # Provides API viewset for handling fares datasets.
    "FaresOpenApiView",        # Provides an open API view for fares data.
    "TimetablesApiView",       # Provides API view for timetables data.
    "TimetablesViewSet",       # Provides API viewset for handling timetables datasets.
    "DisruptionsOpenApiView",  # Provides an open API view for disruptions data.
]
```

from transit_odp.api.views.avl import (
    AVLApiView,
    AVLDetailApiView,
    AVLGTFSRTApiView,
    AVLOpenApiView,
)
from transit_odp.api.views.base import DatasetBaseViewSet, DatasetViewSet
from transit_odp.api.views.fares import FaresDatasetViewset, FaresOpenApiView
from transit_odp.api.views.timetables import TimetablesApiView, TimetablesViewSet
from transit_odp.api.views.disruptions import DisruptionsOpenApiView

__all__ = [
    "AVLApiView",
    "AVLGTFSRTApiView",
    "AVLOpenApiView",
    "AVLDetailApiView",
    "DatasetBaseViewSet",
    "DatasetViewSet",
    "FaresDatasetViewset",
    "FaresOpenApiView",
    "TimetablesApiView",
    "TimetablesViewSet",
    "DisruptionsOpenApiView",
]
