```python
import json
from pathlib import Path
from typing import Dict, List

from pydantic import BaseModel

class Rule(BaseModel):
    """
    Represents a single rule within an observation.

    Attributes:
        test: A string representing the condition or test for this rule.
    """
    test: str


class Observation(BaseModel):
    """
    Represents an observation which is a collection of rules and additional metadata.

    Attributes:
        details: A string detailing the observation.
        category: A string representing the category of the observation.
        context: A string providing the context in which the observation applies.
        rules: A list of Rule instances associated with this observation.
    """
    details: str
    category: str
    context: str
    rules: List[Rule]


class Header(BaseModel):
    """
    Represents the header information of a schema.

    Attributes:
        namespaces: A dictionary mapping string keys to string values representing namespace information.
    """
    namespaces: Dict[str, str]


class Schema(BaseModel):
    """
    Represents the entire schema with observations and header information.

    Attributes:
        observations: A list of Observation instances that the schema comprises.
        header: A Header instance containing the header information of the schema.
    """
    observations: List[Observation]
    header: Header

    @classmethod
    def from_path(cls, path: Path):
        """
        Class method to create a Schema instance from a JSON file located at the given path.

        Parameters:
            path: A Path object pointing to the JSON file to be loaded.

        Returns:
            An instance of Schema initialized with the data from the JSON file.
        """
        with path.open("r") as f:
            d = json.load(f)
            return cls(**d)


class Violation(BaseModel):
    """
    Represents a violation which is an occurrence of an observation in a specific context.

    Attributes:
        line: An integer indicating the line number where the violation occurred.
        filename: A string representing the name of the file where the violation was found.
        observation: A string detailing the observation related to the violation.
        category: A string representing the category of the violation.
    """
    line: int
    filename: str
    observation: str
    category: str
```

import json
from pathlib import Path
from typing import Dict, List

from pydantic import BaseModel


class Rule(BaseModel):
    test: str


class Observation(BaseModel):
    details: str
    category: str
    context: str
    rules: List[Rule]


class Header(BaseModel):
    namespaces: Dict[str, str]


class Schema(BaseModel):
    observations: List[Observation]
    header: Header

    @classmethod
    def from_path(cls, path: Path):
        with path.open("r") as f:
            d = json.load(f)
            return cls(**d)


class Violation(BaseModel):
    line: int
    filename: str
    observation: str
    category: str
