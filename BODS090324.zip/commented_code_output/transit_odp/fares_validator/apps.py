```python
from django.apps import AppConfig

class FaresValidatorConfig(AppConfig):
    """
    Configuration class for the 'fares_validator' Django app.

    This class is used to set up the app with the Django framework.
    It defines the default auto field type for model IDs and provides
    a human-readable name for the app.

    Attributes:
        default_auto_field (str): Specifies the type of auto field to use for
                                  primary keys. Defaults to BigAutoField.
        name (str): The full Python path to the application, used by Django
                    to identify the app within the project.
        verbose_name (str): A human-readable name for the application, which
                            is used in the Django admin interface.
    """
    default_auto_field = "django.db.models.BigAutoField"
    name = "transit_odp.fares_validator"
    verbose_name = "fares_validator"
```

from django.apps import AppConfig


class FaresValidatorConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "transit_odp.fares_validator"
    verbose_name = "fares_validator"
