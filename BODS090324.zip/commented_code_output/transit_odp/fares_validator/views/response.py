```python
class XMLViolationDetail:
    """
    Represents details of an XML violation, including whether a violation occurred,
    the line where it happened, and the corresponding message.

    Attributes:
        is_violation (str): A string indicating if a violation occurred.
        violation_line (str): The line number where the violation occurred as a string.
        violation_message (str): A descriptive message about the violation.
        violation_detail (list): A list containing the violation details.
    """

    def __init__(self, is_violation, violation_line=None, violation_message=None):
        """
        Initializes the XMLViolationDetail object with violation status, line, and message.

        Parameters:
            is_violation (str): A string indicating if a violation occurred ('violation' or other).
            violation_line (int or None): The line number where the violation occurred.
            violation_message (str or None): A descriptive message about the violation.
        """
        self.is_violation = is_violation
        self.violation_line = str(violation_line)
        self.violation_message = violation_message
        self.violation_detail = []
        if is_violation == "violation":
            self.violation_detail = [
                self.is_violation,
                self.violation_line,
                self.violation_message,
            ]

    def __list__(self):
        """
        Returns the violation details as a list.

        Returns:
            list: A list containing the is_violation status, violation_line, and violation_message.
        """
        return self.violation_detail
```

"""
Used for forming responses for validator functions
"""


class XMLViolationDetail:
    def __init__(self, is_violation, violation_line=None, violation_message=None):
        self.is_violation = is_violation
        self.violation_line = str(violation_line)
        self.violation_message = violation_message
        self.violation_detail = []
        if is_violation == "violation":
            self.violation_detail = [
                self.is_violation,
                self.violation_line,
                self.violation_message,
            ]

    def __list__(self):
        return self.violation_detail
