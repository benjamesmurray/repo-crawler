```python
from __future__ import annotations

import zipfile
from logging import getLogger
from pathlib import Path
from typing import BinaryIO, Iterable, List

from transit_odp.common.loggers import DatasetPipelineLoggerContext, PipelineAdapter
from transit_odp.common.types import JSONFile
from transit_odp.data_quality.pti.models import Violation
from transit_odp.fares_validator.views.validators import FaresValidator

FARES_SCHEMA = Path(__file__).parent.parent / "schema" / "fares_schema.json"

logger = getLogger(__name__)


class DatasetFaresValidator:
    """
    A class to validate dataset files against a FARES JSON schema.

    Attributes:
        _validator (FaresValidator): An instance of FaresValidator to validate files.

    Methods:
        iter_get_files(file, revision): Generator to iterate over files in a ZIP or a single file.
        get_violations(file, revision): Validates files and returns a list of violations.
        from_path(path): Class method to create an instance of DatasetFaresValidator from a path.
    """

    def __init__(self, schema: JSONFile):
        """
        Initializes the DatasetFaresValidator with a schema.

        Args:
            schema (JSONFile): The JSON schema file against which the datasets will be validated.
        """
        self._validator = FaresValidator(schema)

    def iter_get_files(self, file, revision) -> Iterable[BinaryIO]:
        """
        Iterates over files within a ZIP file or a single file, yielding each as a binary stream.

        Args:
            file (BinaryIO): The ZIP file or a single file to process.
            revision (Any): The revision identifier for logging purposes.

        Yields:
            BinaryIO: The next file in the ZIP file or the single file as a binary stream.
        """
        context = DatasetPipelineLoggerContext(
            component_name="FaresPipeline", object_id=revision
        )
        adapter = PipelineAdapter(logger, {"context": context})
        if zipfile.is_zipfile(file):
            with zipfile.ZipFile(file) as zf:
                names = [n for n in zf.namelist() if n.endswith(".xml")]
                file_count = len(names)
                for index, name in enumerate(names, start=1):
                    adapter.info(
                        f"Fares Validation of file {index} of {file_count} - {name}."
                    )
                    if not name.startswith("__"):
                        with zf.open(name) as f:
                            yield f
        else:
            file.seek(0)
            yield file

    def get_violations(self, file, revision) -> List[Violation]:
        """
        Validates the files and returns a list of violations found.

        Args:
            file (BinaryIO): The ZIP file or a single file to validate.
            revision (Any): The revision identifier for logging purposes.

        Returns:
            List[Violation]: A list of violations detected during validation.
        """
        for xml in self.iter_get_files(file, revision=revision):
            xml.seek(0)
            self._validator.is_valid(xml)

        return self._validator.violations

    @classmethod
    def from_path(cls, path: Path) -> DatasetFaresValidator:
        """
        Creates an instance of DatasetFaresValidator from a JSON schema file path.

        Args:
            path (Path): The path to the JSON schema file.

        Returns:
            DatasetFaresValidator: An instance of DatasetFaresValidator.
        """
        with path.open("r") as schema_file:
            return cls(schema_file)


def get_fares_validator() -> DatasetFaresValidator:
    """
    Gets a FARES JSON Schema and returns a DatasetFaresValidator.

    Returns:
        DatasetFaresValidator: An instance of DatasetFaresValidator initialized with the FARES JSON schema.
    """
    with FARES_SCHEMA.open("r") as f:
        fares_validator = DatasetFaresValidator(f)
    return fares_validator
```

from __future__ import annotations

import zipfile
from logging import getLogger
from pathlib import Path
from typing import BinaryIO, Iterable, List

from transit_odp.common.loggers import DatasetPipelineLoggerContext, PipelineAdapter
from transit_odp.common.types import JSONFile
from transit_odp.data_quality.pti.models import Violation
from transit_odp.fares_validator.views.validators import FaresValidator

FARES_SCHEMA = Path(__file__).parent.parent / "schema" / "fares_schema.json"

logger = getLogger(__name__)


class DatasetFaresValidator:
    def __init__(self, schema: JSONFile):
        self._validator = FaresValidator(schema)

    def iter_get_files(self, file, revision) -> Iterable[BinaryIO]:
        context = DatasetPipelineLoggerContext(
            component_name="FaresPipeline", object_id=revision
        )
        adapter = PipelineAdapter(logger, {"context": context})
        if zipfile.is_zipfile(file):
            with zipfile.ZipFile(file) as zf:
                names = [n for n in zf.namelist() if n.endswith(".xml")]
                file_count = len(names)
                for index, name in enumerate(names, start=1):
                    adapter.info(
                        f"Fares Validation of file {index} of {file_count} - {name}."
                    )
                    if not name.startswith("__"):
                        with zf.open(name) as f:
                            yield f
        else:
            file.seek(0)
            yield file

    def get_violations(self, file, revision) -> List[Violation]:
        for xml in self.iter_get_files(file, revision=revision):
            xml.seek(0)
            self._validator.is_valid(xml)

        return self._validator.violations

    @classmethod
    def from_path(cls, path: Path) -> DatasetFaresValidator:
        with path.open("r") as schema_file:
            return cls(schema_file)


def get_fares_validator() -> DatasetFaresValidator:
    """
    Gets a FARES JSON Schema and returns a DatasetFaresValidator.
    """
    with FARES_SCHEMA.open("r") as f:
        fares_validator = DatasetFaresValidator(f)
    return fares_validator
