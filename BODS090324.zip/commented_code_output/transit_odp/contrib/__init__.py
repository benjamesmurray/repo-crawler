```python
"""
To understand why this file is here, please read:

http://cookiecutter-django.readthedocs.io/en/latest/faq.html#why-is-there-a-django-contrib-sites-directory-in-cookiecutter-django
"""

from django.db import models
from django.conf import settings

class SiteProfile(models.Model):
    """
    This is a model class for a site profile, which extends the base Site model
    from django.contrib.sites to include additional site-specific information.

    Attributes:
        site (OneToOneField): A one-to-one relationship linking to Django's built-in Site model.
        description (TextField): A text field to store additional information about the site.
    """
    site = models.OneToOneField(settings.SITE_ID, on_delete=models.CASCADE)
    description = models.TextField()

    def __str__(self):
        """
        Returns a string representation of the SiteProfile, which includes the site name.

        Returns:
            str: The name of the site linked to this profile.
        """
        return self.site.name
```

"""
To understand why this file is here, please read:

http://cookiecutter-django.readthedocs.io/en/latest/faq.html#why-is-there-a-django-contrib-sites-directory-in-cookiecutter-django
"""
