```python
from django.core.files.storage import Storage, default_storage
from django.db import models

class CallableStorageFileField(models.FileField):
    """
    A FileField subclass that accepts a callable as the storage option, allowing
    for lazy initialization of the storage backend.

    Attributes:
        verbose_name (str): An optional human-readable name for the field.
        name (str): The name of the field within the model.
        upload_to (str, callable): A path or a callable that returns a path that
                                   defines where to upload the file.
        storage (Storage, callable): A storage backend instance or a callable that
                                     returns a storage backend instance.
    """
    def __init__(
        self, verbose_name=None, name=None, upload_to="", storage=None, **kwargs
    ):
        super().__init__(verbose_name, name, **kwargs)
        self.storage = storage or default_storage
        if callable(self.storage):
            # Hold a reference to the callable for deconstruct().
            self._storage_callable = self.storage
            self.storage = self.storage()
            if not isinstance(self.storage, Storage):
                raise TypeError(
                    "%s.storage must be a subclass/instance of %s.%s"
                    % (
                        self.__class__.__qualname__,
                        Storage.__module__,
                        Storage.__qualname__,
                    )
                )

    def deconstruct(self):
        """
        Deconstruct the field to a serializable state.

        Returns:
            tuple: A tuple containing the field name, import path, positional
                   arguments, and keyword arguments.
        """
        name, path, args, kwargs = super().deconstruct()
        if self.storage is not default_storage:
            kwargs["storage"] = getattr(self, "_storage_callable", self.storage)
        return name, path, args, kwargs


class NullFileField(models.FileField):
    """
    A FileField subclass that defaults to unique=True and saves unset files
    as NULL in the database, rather than storing an empty string.

    Attributes:
        unique (bool): Whether the field is required to be unique throughout the model.
        null (bool): Whether to store empty files as NULL in the database.
        blank (bool): Whether the field is allowed to be blank.
    """
    def __init__(self, *args, **kwargs):
        kwargs.setdefault("unique", True)
        kwargs["null"] = True
        kwargs["blank"] = True
        super().__init__(*args, **kwargs)

    def deconstruct(self):
        """
        Deconstruct the field to a serializable state.

        Returns:
            tuple: A tuple containing the field name, import path, positional
                   arguments, and keyword arguments.
        """
        name, path, args, kwargs = super().deconstruct()
        if self.null is not False:
            kwargs["null"] = True
        if self.blank is not True:
            kwargs["blank"] = False
        if self.unique is not True:
            kwargs["unique"] = False
        return name, path, args, kwargs

    def get_prep_value(self, value):
        """
        Prepare the value for database storage.

        Parameters:
            value (str): The file's value to prepare.

        Returns:
            str or None: The prepared value, or None if the original value was an empty string.
        """
        value = super().get_prep_value(value)
        if value == "":
            value = None
        return value
```

from django.core.files.storage import Storage, default_storage
from django.db import models


class CallableStorageFileField(models.FileField):
    """Backport of __init__ for Django 3.1 FileField adds the option to
    specify a callable storage.
    """

    def __init__(
        self, verbose_name=None, name=None, upload_to="", storage=None, **kwargs
    ):
        super().__init__(verbose_name, name, **kwargs)
        self.storage = storage or default_storage
        if callable(self.storage):
            # Hold a reference to the callable for deconstruct().
            self._storage_callable = self.storage
            self.storage = self.storage()
            if not isinstance(self.storage, Storage):
                raise TypeError(
                    "%s.storage must be a subclass/instance of %s.%s"
                    % (
                        self.__class__.__qualname__,
                        Storage.__module__,
                        Storage.__qualname__,
                    )
                )

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        if self.storage is not default_storage:
            kwargs["storage"] = getattr(self, "_storage_callable", self.storage)
        return name, path, args, kwargs


class NullFileField(models.FileField):
    """
    A custom FileField which defaults unique=True and saves unset files to the
    DB as NULL rather than an empty string
    """

    def __init__(self, *args, **kwargs):
        kwargs.setdefault("unique", True)
        kwargs["null"] = True
        kwargs["blank"] = True
        super().__init__(*args, **kwargs)

    def deconstruct(self):
        name, path, args, kwargs = super().deconstruct()
        if self.null is not False:
            kwargs["null"] = True
        if self.blank is not True:
            kwargs["blank"] = False
        if self.unique is not True:
            kwargs["unique"] = False
        return name, path, args, kwargs

    def get_prep_value(self, value):
        value = super().get_prep_value(value)
        if value == "":
            value = None
        return value
