```python
from contextlib import contextmanager

from django.contrib.messages.middleware import MessageMiddleware
from django.contrib.sessions.middleware import SessionMiddleware
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse

def get_response_for_test(request):
    """
    A mock response function for testing purposes.
    
    Parameters:
    - request: The WSGIRequest object.

    Returns:
    - HttpResponse object for testing.
    """
    return HttpResponse()

def add_session_middleware(request: WSGIRequest):
    """
    Add session middleware to the given request object.
    
    This function processes the request through the SessionMiddleware
    which handles session management for Django views.

    Parameters:
    - request: The WSGIRequest object that needs session handling.

    Returns:
    - The modified request object with session middleware applied.
    """
    middleware = SessionMiddleware(get_response=get_response_for_test)
    middleware.process_request(request)
    request.session.save()
    return request

def add_message_middleware(request: WSGIRequest):
    """
    Add message middleware to the given request object.
    
    This function processes the request through the MessageMiddleware
    which handles temporary messages for Django views.

    Parameters:
    - request: The WSGIRequest object that needs message handling.

    Returns:
    - The modified request object with message middleware applied.
    """
    middleware = MessageMiddleware(get_response=get_response_for_test)
    middleware.process_request(request)
    request.session.save()
    return request

@contextmanager
def does_not_raise():
    """
    A context manager for use in tests to explicitly state that an exception is not expected.
    
    Yields:
    - None, but provides a clear syntax for a 'no exception expected' context.
    """
    yield
```

from contextlib import contextmanager

from django.contrib.messages.middleware import MessageMiddleware
from django.contrib.sessions.middleware import SessionMiddleware
from django.core.handlers.wsgi import WSGIRequest
from django.http import HttpResponse


def get_response_for_test(request):
    return HttpResponse()


def add_session_middleware(request: WSGIRequest):
    """Add session middleware to request"""
    middleware = SessionMiddleware(get_response=get_response_for_test)
    middleware.process_request(request)
    request.session.save()
    return request


def add_message_middleware(request: WSGIRequest):
    """Add message middleware to request"""
    middleware = MessageMiddleware(get_response=get_response_for_test)
    middleware.process_request(request)
    request.session.save()
    return request


@contextmanager
def does_not_raise():
    yield
