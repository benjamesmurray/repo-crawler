```python
from typing import IO, Any, AnyStr, Union

# Type alias for a file that can be either a string path or a file-like object containing XML data.
XMLFile = Union[AnyStr, IO[Any]]

# Type alias for a file-like object containing JSON data.
JSONFile = IO[Any]
```

from typing import IO, Any, AnyStr, Union

XMLFile = Union[AnyStr, IO[Any]]
JSONFile = IO[Any]
