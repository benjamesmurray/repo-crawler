```python
import attr

@attr.s(auto_attribs=True)
class RangeFilter(object):
    """
    A class representing a filter for a range of values.

    Attributes:
        filter (str): The range to filter on, in a specific format.
        display (str): The human-readable representation of the filter.
        disabled (bool): Flag indicating whether the filter is disabled.
    """
    filter: str
    display: str
    disabled: bool
```

import attr


@attr.s(auto_attribs=True)
class RangeFilter(object):
    # A range to filter on
    filter: str
    display: str
    disabled: bool
