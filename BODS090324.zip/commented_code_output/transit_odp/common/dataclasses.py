```python
from dataclasses import dataclass

@dataclass
class AnchorTag:
    """
    Represents an HTML anchor tag.

    Attributes:
        href (str): The hyperlink reference (URL) that the anchor tag points to.
        content (str): The text or content displayed for the anchor tag.
    """
    href: str
    content: str
```

from dataclasses import dataclass


@dataclass
class AnchorTag:
    href: str
    content: str
