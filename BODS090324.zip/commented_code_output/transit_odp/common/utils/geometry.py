```python
import pyproj
from shapely.geometry import Point
from shapely.ops import transform

def grid_gemotry_from_str(easting, northing):
    """
    Create a geometry object from string representations of easting and northing coordinates.

    Parameters:
    easting (str): The easting coordinate as a string.
    northing (str): The northing coordinate as a string.

    Returns:
    shapely.geometry.Point: A point object in WGS84 coordinate system.
    """
    point = Point(float(easting), float(northing))
    return construct_geometry(point)

def wsg84_from_str(longitude, latitude):
    """
    Create a WGS84 Point object from string representations of longitude and latitude.

    Parameters:
    longitude (str): The longitude coordinate as a string.
    latitude (str): The latitude coordinate as a string.

    Returns:
    shapely.geometry.Point: A point object in WGS84 coordinate system.
    """
    return Point(float(longitude), float(latitude))

def osgb36_to_wgs84(osgb36_point):
    """
    Convert a point from OSGB36 coordinate system to WGS84 coordinate system.

    Parameters:
    osgb36_point (shapely.geometry.Point): A point object in OSGB36 coordinate system.

    Returns:
    shapely.geometry.Point: A point object in WGS84 coordinate system.
    """
    wgs84 = pyproj.CRS("EPSG:4326")
    osgb36 = pyproj.CRS("EPSG:27700")
    project = pyproj.Transformer.from_crs(osgb36, wgs84, always_xy=True).transform
    wgs84_point = transform(project, osgb36_point)
    return wgs84_point

def construct_geometry(point: Point):
    """
    Convert a point from OSGB36 to WGS84 coordinate system.

    Parameters:
    point (shapely.geometry.Point): A point object in OSGB36 coordinate system.

    Returns:
    shapely.geometry.Point: A point object in WGS84 coordinate system.
    """
    return osgb36_to_wgs84(point)
```

import pyproj
from shapely.geometry import Point
from shapely.ops import transform


def grid_gemotry_from_str(easting, northing):
    point = Point(float(easting), float(northing))
    return construct_geometry(point)


def wsg84_from_str(longitude, latitude):
    return Point(float(longitude), float(latitude))


def osgb36_to_wgs84(osgb36_point):
    wgs84 = pyproj.CRS("EPSG:4326")
    osgb36 = pyproj.CRS("EPSG:27700")
    project = pyproj.Transformer.from_crs(osgb36, wgs84, always_xy=True).transform
    wgs84_point = transform(project, osgb36_point)
    return wgs84_point


def construct_geometry(point: Point):
    return osgb36_to_wgs84(point)
