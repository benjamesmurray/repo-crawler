```python
def to_int_or_value(value):
    """
    Attempt to convert a given value to an integer; if conversion fails, return the original value.
    
    Parameters:
    value (str or int): The value to be converted to an integer.
    
    Returns:
    int or original type: The converted integer if successful, or the original value if conversion fails.
    """
    try:
        return int(value)
    except ValueError:
        return value
```

def to_int_or_value(value):
    """Either cast an object to an integer else return the original object."""
    try:
        return int(value)
    except ValueError:
        return value
