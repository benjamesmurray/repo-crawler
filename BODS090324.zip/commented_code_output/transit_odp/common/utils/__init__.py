```python
import hashlib
import math
from typing import Union
from urllib.parse import parse_qs, urlencode, urlparse

from django_hosts import reverse

def remove_query_string_param(query_string: str, key: str) -> str:
    """
    Remove a specified key from the query string.
    
    :param query_string: The original query string from a URL.
    :param key: The key to be removed from the query string.
    :return: The modified query string with the specified key removed.
    """
    query_params = parse_qs(query_string)
    query_params.pop(key, None)
    query_string = urlencode(query_params, doseq=True)
    return query_string


def get_dataset_type_from_path_info(path_info: str) -> str:
    """
    Determine the dataset type based on the path info of a URL.
    
    :param path_info: The path component of a URL.
    :return: A string representing the dataset type inferred from the path info.
    """
    dataset_type = ""
    if "/datafeed" in path_info:
        dataset_type = "SIRI VM"
    elif "/gtfsrtdatafeed" in path_info:
        dataset_type = "GTFS RT"
    elif "/fares" in path_info:
        dataset_type = "Fares"
    elif "/dataset" in path_info:
        dataset_type = "Timetable"
    else:
        return dataset_type
    return dataset_type


def round_down(value: float):
    """
    Round down a float value to three decimal places.
    
    :param value: The float value to be rounded down.
    :return: The value rounded down to three decimal places.
    """
    return math.floor(value * 1000.0) / 1000.0


def reverse_path(*args, **kwargs) -> str:
    """
    Use django_hosts to reverse a URL pattern and return only the path component.
    
    :param args: Positional arguments passed to django_hosts.reverse.
    :param kwargs: Keyword arguments passed to django_hosts.reverse.
    :return: The path component of the reversed URL.
    """
    full_url = reverse(*args, **kwargs)
    parsed_url = urlparse(full_url)
    return parsed_url.path


def sha1sum(content: Union[bytes, bytearray, memoryview]) -> str:
    """
    Calculate the SHA-1 hash of the given content and return it as a hex string.
    
    :param content: The content to hash. Can be bytes, bytearray, or memoryview.
    :return: The SHA-1 hash of the content as a hex string.
    """
    return hashlib.sha1(content).hexdigest()
```

import hashlib
import math
from typing import Union
from urllib.parse import parse_qs, urlencode, urlparse

from django_hosts import reverse


def remove_query_string_param(query_string: str, key: str) -> str:
    """If a query string contains a `key` field remove it."""
    query_params = parse_qs(query_string)
    query_params.pop(key, None)
    query_string = urlencode(query_params, doseq=True)
    return query_string


def get_dataset_type_from_path_info(path_info: str) -> str:
    """Update the raw api based on `path_info`"""
    dataset_type = ""
    if "/datafeed" in path_info:
        dataset_type = "SIRI VM"
    elif "/gtfsrtdatafeed" in path_info:
        dataset_type = "GTFS RT"
    elif "/fares" in path_info:
        dataset_type = "Fares"
    elif "/dataset" in path_info:
        dataset_type = "Timetable"
    else:
        return dataset_type
    return dataset_type


def round_down(value: float):
    return math.floor(value * 1000.0) / 1000.0


def reverse_path(*args, **kwargs) -> str:
    """
    django_hosts reverse helper function
    does a reverse but only return the path info
    args and kwargs are the same as django_hosts.reverse
    returns path string of resource
    """
    full_url = reverse(*args, **kwargs)
    parsed_url = urlparse(full_url)
    return parsed_url.path


def sha1sum(content: Union[bytes, bytearray, memoryview]) -> str:
    """
    Takes the sha1 of a string and returns a hex string
    """
    return hashlib.sha1(content).hexdigest()
