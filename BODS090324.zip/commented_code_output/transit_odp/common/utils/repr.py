```python
def nice_repr(instance):
    """
    Generate a 'nice' string representation of an instance with its class name and attributes.
    
    This function takes an instance of any class, extracts its class name and its public attributes,
    and formats them into a string that resembles a constructor call.
    
    Parameters:
    - instance: The instance of a class to be represented as a string.
    
    Returns:
    - A string that includes the class name followed by its public attributes in key=value format.
    """
    class_name = instance.__class__.__name__  # Get the name of the class
    attrs = ", ".join(
        f"{key}={value!r}"  # Format each key-value pair with the key, an equals sign, and the repr of the value
        for key, value in instance.__dict__.items()  # Iterate over the instance's dictionary
        if not key.startswith("_")  # Exclude private attributes that start with an underscore
    )
    return f"{class_name}({attrs})"  # Return the formatted string
```

def nice_repr(instance):
    class_name = instance.__class__.__name__
    attrs = ", ".join(
        f"{key}={value!r}"
        for key, value in instance.__dict__.items()
        if not key.startswith("_")
    )
    return f"{class_name}({attrs})"
