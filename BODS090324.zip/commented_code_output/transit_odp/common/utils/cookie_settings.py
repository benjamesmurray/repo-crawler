```python
import datetime
from django.conf import settings

def set_cookie(response, key, value, days_expire=7):
    """
    Set a cookie on an HttpResponse object with a specified expiration.

    :param response: HttpResponse object where the cookie will be set.
    :param key: The name of the cookie.
    :param value: The value of the cookie.
    :param days_expire: The number of days until the cookie expires. Defaults to 7 days.
                        If None, the cookie will expire in one year.
    """
    if days_expire is None:
        max_age = 365 * 24 * 60 * 60  # one year
    else:
        max_age = days_expire * 24 * 60 * 60
    expires = datetime.datetime.strftime(
        datetime.datetime.utcnow() + datetime.timedelta(seconds=max_age),
        "%a, %d-%b-%Y %H:%M:%S GMT",
    )
    response.set_cookie(
        key,
        value,
        max_age=max_age,
        expires=expires,
        domain=settings.SESSION_COOKIE_DOMAIN,
        secure=settings.SESSION_COOKIE_SECURE or None,
    )

def delete_cookie(response, key):
    """
    Delete a cookie from an HttpResponse object.

    :param response: HttpResponse object from which the cookie will be deleted.
    :param key: The name of the cookie to delete.
    """
    response.delete_cookie(key, domain=settings.SESSION_COOKIE_DOMAIN)
```

import datetime

from django.conf import settings


def set_cookie(response, key, value, days_expire=7):
    if days_expire is None:
        max_age = 365 * 24 * 60 * 60  # one year
    else:
        max_age = days_expire * 24 * 60 * 60
    expires = datetime.datetime.strftime(
        datetime.datetime.utcnow() + datetime.timedelta(seconds=max_age),
        "%a, %d-%b-%Y %H:%M:%S GMT",
    )
    response.set_cookie(
        key,
        value,
        max_age=max_age,
        expires=expires,
        domain=settings.SESSION_COOKIE_DOMAIN,
        secure=settings.SESSION_COOKIE_SECURE or None,
    )


def delete_cookie(response, key):
    response.delete_cookie(key, domain=settings.SESSION_COOKIE_DOMAIN)
