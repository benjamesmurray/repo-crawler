```python
from typing import List

def get_bounding_box(bounding_box: List) -> List[float]:
    """
    Parse a bounding box argument to extract the coordinates.

    The function supports two formats of bounding box arguments:
    1. A single string with comma-separated values (e.g., "minLong,minLat,maxLong,maxLat").
    2. Separate query parameters for each coordinate (e.g., [minLong, minLat, maxLong, maxLat]).

    Parameters:
    bounding_box (List): A list that contains the bounding box coordinates as strings.
                         This can be a single-element list with a comma-separated string,
                         or a list with individual string coordinates.

    Returns:
    List[float]: A list of floating-point numbers representing the bounding box coordinates.
                 Returns an empty list if the input is not valid.
    """

    # Array query params can be passed in a few ways, this handles 2
    # of the most common array string "?=boundingBox=minLong,minLat... and
    # multi query params "?boundingBox=minLong&boundingBox=minLat...
    box = []
    if len(bounding_box) == 1:
        box_string = bounding_box[0]
        try:
            box = [float(coord.strip()) for coord in box_string.split(",") if coord]
        except ValueError:
            return box
    else:
        box = [float(coord) for coord in bounding_box]

    return box
```

from typing import List


def get_bounding_box(bounding_box: List):
    """Returns a list of coordinates that form a bounding box from request args."""

    # Array query params can be passed in a few ways, this handles 2
    # of the most common array string "?=boundingBox=minLong,minLat... and
    # multi query params "?boundingBox=minLong&boundingBox=minLat...
    box = []
    if len(bounding_box) == 1:
        box_string = bounding_box[0]
        try:
            box = [float(coord.strip()) for coord in box_string.split(",") if coord]
        except ValueError:
            return box
    else:
        box = [float(coord) for coord in bounding_box]

    return box
