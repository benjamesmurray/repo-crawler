```python
from django.shortcuts import get_object_or_404
from django.utils.functional import LazyObject
from django_hosts import reverse_host

class LazySite(LazyObject):
    """
    A lazy proxy for the Django Site object.
    
    This class is a lazy object that defers the retrieval of the Site object
    until it's actually accessed. It's initialized with the request object
    and any additional arguments that will be used to reverse the host to a
    site object.
    
    Attributes:
        _host (dict): A dictionary containing the host name and additional
                      args and kwargs for reversing the host.
    """
    
    def __init__(self, request, *args, **kwargs):
        """
        Initialize the lazy site object with the request and additional arguments.
        
        Args:
            request: The request object containing the host.
            *args: Additional positional arguments for reversing the host.
            **kwargs: Additional keyword arguments for reversing the host.
        """
        super(LazySite, self).__init__()
        self.__dict__.update(
            {"_host": {"name": request.host.name, "args": args, "kwargs": kwargs}}
        )

    def _setup(self):
        """
        Set up the lazy object by retrieving the Site object based on the host.
        
        This method is called internally when the lazy object is accessed for
        the first time. It performs the host reversal and fetches the Site
        object from the database.
        """
        host = reverse_host(
            self._host["name"], args=self._host["args"], kwargs=self._host["kwargs"]
        )
        from django.contrib.sites.models import Site

        site = get_object_or_404(Site, domain__iexact=host)
        self._wrapped = site


def host_site(request, *args, **kwargs):
    """
    A callback function for django-hosts to replace the default 'host_site' callback.
    
    This function is intended to be used in the HOST_CALLBACKS setting of the
    django-hosts configuration. It sets a LazySite object on the request which
    will lazily retrieve the associated Site object when accessed.
    
    Args:
        request: The HttpRequest object.
        *args: Additional positional arguments for reversing the host.
        **kwargs: Additional keyword arguments for reversing the host.
    """
    request.site = LazySite(request, *args, **kwargs)
```

from django.shortcuts import get_object_or_404
from django.utils.functional import LazyObject
from django_hosts import reverse_host


class LazySite(LazyObject):
    def __init__(self, request, *args, **kwargs):
        super(LazySite, self).__init__()
        self.__dict__.update(
            {"_host": {"name": request.host.name, "args": args, "kwargs": kwargs}}
        )

    def _setup(self):
        host = reverse_host(
            self._host["name"], args=self._host["args"], kwargs=self._host["kwargs"]
        )
        from django.contrib.sites.models import Site

        site = get_object_or_404(Site, domain__iexact=host)
        self._wrapped = site


def host_site(request, *args, **kwargs):
    """
    Callback for django-hosts:
    see https://django-hosts.readthedocs.io/en/latest/callbacks.html#
    django_hosts.callbacks.host_site

    Replacing callback 'django_hosts.callbacks.host_site' as their LazySite object
    shadows Site.name
    """
    request.site = LazySite(request, *args, **kwargs)
