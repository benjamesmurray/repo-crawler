```python
import datetime

def earlier_or_later(first: datetime, second: datetime, choose_earlier=True):
    """
    Determine the earlier or later of two datetime objects.
    
    Parameters:
    first (datetime): The first datetime object to compare.
    second (datetime): The second datetime object to compare.
    choose_earlier (bool): If True, the earlier datetime is returned, otherwise the later.
    
    Returns:
    datetime: The earlier or later datetime object depending on choose_earlier. If one is None, returns the other.
             If both are None, returns None.
    """
    if first and second:
        return min(first, second) if choose_earlier else max(first, second)
    return first or second
```

# Returns the earliest of first or second.
# If both are None, returns None
# If one is None, returns the other
import datetime


def earlier_or_later(first: datetime, second: datetime, choose_earlier=True):
    if first and second:
        return min(first, second) if choose_earlier else max(first, second)
    return first or second
