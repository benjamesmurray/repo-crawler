```python
from collections import namedtuple

# Define a namedtuple 'Column' which represents a column in a database or dataset.
# The 'Column' namedtuple has two fields: 'field_name' and 'definition'.
# 'field_name' is a string representing the name of the column.
# 'definition' is a string or object that describes the type or contents of the column.
Column = namedtuple("Column", "field_name, definition")
```

from collections import namedtuple

Column = namedtuple("Column", "field_name, definition")
