```python
from crispy_forms import layout
from crispy_forms.layout import LayoutObject
from crispy_forms.utils import TEMPLATE_PACK
from django.template import Template
from django.template.loader import render_to_string

class TableCell(layout.Div):
    """
    TableCell is a layout object that wraps fields in a specified HTML tag.
    
    Attributes:
        tag (str): HTML tag to use for wrapping fields.
        template (str): Path to the template used for rendering the cell.
    """
    
    tag: str = None
    template = "common/forms/table_cell.html"

    def render(self, form, context, template_pack=TEMPLATE_PACK, **kwargs):
        """
        Renders the TableCell layout object using the specified form and context.
        
        Parameters:
            form: The form being rendered.
            context: Template context for rendering.
            template_pack: The template pack to be used for rendering.
            **kwargs: Additional keyword arguments.
            
        Returns:
            Rendered HTML string for the TableCell.
        """
        original_form = context.get("form", None)
        context["form"] = form

        fields = self.get_rendered_fields(form, context, template_pack, **kwargs)

        if self.css_id is not None:
            self.css_id = Template(str(self.css_id)).render(context=context)

        context["form"] = original_form

        template = self.get_template_name(template_pack)
        return render_to_string(
            template, {"elem": self, "tag": self.tag, "fields": fields}
        )

class TR(TableCell):
    """
    TR is a TableCell layout object specifically for table row elements.
    """
    tag = "tr"

class TD(TableCell):
    """
    TD is a TableCell layout object specifically for table data elements.
    """
    tag = "td"

class Formset(LayoutObject):
    """
    Formset is a layout object for rendering formsets within a template.
    
    Attributes:
        template (str): Path to the template used for rendering the formset.
    """
    
    template = None

    def __init__(self, formset_name_in_context, template=None):
        """
        Initializes the Formset layout object.
        
        Parameters:
            formset_name_in_context (str): The name of the formset within the template context.
            template (str, optional): Custom template to use for rendering.
        """
        self.formset_name_in_context = formset_name_in_context
        self.fields = []
        if template:
            self.template = template

    def render(self, form, context, template_pack=TEMPLATE_PACK):
        """
        Renders the Formset layout object using the specified form and context.
        
        Parameters:
            form: The form being rendered.
            context: Template context for rendering.
            template_pack: The template pack to be used for rendering.
            
        Returns:
            Rendered HTML string for the Formset.
        """
        formset = context[self.formset_name_in_context]
        return render_to_string(self.template, {"formset": formset})

class InlineFormset(LayoutObject):
    """
    InlineFormset is a layout object for rendering inline formsets within a template.
    
    Attributes:
        template (str): Path to the template used for rendering the inline formset.
    """
    
    template = "common/forms/formset_inline.html"

    def __init__(self, field, **kwargs):
        """
        Initializes the InlineFormset layout object.
        
        Parameters:
            field (str): The name of the formset field within the form.
            **kwargs: Additional keyword arguments, including 'template' for a custom template.
        """
        self.field = field
        self.template = kwargs.pop("template", self.template)
        super().__init__(**kwargs)

    def render(self, form, context, template_pack=TEMPLATE_PACK):
        """
        Renders the InlineFormset layout object using the specified form and context.
        
        Parameters:
            form: The form being rendered.
            context: Template context for rendering.
            template_pack: The template pack to be used for rendering.
            
        Returns:
            Rendered HTML string for the InlineFormset.
        """
        formset = getattr(form, self.field)
        return render_to_string(self.template, {"formset": formset})
```

from crispy_forms import layout
from crispy_forms.layout import LayoutObject
from crispy_forms.utils import TEMPLATE_PACK
from django.template import Template
from django.template.loader import render_to_string


class TableCell(layout.Div):
    """
    Layout object. It wraps fields in a <tag>
    """

    tag: str = None
    template = "common/forms/table_cell.html"

    def render(self, form, context, template_pack=TEMPLATE_PACK, **kwargs):
        # replace form in context with form being render so templated
        # attributes use correct form
        # i.e. when rendering the
        # `empty_form`: Template('id_{{ form.prefix }}').render(context)
        # resolves to 'id_form'
        # not 'id_form-__prefix__'.
        original_form = context.get("form", None)
        context["form"] = form

        fields = self.get_rendered_fields(form, context, template_pack, **kwargs)

        if self.css_id is not None:
            self.css_id = Template(str(self.css_id)).render(context=context)

        # put original form back in context just in case its required for
        # some other reason
        context["form"] = original_form

        template = self.get_template_name(template_pack)
        return render_to_string(
            template, {"elem": self, "tag": self.tag, "fields": fields}
        )


class TR(TableCell):
    tag = "tr"


class TD(TableCell):
    tag = "td"


# rer https://stackoverflow.com/questions/15157262/
# django-crispy-forms-nesting-a-formset-within-a-form/22053952#22053952
class Formset(LayoutObject):
    template = None

    def __init__(self, formset_name_in_context, template=None):
        self.formset_name_in_context = formset_name_in_context
        self.fields = []
        if template:
            self.template = template

    def render(self, form, context, template_pack=TEMPLATE_PACK):
        formset = context[self.formset_name_in_context]
        return render_to_string(self.template, {"formset": formset})


class InlineFormset(LayoutObject):
    template = "common/forms/formset_inline.html"

    def __init__(self, field, **kwargs):
        self.field = field
        self.template = kwargs.pop("template", self.template)
        super().__init__(**kwargs)

    def render(self, form, context, template_pack=TEMPLATE_PACK):
        formset = getattr(form, self.field)
        return render_to_string(self.template, {"formset": formset})
