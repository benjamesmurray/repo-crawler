```python
from django.utils.translation import gettext_lazy as _

# Default message for error summaries
DEFAULT_ERROR_SUMMARY = _("There is a problem")

# Constants representing boolean string values
TRUE = "True"
FALSE = "False"

# Standard encoding used for text data
UTF8 = "utf-8"
```

from django.utils.translation import gettext_lazy as _

DEFAULT_ERROR_SUMMARY = _("There is a problem")
TRUE = "True"
FALSE = "False"

UTF8 = "utf-8"
