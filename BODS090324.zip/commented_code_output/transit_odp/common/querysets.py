```python
from django.db.models import Aggregate, CharField, Value

class GroupConcat(Aggregate):
    """
    An aggregate class that represents a GROUP_CONCAT SQL function.

    This class is used to concatenate values from a group into a single string with a specified delimiter.
    It can be used in Django's ORM to create a custom aggregate function.

    Attributes:
        function (str): The SQL function name to use.
        name (str): The name of the aggregate function.
        template (str): A template to format the SQL query.
        allow_distinct (bool): Whether or not the DISTINCT option is allowed.
    
    Methods:
        __init__: Initializes the GroupConcat instance with the specified expression, delimiter, and distinct option.
        as_postgresql: Modifies the SQL function for PostgreSQL compatibility.
    """

    function = "GROUP_CONCAT"
    name = "Group Concat"
    template = "%(function)s(%(distinct)s%(expressions)s)"
    allow_distinct = True

    def __init__(self, expression, delimiter, distinct=False, **extra):
        """
        Initialize the GroupConcat aggregate function.

        Parameters:
            expression (str or F object): The field or expression to concatenate.
            delimiter (str): The string to use as the delimiter between values.
            distinct (bool, optional): Whether to use DISTINCT in the aggregate function.
            **extra: Additional keyword arguments to be passed to the parent class.
        """
        output_field = extra.pop("output_field", CharField())
        delimiter = Value(delimiter, CharField())
        super(GroupConcat, self).__init__(
            expression,
            delimiter,
            output_field=output_field,
            distinct="DISTINCT " if distinct else "",
            **extra
        )

    def as_postgresql(self, compiler, connection):
        """
        Customizes the SQL function for PostgreSQL.

        This method changes the SQL function to STRING_AGG, which is the PostgreSQL equivalent of GROUP_CONCAT.

        Parameters:
            compiler: The SQL compiler.
            connection: The database connection.

        Returns:
            A tuple containing the SQL string and any parameters.
        """
        self.function = "STRING_AGG"
        return super(GroupConcat, self).as_sql(compiler, connection)
```

from django.db.models import Aggregate, CharField, Value


class GroupConcat(Aggregate):
    function = "GROUP_CONCAT"
    nane = "Group Concat"
    template = "%(function)s(%(distinct)s%(expressions)s)"
    allow_distinct = True

    def __init__(self, expression, delimiter, distinct=False, **extra):
        output_field = extra.pop("output_field", CharField())
        delimiter = Value(delimiter, CharField())
        super(GroupConcat, self).__init__(
            expression,
            delimiter,
            output_field=output_field,
            distinct="DISTINCT " if distinct else "",
            **extra
        )

    def as_postgresql(self, compiler, connection):
        self.function = "STRING_AGG"
        return super(GroupConcat, self).as_sql(compiler, connection)
