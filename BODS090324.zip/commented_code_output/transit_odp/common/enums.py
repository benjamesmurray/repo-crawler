```python
import enum

@enum.unique
class FeedErrorSeverity(enum.Enum):
    """
    Enum for representing the severity of feed errors.

    Attributes:
        severe (str): Represents a severe error.
        minor (str): Represents a minor error.
    """
    severe = "severe"
    minor = "minor"


@enum.unique
class FeedErrorCategory(enum.Enum):
    """
    Enum for categorizing feed errors.

    Attributes:
        xml (str): Represents an XML-related error.
        zip (str): Represents a ZIP file-related error.
        naptan (str): Represents a NaPTAN (National Public Transport Access Nodes) error.
        unknown (str): Represents an unknown type of error.
        data (str): Represents a data-related error.
        availability (str): Represents an error related to availability.
    """
    xml = "xml"
    zip = "zip"
    naptan = "naptan"
    unknown = "unknown"
    data = "data"
    availability = "availability"


@enum.unique
class FeedNotificationCategory(enum.Enum):
    """
    Enum for defining the categories of feed notifications.

    Attributes:
        no_notifications (str): Represents the absence of notifications.
        immediately (str): Represents that notifications should be sent immediately.
        daily (str): Represents that notifications should be sent daily.
        weekly (str): Represents that notifications should be sent weekly.
    """
    no_notifications = "no_notifications"
    immediately = "immediately"
    daily = "daily"
    weekly = "weekly"
```

import enum


@enum.unique
class FeedErrorSeverity(enum.Enum):
    severe = "severe"
    minor = "minor"


@enum.unique
class FeedErrorCategory(enum.Enum):
    xml = "xml"
    zip = "zip"
    naptan = "naptan"
    unknown = "unknown"
    data = "data"
    availability = "availability"


@enum.unique
class FeedNotificationCategory(enum.Enum):
    no_notifications = "no_notifications"
    immediately = "immediately"
    daily = "daily"
    weekly = "weekly"
