```python
from django_filters import rest_framework as filters
from django_filters.constants import EMPTY_VALUES

class ArrayFilter(filters.CharFilter):
    """
    Custom filter class to handle filtering by an array of values.
    
    This filter extends the CharFilter from django_filters and overrides
    the filter method to handle values that are expected to be arrays.
    It is useful when you want to filter by a list of values instead of a single value.
    
    Attributes:
        qs: The initial queryset to be filtered.
        value: The value (or list of values) used for filtering.
        
    Returns:
        A filtered queryset based on the provided value(s).
    """
    
    def filter(self, qs, value):
        """
        Override the filter method to handle array values.
        
        If the value is considered empty (None, '', etc.), it returns the
        original queryset. Otherwise, it calls the superclass filter method
        with the value wrapped in a list.
        
        Args:
            qs: The QuerySet to be filtered.
            value: The value to filter by. If it's an empty value, the method
                   returns the unfiltered QuerySet.
        
        Returns:
            The filtered QuerySet.
        """
        if value in EMPTY_VALUES:
            return qs

        return super().filter(qs, [value])
```

from django_filters import rest_framework as filters
from django_filters.constants import EMPTY_VALUES


class ArrayFilter(filters.CharFilter):
    def filter(self, qs, value):
        if value in EMPTY_VALUES:
            return qs

        return super().filter(qs, [value])
