```python
from logging import LoggerAdapter
from pydantic import BaseModel

class LoggerContext(BaseModel):
    """
    A Pydantic model representing the context of a logger message.
    
    Attributes:
        component_name (str): The name of the component generating the log.
        class_name (str): The name of the class generating the log.
        object_id (int): An identifier for the object associated with the log.
    """
    component_name: str = ""
    class_name: str = ""
    object_id: int = -1

class PipelineAdapter(LoggerAdapter):
    """
    A LoggerAdapter that prefixes log messages with context information.
    """
    def process(self, msg, kwargs):
        """
        Process the logging message and keyword arguments.
        
        Parameters:
            msg (str): The log message.
            kwargs (dict): Additional keyword arguments.
            
        Returns:
            tuple: The modified log message and keyword arguments.
        """
        if "context" in self.extra:
            context: LoggerContext = kwargs.pop("context", self.extra["context"])

            prefix = "[{component_name}] {class_name} {object_id} => ".format(
                **context.model_dump()
            )
            msg = prefix + msg
        return msg, kwargs

class LoaderAdapter(LoggerAdapter):
    """
    A LoggerAdapter that prefixes log messages with the name of a pipeline.
    """
    def __init__(self, pipeline, logger, extra=None):
        """
        Initialize the LoaderAdapter.
        
        Parameters:
            pipeline (str): The name of the pipeline.
            logger (Logger): The logger instance.
            extra (dict, optional): Additional context.
        """
        self.pipeline = pipeline
        super().__init__(logger, extra)

    def process(self, msg, kwargs):
        """
        Process the logging message and keyword arguments.
        
        Parameters:
            msg (str): The log message.
            kwargs (dict): Additional keyword arguments.
            
        Returns:
            tuple: The modified log message and keyword arguments.
        """
        msg: str = f"[{self.pipeline}] => {msg}"
        return msg, kwargs

class MonitoringLoggerContext(LoggerContext):
    """
    A specific LoggerContext for dataset monitoring.
    """
    class_name: str = "Dataset"
    component_name: str = "DatasetMonitoring"

class DatasetPipelineLoggerContext(LoggerContext):
    """
    A specific LoggerContext for the dataset pipeline.
    """
    class_name: str = "Dataset"
    component_name: str = "TimetablePipeline"

class DatafeedPipelineLoggerContext(LoggerContext):
    """
    A specific LoggerContext for the AVL dataset pipeline.
    """
    class_name: str = "AVLDataset"
    component_name: str = "AVLPipeline"

def get_dataset_adapter_from_revision(logger, revision) -> PipelineAdapter:
    """
    Create a PipelineAdapter with context for a dataset based on its revision.
    
    Parameters:
        logger (Logger): The logger instance.
        revision: The revision object with a dataset_id attribute.
        
    Returns:
        PipelineAdapter: A configured PipelineAdapter instance.
    """
    context: DatafeedPipelineLoggerContext = DatasetPipelineLoggerContext(
        object_id=revision.dataset_id
    )
    adapter: PipelineAdapter = PipelineAdapter(logger, {"context": context})
    return adapter

def get_datafeed_adapter(logger, feed_id: int) -> PipelineAdapter:
    """
    Create a PipelineAdapter with context for a datafeed specified by feed_id.
    
    Parameters:
        logger (Logger): The logger instance.
        feed_id (int): The identifier for the datafeed.
        
    Returns:
        PipelineAdapter: A configured PipelineAdapter instance.
    """
    context: DatafeedPipelineLoggerContext = DatafeedPipelineLoggerContext(
        object_id=feed_id
    )
    adapter: PipelineAdapter = PipelineAdapter(logger, {"context": context})
    return adapter
```

from logging import LoggerAdapter

from pydantic import BaseModel


class LoggerContext(BaseModel):
    component_name: str = ""
    class_name: str = ""
    object_id: int = -1


class PipelineAdapter(LoggerAdapter):
    def process(self, msg, kwargs):
        if "context" in self.extra:
            context: LoggerContext = kwargs.pop("context", self.extra["context"])

            prefix = "[{component_name}] {class_name} {object_id} => ".format(
                **context.model_dump()
            )
            msg = prefix + msg
        return msg, kwargs


class LoaderAdapter(LoggerAdapter):
    def __init__(self, pipeline, logger, extra=None):
        self.pipeline = pipeline
        super().__init__(logger, extra)

    def process(self, msg, kwargs):
        msg: str = f"[{self.pipeline}] => {msg}"
        return msg, kwargs


class MonitoringLoggerContext(LoggerContext):
    class_name: str = "Dataset"
    component_name: str = "DatasetMonitoring"


class DatasetPipelineLoggerContext(LoggerContext):
    class_name: str = "Dataset"
    component_name: str = "TimetablePipeline"


class DatafeedPipelineLoggerContext(LoggerContext):
    class_name: str = "AVLDataset"
    component_name: str = "AVLPipeline"


def get_dataset_adapter_from_revision(logger, revision) -> PipelineAdapter:
    context: DatafeedPipelineLoggerContext = DatasetPipelineLoggerContext(
        object_id=revision.dataset_id
    )
    adapter: PipelineAdapter = PipelineAdapter(logger, {"context": context})
    return adapter


def get_datafeed_adapter(logger, feed_id: int) -> PipelineAdapter:
    context: DatafeedPipelineLoggerContext = DatafeedPipelineLoggerContext(
        object_id=feed_id
    )
    adapter: PipelineAdapter = PipelineAdapter(logger, {"context": context})
    return adapter
