```python
from config.settings.base import APP_VERSION_NUMBER
from django import template

register = template.Library()

@register.simple_tag
def version():
    """
    Django template tag that returns the current application version number.

    No input parameters.
    Expected output: A string representing the application version number as defined in settings.
    """
    return APP_VERSION_NUMBER
```

from config.settings.base import APP_VERSION_NUMBER
from django import template

register = template.Library()


@register.simple_tag
def version():
    return APP_VERSION_NUMBER
