```python
from typing import Any, Dict, List

from django.template import Library
from django.template.defaultfilters import floatformat

register = Library()

@register.filter("percentage")
def percentage(text, arg=-1):
    """
    Converts a decimal number (as a string or number) to a percentage string.
    
    Parameters:
    - text: The input number as a string or numeric type to be converted to a percentage.
    - arg: The number of decimal points to include in the output string. Defaults to -1 which doesn't trim zeros.
    
    Returns:
    - A string representation of the number as a percentage.
    """
    try:
        score = float(text)
    except (TypeError, ValueError):
        # Handle the case where the conversion to float fails (e.g., if value is not numeric)
        return text

    percentage_value = score * 100.0

    # If value is 0.1 then 1% should be returned
    # If value is 99.8 then 99% should be returned
    if int(arg) == 0:
        if 0 < percentage_value < 1:
            return "1%"
        elif 99 < percentage_value < 100:
            return "99%"
    return floatformat(percentage_value, arg=arg) + "%"


@register.filter("lookup")
def lookup(d: Dict[Any, Any], key: Any) -> Any:
    """
    Looks up a value in a dictionary using the provided key.
    
    Parameters:
    - d: The dictionary from which to retrieve the value.
    - key: The key to look up in the dictionary.
    
    Returns:
    - The value associated with the provided key in the dictionary.
    """
    return d[key]


@register.filter("unique_by_property")
def unique_by_property(lta_objects: List[Any], property_name: str) -> List[Any]:
    """
    Filters a list of objects, returning a list of objects that have unique values for a specified property.
    
    Parameters:
    - lta_objects: A list of objects to be filtered.
    - property_name: The name of the property to filter by.
    
    Returns:
    - A list of objects that have unique values for the specified property.
    """
    unique_values = []
    unique_items = []
    for lta_object in lta_objects:
        if getattr(lta_object, property_name) not in unique_values:
            unique_values.append(getattr(lta_object, property_name))
            unique_items.append(lta_object)
    return unique_items
```

from typing import Any, Dict

from django.template import Library
from django.template.defaultfilters import floatformat

register = Library()


@register.filter("percentage")
def percentage(text, arg=-1):
    try:
        score = float(text)
    except (TypeError, ValueError):
        # Handle the case where the conversion to float fails (e.g., if value is not numeric)
        return text

    percentage_value = score * 100.0

    # If value is 0.1 then 1% should be returned
    # If value is 99.8 then 99% should be returned
    if int(arg) == 0:
        if 0 < percentage_value < 1:
            return "1%"
        elif 99 < percentage_value < 100:
            return "99%"
    return floatformat(percentage_value, arg=arg) + "%"


@register.filter("lookup")
def lookup(d: Dict[Any, Any], key: Any) -> Any:
    return d[key]


@register.filter("unique_by_property")
def unique_by_property(lta_objects, property_name):
    unique_values = []
    unique_items = []
    for lta_object in lta_objects:
        if getattr(lta_object, property_name) not in unique_values:
            unique_values.append(getattr(lta_object, property_name))
            unique_items.append(lta_object)
    return unique_items
