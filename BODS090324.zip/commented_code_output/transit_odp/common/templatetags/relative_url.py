```python
from django import template

register = template.Library()

@register.simple_tag
def relative_url(value, field_name, urlencode=None):
    """
    Generate a URL with the given query parameter while retaining other parameters.

    This tag can be used to create a URL for hyperlinks that keep the current
    query parameters intact except for the one specified by `field_name`, which is set
    to `value`. This is useful for creating links for sorting or filtering.

    Args:
        value: The value to set for the `field_name` parameter in the URL.
        field_name: The name of the query parameter to set/change.
        urlencode (str, optional): A querystring that contains all the current
                                   query parameters, typically provided by
                                   `{{ request.GET.urlencode }}`.

    Returns:
        str: A string of the modified URL with the new query parameter value
             while retaining other parameters.
    """
    url = "?{}={}".format(field_name, value)
    if urlencode:
        querystring = urlencode.split("&")
        filtered_querystring = filter(
            lambda p: p.split("=")[0] != field_name, querystring
        )
        encoded_querystring = "&".join(filtered_querystring)
        url = "{}&{}".format(url, encoded_querystring)
    return url
```

from django import template

register = template.Library()


# See https://simpleisbetterthancomplex.com/
# snippet/2016/08/22/dealing-with-querystring-parameters.html
@register.simple_tag
def relative_url(value, field_name, urlencode=None):
    url = "?{}={}".format(field_name, value)
    if urlencode:
        querystring = urlencode.split("&")
        filtered_querystring = filter(
            lambda p: p.split("=")[0] != field_name, querystring
        )
        encoded_querystring = "&".join(filtered_querystring)
        url = "{}&{}".format(url, encoded_querystring)
    return url
