```python
from django import template

# Initialize a template Library object which can be used to register
# the custom template filter.
register = template.Library()

@register.filter("get_value_from_dict")
def get_value_from_dict(dict_data, key):
    """
    Custom template filter that checks if a given key exists in a dictionary.

    It is used in Django templates to verify the presence of a key in a dictionary.

    The filter can be used in a template with the following syntax:
    {{ your_dict|get_value_from_dict:your_key }}

    Parameters:
    dict_data (dict): The dictionary to search the key in.
    key: The key to be searched in the dictionary.

    Returns:
    bool: True if the key exists in the dictionary, False otherwise.
    """
    if key and key in dict_data:
        return True
    else:
        return False
```

from django import template

register = template.Library()


@register.filter("get_value_from_dict")
def get_value_from_dict(dict_data, key):
    """
    usage example {{ your_dict|get_value_from_dict:your_key }}
    """
    if key and key in dict_data:
        return True
    else:
        return False
