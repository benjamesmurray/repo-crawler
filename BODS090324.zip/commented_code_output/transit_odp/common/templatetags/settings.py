```python
from django import template
from django.conf import settings

# Initialize a template Library object which can be used to register custom template tags and filters.
register = template.Library()

@register.simple_tag
def session_cookie_age():
    """
    Django template tag that returns the session cookie age as a string.

    This tag can be used in Django templates to retrieve the value of SESSION_COOKIE_AGE
    from the project's settings. It converts the age to a string before returning it.

    Returns:
        str: The session cookie age defined in settings, converted to a string.
    """
    return str(settings.SESSION_COOKIE_AGE)
```

from django import template
from django.conf import settings

register = template.Library()


@register.simple_tag
def session_cookie_age():
    """Exposes session cookie age in templates"""
    return str(settings.SESSION_COOKIE_AGE)
