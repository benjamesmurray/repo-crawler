```python
import re

from django import template
from django.conf import settings
from django.urls import NoReverseMatch
from django_hosts.resolvers import reverse

register = template.Library()

@register.simple_tag(takes_context=True)
def active_url(context, url, host=None, css_class="govuk-header__navigation-item--active", exact=False, **kwargs):
    """
    A template tag that returns a CSS class if the given URL matches the current request path.

    The tag can be used in Django templates to add an active CSS class to a navigation item if the URL of that
    item matches the current URL.

    Parameters:
    - context (dict): The context dictionary containing the current request.
    - url (str): The name of the URL pattern to match against the current request path.
    - host (str, optional): The host name to use for URL reversal. Defaults to settings.DEFAULT_HOST.
    - css_class (str, optional): The CSS class to return if the URL matches. Defaults to "govuk-header__navigation-item--active".
    - exact (bool, optional): If True, the URL pattern will match exactly with the request path. Defaults to False.
    - **kwargs: Additional keyword arguments to pass to the URL reversal function.

    Returns:
    - str: The CSS class if the URL matches the current request path, otherwise an empty string.
    """
    # Use the default host if none is provided.
    if host is None:
        host = settings.DEFAULT_HOST
    try:
        # Attempt to reverse the URL with the provided host and kwargs. Prepend with '^' for start of string.
        pattern = f"^{reverse(url, host=host, kwargs=kwargs)}"
    except NoReverseMatch:
        # If URL reversing fails, use the provided URL as the pattern.
        pattern = url

    # Append '$' at the end of the pattern if exact match is required.
    if exact:
        pattern += "$"

    # Retrieve the full path of the current request from the context.
    path = context["request"].build_absolute_uri()
    # Return the CSS class if the pattern matches the path, otherwise return an empty string.
    return css_class if re.search(pattern, path) else ""
```

import re

from django import template
from django.conf import settings
from django.urls import NoReverseMatch
from django_hosts.resolvers import reverse

register = template.Library()


@register.simple_tag(takes_context=True)
def active_url(
    context,
    url,
    host=None,
    css_class="govuk-header__navigation-item--active",
    exact=False,
    **kwargs,
):
    if host is None:
        host = settings.DEFAULT_HOST
    try:
        pattern = f"^{reverse(url, host=host, kwargs=kwargs)}"

    except NoReverseMatch:
        pattern = url

    if exact:
        pattern += "$"

    path = context["request"].build_absolute_uri()
    return css_class if re.search(pattern, path) else ""
