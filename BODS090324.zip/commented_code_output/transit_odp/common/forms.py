```python
from crispy_forms.layout import ButtonHolder, Layout
from transit_odp.crispy_forms_govuk.forms import GOVUKForm
from transit_odp.crispy_forms_govuk.layout.buttons import ButtonSubmit, LinkButton
from django.utils.translation import gettext_lazy as _

GOV_BUTTON_SECONDARY_CLASS = "govuk-button govuk-button--secondary"


class ConfirmationForm(GOVUKForm):
    """
    A form for confirming an action with an option to cancel.
    
    Attributes:
        label (str): The label for the confirmation button.
        cancel_url (str): The URL to redirect to when the cancel button is clicked.
    
    Methods:
        get_layout: Returns a Layout object with a confirmation and cancel button.
    """
    def __init__(self, cancel_url, *args, label="Confirm", **kwargs):
        """
        Initializes the ConfirmationForm with a label and a cancel URL.
        
        Parameters:
            cancel_url (str): The URL to redirect to when the cancel button is clicked.
            label (str, optional): The label for the confirmation button. Defaults to "Confirm".
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        super().__init__(*args, **kwargs)
        self.label = label
        self.cancel_url = cancel_url

    def get_layout(self):
        """
        Creates and returns the layout for the form.
        
        Returns:
            Layout: A Layout object containing the confirmation and cancel buttons.
        """
        cancel_link_button = LinkButton(url=self.cancel_url, content="Cancel")
        cancel_link_button.field_classes = GOV_BUTTON_SECONDARY_CLASS

        return Layout(
            ButtonHolder(
                ButtonSubmit("submit", "submit", content=_(self.label)),
                cancel_link_button,
            )
        )


class AcceptRejectForm(GOVUKForm):
    """
    A form with buttons to accept or reject something.
    
    Methods:
        get_layout: Returns a Layout object with accept and reject buttons.
    """
    def get_layout(self):
        """
        Creates and returns the layout for the form.
        
        Returns:
            ButtonHolder: A ButtonHolder object containing the accept and reject buttons.
        """
        accept_button = ButtonSubmit("status", "accepted", content=_("Accept"))
        reject_button = ButtonSubmit("status", "rejected", content=_("Reject"))
        reject_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(accept_button, reject_button))


class AgentLeaveForm(GOVUKForm):
    """
    A form for an agent to confirm leaving or to cancel the action.
    
    Methods:
        get_layout: Returns a Layout object with confirm and cancel buttons.
    """
    def get_layout(self):
        """
        Creates and returns the layout for the form.
        
        Returns:
            ButtonHolder: A ButtonHolder object containing the confirm and cancel buttons.
        """
        confirm_button = ButtonSubmit("status", "inactive", content=_("Confirm"))
        cancel_button = ButtonSubmit("status", "", content=_("Cancel"))
        cancel_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(confirm_button, cancel_button))


class AgentRemoveForm(AgentLeaveForm):
    """
    A form for removing an agent. Inherits from AgentLeaveForm.
    """
    pass


class AgentResendInviteForm(GOVUKForm):
    """
    A form for resending an invitation to an agent with an option to cancel.
    
    Methods:
        get_layout: Returns a Layout object with confirm and cancel buttons.
    """
    def get_layout(self):
        """
        Creates and returns the layout for the form.
        
        Returns:
            ButtonHolder: A ButtonHolder object containing the resend and cancel buttons.
        """
        confirm_button = ButtonSubmit("submit", "resend", content=_("Confirm"))
        cancel_button = ButtonSubmit("submit", "cancel", content=_("Cancel"))
        cancel_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(confirm_button, cancel_button))


class ConfirmCancelForm(GOVUKForm):
    """
    A form for confirming or cancelling an action.
    
    Methods:
        get_layout: Returns a Layout object with confirm and cancel buttons.
    """
    def get_layout(self):
        """
        Creates and returns the layout for the form.
        
        Returns:
            ButtonHolder: A ButtonHolder object containing the confirm and cancel buttons.
        """
        confirm_button = ButtonSubmit("submit", "confirm", content=_("Confirm"))
        cancel_button = ButtonSubmit("submit", "cancel", content=_("Cancel"))
        cancel_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(confirm_button, cancel_button))
```

from crispy_forms.layout import ButtonHolder, Layout
from transit_odp.crispy_forms_govuk.forms import GOVUKForm
from transit_odp.crispy_forms_govuk.layout.buttons import ButtonSubmit, LinkButton
from django.utils.translation import gettext_lazy as _

GOV_BUTTON_SECONDARY_CLASS = "govuk-button govuk-button--secondary"


class ConfirmationForm(GOVUKForm):
    def __init__(self, cancel_url, *args, label="Confirm", **kwargs):
        super().__init__(*args, **kwargs)
        self.label = label
        self.cancel_url = cancel_url

    def get_layout(self):
        cancel_link_button = LinkButton(url=self.cancel_url, content="Cancel")
        cancel_link_button.field_classes = GOV_BUTTON_SECONDARY_CLASS

        return Layout(
            ButtonHolder(
                ButtonSubmit("submit", "submit", content=_(self.label)),
                cancel_link_button,
            )
        )


class AcceptRejectForm(GOVUKForm):
    def get_layout(self):
        accept_button = ButtonSubmit("status", "accepted", content=_("Accept"))
        reject_button = ButtonSubmit("status", "rejected", content=_("Reject"))
        reject_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(accept_button, reject_button))


class AgentLeaveForm(GOVUKForm):
    def get_layout(self):
        confirm_button = ButtonSubmit("status", "inactive", content=_("Confirm"))
        cancel_button = ButtonSubmit("status", "", content=_("Cancel"))
        cancel_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(confirm_button, cancel_button))


class AgentRemoveForm(AgentLeaveForm):
    pass


class AgentResendInviteForm(GOVUKForm):
    def get_layout(self):
        confirm_button = ButtonSubmit("submit", "resend", content=_("Confirm"))
        cancel_button = ButtonSubmit("submit", "cancel", content=_("Cancel"))
        cancel_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(confirm_button, cancel_button))


class ConfirmCancelForm(GOVUKForm):
    def get_layout(self):
        confirm_button = ButtonSubmit("submit", "confirm", content=_("Confirm"))
        cancel_button = ButtonSubmit("submit", "cancel", content=_("Cancel"))
        cancel_button.field_classes = GOV_BUTTON_SECONDARY_CLASS
        return ButtonHolder(Layout(confirm_button, cancel_button))
