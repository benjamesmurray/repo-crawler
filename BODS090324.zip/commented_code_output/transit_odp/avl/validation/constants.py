```python
# Constant defining the default timeout for operations
DEFAULT_TIMEOUT = 120

# Add your functions, methods, or classes below this line with appropriate docstrings
```

DEFAULT_TIMEOUT = 120
