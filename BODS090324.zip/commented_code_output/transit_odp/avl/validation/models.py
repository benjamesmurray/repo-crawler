```python
from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel


class Observation(BaseModel):
    """
    A BODS Observation model representing a specific observation within a packet.
    
    Attributes:
        details (str): Details of the observation.
        category (str): The observations category.
        reference (str): A reference to guidance for this observation.
        context (str): An XPath query for the element that the tests are applied to.
        number (int): The unique identifier for the observation.
        rules (List[str]): A list of rules to evaluate on the context element.
    """
    details: str
    category: str
    reference: str
    context: str
    number: int


class Header(BaseModel):
    """
    A model representing the header information of a packet result.
    
    Attributes:
        packet_name (str): The filename of the packet.
        timestamp (int): The timestamp of the packet.
        feed_id (int): The feed id of the packet.
        plugin (str): The plugin that recorded the packet.
    """
    packet_name: str
    timestamp: int
    feed_id: int
    plugin: str


class Identifier(BaseModel):
    """
    A model for identifying a SIRI VM element within a packet.
    
    Attributes:
        item_identifier (Optional[str]): The ItemIdentifier value.
        line_ref (Optional[str]): The LineRef value.
        name (str): The name of the element.
        operator_ref (Optional[str]): The OperatorRef value.
        recorded_at_time (Optional[datetime]): The RecordedAtTime.
        vehicle_journey_ref (Optional[str]): The VehicleJourneyRef value.
        vehicle_ref (Optional[str]): The VehicleRef value.
    """
    item_identifier: Optional[str] = None
    line_ref: Optional[str] = None
    name: str
    operator_ref: Optional[str] = None
    recorded_at_time: Optional[datetime] = None
    vehicle_journey_ref: Optional[str] = None
    vehicle_ref: Optional[str] = None


class Error(BaseModel):
    """
    A model representing an AVL validation error.
    
    Attributes:
        level (str): Whether the error is critical or non-critical.
        context (str): The packet element that has the issue.
        details (str): Details of the error.
        identifier (Identifier): The Identifier object used to identify the element.
    """
    level: str
    context: str
    details: str
    identifier: Identifier


class Result(BaseModel):
    """
    A model representing the result of a packet analysis.
    
    Attributes:
        header (Header): A header describing the packet analysed.
        errors (List[Error]): A list of issues with the packet.
    """
    header: Header
    errors: List[Error]


class ValidationSummary(BaseModel):
    """
    A model summarizing the AVL validation results.
    
    Attributes:
        total_error_count (int): Total number of errors found for all packets.
        critical_error_count (int): Total number of critical errors.
        non_critical_error_count (int): Total number of non-critical errors.
        vehicle_activity_count (int): Number of vehicle activity elements in all packets.
        critical_score (float): Critical error score.
        non_critical_score (float): Non-critical error score.
    """
    total_error_count: int
    critical_error_count: int
    non_critical_error_count: int
    vehicle_activity_count: int
    critical_score: float
    non_critical_score: float


class ValidationResponse(BaseModel):
    """
    The response model sent from the validation service.
    
    Attributes:
        feed_id (int): The id of the feed analysed.
        packet_count (int): The total number of packets analysed.
        validation_summary (ValidationSummary): A summary of the validation.
        results (List[Result]): A list of the results of every packet in the analysis.
    """
    feed_id: int
    packet_count: int
    validation_summary: ValidationSummary
    results: List[Result]


class SchemaError(BaseModel):
    """
    A model representing a schema validation error.
    
    Attributes:
        domain_name (str): The xml domain name.
        filename (str): The xml filename.
        level_name (str): The name of the error level.
        line (int): The line the error occurs on.
        message (str): The error message.
        path (str): The path to the element that has the issue.
        type_name (str): The type of error.
    """
    domain_name: str
    filename: str
    level_name: str
    line: int
    message: str
    path: str
    type_name: str


class SchemaValidationResponse(BaseModel):
    """
    A response model for schema validation.
    
    Attributes:
        feed_id (int): The id of the feed.
        is_valid (bool): True if the packet has no schema issues, False otherwise.
        timestamp (int): The timestamp of when Real Time processed the packet.
        errors (List[SchemaError]): A list of all the schema validation errors.
    """
    feed_id: int
    is_valid: bool
    timestamp: int
    errors: List[SchemaError]
```

from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel


class Observation(BaseModel):
    """
    A BODS Observation.

    Args:
        details: Details of the observation.
        category: The observations category.
        reference: A reference to guidance for this observation.
        context: An XPath query for the element that the tests are applied to.
        number: The unique identifier for the observation.
        rules: A list of rules to evaluate on the context element.
    """

    details: str
    category: str
    reference: str
    context: str
    number: int


class Header(BaseModel):
    """
    A result header.

    Args:
        packet_name: The filename of the packet.
        timestamp: The timestamp of the packet.
        feed_id: The feed id of the packet.
        plugin: The plugin that recorded the packet.
    """

    packet_name: str
    timestamp: int
    feed_id: int
    plugin: str


class Identifier(BaseModel):
    """
    A class for identifying a SIRI VM element.

    Args:
        item_identifier: The ItemIdentifier value.
        line_ref: The LineRef value.
        name: The name of the element.
        operator_ref: The OperatorRef value.
        recorded_at_time: The RecordedAtTime.
        vehicle_journey_ref: The VehicleJourneyRef value.
        vehicle_ref: The VehicleRef value.
    """

    item_identifier: Optional[str] = None
    line_ref: Optional[str] = None
    name: str
    operator_ref: Optional[str] = None
    recorded_at_time: Optional[datetime] = None
    vehicle_journey_ref: Optional[str] = None
    vehicle_ref: Optional[str] = None


class Error(BaseModel):
    """
    A AVL validation error.

    Args:
        level: Whether the error is critical or non-critical.
        context: The packet element that has the issue.
        details: Details of the error.
        identifier: The Identifier object used to identify the element.
    """

    level: str
    context: str
    details: str
    identifier: Identifier


class Result(BaseModel):
    """
    The result of a packet analysis.

    Args:
        header: A header describing the packet analysed.
        errors: A list of issues with the packet.
    """

    header: Header
    errors: List[Error]


class ValidationSummary(BaseModel):

    """
    A summary of the AVL validation results.

    total_error_count: Total number of errors found for all packets.
    critical_error_count: Total number of critical errors.
    non_critical_error_count: Total number of non-critical errors.
    critical_score: Critical error score.
    non_critical_score: Non-critical error score.
    vehicle_activity_count: Number of vehicle activity elements in all packets.
    """

    total_error_count: int
    critical_error_count: int
    non_critical_error_count: int
    vehicle_activity_count: int
    critical_score: float
    non_critical_score: float


class ValidationResponse(BaseModel):
    """
    The response sent from the validation service.

    Args:
        feed_id: The id of the feed analysed.
        packet_count: The total number of packets analysed.
        validation_summary: A summary of the validation.
        results: A list of the results of every packet in the analysis.
    """

    feed_id: int
    packet_count: int
    validation_summary: ValidationSummary
    results: List[Result]


class SchemaError(BaseModel):
    """
    A schema validation error.

    Args:
        domain_name: The xml domain name.
        filename: The xml filename.
        level_name: The name of the error level.
        line: The line the error occurs on.
        message: The error message.
        path: The path to the element that has the issue.
        type_name: The type of error.
    """

    domain_name: str
    filename: str
    level_name: str
    line: int
    message: str
    path: str
    type_name: str


class SchemaValidationResponse(BaseModel):
    """
    A validation response

    Args:
        feed_id: The id of the feed.
        is_valid: True if the packet has no schema issues, False otherwise.
        timestamp: The timestamp of when Real Time processed the packet
        errors: A list of all the schema validation errors.
    """

    feed_id: int
    is_valid: bool
    timestamp: int
    errors: List[SchemaError]
