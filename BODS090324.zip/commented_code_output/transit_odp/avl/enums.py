```python
from enum import Enum, unique

from transit_odp.common.utils.choice_enum import ChoiceEnum

@unique
class AVLFeedStatus(ChoiceEnum):
    """
    AVLFeedStatus is an enumeration of possible statuses for an AVL feed.
    
    It inherits from ChoiceEnum, which is a custom Enum class that adds
    additional functionality for choices in Django model fields.
    
    Attributes:
        DEPLOYING: Indicates the AVL feed is currently being deployed.
        SYSTEM_ERROR: Indicates there is a system error with the AVL feed.
        FEED_UP: Indicates the AVL feed is operational.
        FEED_DOWN: Indicates the AVL feed is not operational.
    """
    DEPLOYING = "DEPLOYING"
    SYSTEM_ERROR = "SYSTEM_ERROR"
    FEED_UP = "FEED_UP"
    FEED_DOWN = "FEED_DOWN"

# Constants for easy access to AVLFeedStatus values
AVL_FEED_UP = AVLFeedStatus.FEED_UP.value
AVL_FEED_DOWN = AVLFeedStatus.FEED_DOWN.value
AVL_FEED_SYSTEM_ERROR = AVLFeedStatus.SYSTEM_ERROR.value
AVL_FEED_DEPLOYING = AVLFeedStatus.DEPLOYING.value

@unique
class ValidationTaskResultStatus(str, Enum):
    """
    ValidationTaskResultStatus is an enumeration of possible result statuses
    for a validation task.
    
    It inherits from str and Enum to allow for string comparison and to be used
    as enumeration, respectively.
    
    Attributes:
        DEPLOYING: Indicates the validation task is in progress.
        SYSTEM_ERROR: Indicates there is a system error with the validation task.
        FEED_VALID: Indicates the feed is valid.
        FEED_INVALID: Indicates the feed is invalid.
    """
    DEPLOYING = "DEPLOYING"
    SYSTEM_ERROR = "SYSTEM_ERROR"
    FEED_VALID = "FEED_VALID"
    FEED_INVALID = "FEED_INVALID"
```

from enum import Enum, unique

from transit_odp.common.utils.choice_enum import ChoiceEnum


# TODO: for Python 3.11 use StrEnum class instead of (str, Enum)
@unique
class AVLFeedStatus(ChoiceEnum):
    DEPLOYING = "DEPLOYING"
    SYSTEM_ERROR = "SYSTEM_ERROR"
    FEED_UP = "FEED_UP"
    FEED_DOWN = "FEED_DOWN"


AVL_FEED_UP = AVLFeedStatus.FEED_UP.value
AVL_FEED_DOWN = AVLFeedStatus.FEED_DOWN.value
AVL_FEED_SYSTEM_ERROR = AVLFeedStatus.SYSTEM_ERROR.value
AVL_FEED_DEPLOYING = AVLFeedStatus.DEPLOYING.value


@unique
class ValidationTaskResultStatus(str, Enum):
    DEPLOYING = "DEPLOYING"
    SYSTEM_ERROR = "SYSTEM_ERROR"
    FEED_VALID = "FEED_VALID"
    FEED_INVALID = "FEED_INVALID"
