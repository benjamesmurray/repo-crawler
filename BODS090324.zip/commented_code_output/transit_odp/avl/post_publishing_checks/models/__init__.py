```python
from .siri import MonitoredVehicleJourney, Siri, VehicleActivity

# This module exports the MonitoredVehicleJourney, Siri,
# and VehicleActivity classes for external use.

__all__ = [
    "MonitoredVehicleJourney",
    "Siri",
    "VehicleActivity",
]
```

from .siri import MonitoredVehicleJourney, Siri, VehicleActivity

__all__ = [
    "MonitoredVehicleJourney",
    "Siri",
    "VehicleActivity",
]
