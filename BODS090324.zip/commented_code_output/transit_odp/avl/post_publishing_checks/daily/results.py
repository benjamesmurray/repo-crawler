```python
import logging
from typing import Optional

from transit_odp.avl.post_publishing_checks.constants import (
    SIRIVM_TO_TXC_MAP,
    ErrorCategory,
    MiscFieldPPC,
    SirivmField,
)

logger = logging.getLogger(__name__)

# For debug (temporary)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler())

class FieldValidation:
    """
    Represents the validation status of a single field in the SIRI-VM to TXC comparison.
    
    Attributes:
        sirivm_field (SirivmField): The field from the SIRI-VM data.
        txc_name (Optional[str]): The corresponding field name in the TXC data, if any.
        sirivm_value (Optional[str]): The value of the SIRI-VM field.
        sirivm_line_num (Optional[int]): The line number of the SIRI-VM field.
        txc_value (Optional[str]): The value of the TXC field.
        txc_line_num (Optional[int]): The line number of the TXC field.
        matches (bool): Flag to indicate if the SIRI-VM and TXC field values match.
    """
    def __init__(self, sirivm_field: SirivmField, txc_name: Optional[str] = None):
        self.sirivm_field = sirivm_field
        self.sirivm_value = None
        self.sirivm_line_num = None
        self.txc_name = txc_name
        self.txc_value = None
        self.txc_line_num = None
        self.matches = False


class ValidationResult:
    """
    Holds the results of the post-publishing validation checks for SIRI-VM data against TXC data.
    
    Attributes:
        validated (list): A list of FieldValidation objects for each SIRI-VM field.
        misc (dict): A dictionary to hold miscellaneous field values.
        errors (dict): A dictionary to store validation errors categorized by ErrorCategory.
        journey_matched (bool): Flag indicating if the journey was matched in the validation.
        stats (Optional[dict]): A dictionary to hold statistics about the validation process.
    """
    def __init__(self):
        self.validated = []
        for field in SirivmField:
            self.validated.append(FieldValidation(field, SIRIVM_TO_TXC_MAP.get(field)))
        self.misc = {field: None for field in MiscFieldPPC}
        self.errors = {category: [] for category in ErrorCategory}
        self.journey_matched = False
        self.stats = None

    def set_sirivm_value(
        self, sirivm_field: SirivmField, value: str, line_num: int = None
    ):
        """
        Sets the SIRI-VM value and line number for a given SIRI-VM field.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to update.
            value (str): The value to set for the given SIRI-VM field.
            line_num (Optional[int]): The line number where the value is found.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                validated_field.sirivm_value = value
                validated_field.sirivm_line_num = line_num
                return
        assert False

    def set_txc_value(
        self, sirivm_field: SirivmField, value: str, line_num: int = None
    ):
        """
        Sets the TXC value and line number for a given SIRI-VM field.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to update.
            value (str): The value to set for the corresponding TXC field.
            line_num (Optional[int]): The line number where the value is found.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                validated_field.txc_value = value
                validated_field.txc_line_num = line_num
                return
        assert False

    def set_matches(self, sirivm_field: SirivmField):
        """
        Sets the match status to True for a given SIRI-VM field, indicating a match with TXC.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to update the match status for.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                validated_field.matches = True
                return
        assert False

    def add_error(self, category: ErrorCategory, error: str):
        """
        Adds an error message to the validation result under a specific error category.
        
        Parameters:
            category (ErrorCategory): The category of the error.
            error (str): The error message to be added.
        """
        self.errors[category].append(error)
        logger.info(error)

    def sirivm_value(self, sirivm_field: SirivmField) -> Optional[str]:
        """
        Retrieves the SIRI-VM value for a given SIRI-VM field.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to retrieve the value for.
        
        Returns:
            Optional[str]: The value of the specified SIRI-VM field, or None if not set.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.sirivm_value
        assert False

    def sirivm_line_number(self, sirivm_field: SirivmField) -> Optional[int]:
        """
        Retrieves the line number of the SIRI-VM value for a given SIRI-VM field.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to retrieve the line number for.
        
        Returns:
            Optional[int]: The line number of the specified SIRI-VM field, or None if not set.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.sirivm_line_num
        assert False

    def txc_value(self, sirivm_field: SirivmField) -> Optional[str]:
        """
        Retrieves the TXC value for a given SIRI-VM field.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to retrieve the corresponding TXC value for.
        
        Returns:
            Optional[str]: The value of the corresponding TXC field, or None if not set.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.txc_value
        assert False

    def txc_line_number(self, sirivm_field: SirivmField) -> Optional[int]:
        """
        Retrieves the line number of the TXC value for a given SIRI-VM field.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to retrieve the corresponding TXC line number for.
        
        Returns:
            Optional[int]: The line number of the corresponding TXC field, or None if not set.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.txc_line_num
        assert False

    def matches(self, sirivm_field: SirivmField) -> Optional[bool]:
        """
        Retrieves the match status for a given SIRI-VM field.
        
        Parameters:
            sirivm_field (SirivmField): The SIRI-VM field to retrieve the match status for.
        
        Returns:
            Optional[bool]: True if the SIRI-VM and TXC values match, False otherwise, or None if not set.
        """
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.matches
        assert False

    def set_misc_value(self, misc_field: MiscFieldPPC, value: str):
        """
        Sets a miscellaneous value for a given field.
        
        Parameters:
            misc_field (MiscFieldPPC): The miscellaneous field to set the value for.
            value (str): The value to be set for the miscellaneous field.
        """
        self.misc[misc_field] = value

    def misc_value(self, misc_field: MiscFieldPPC) -> str:
        """
        Retrieves the value for a given miscellaneous field.
        
        Parameters:
            misc_field (MiscFieldPPC): The miscellaneous field to retrieve the value for.
        
        Returns:
            str: The value of the specified miscellaneous field.
        """
        return self.misc[misc_field]

    def set_journey_matched(self):
        """
        Sets the journey_matched flag to True, indicating that the journey was matched during validation.
        """
        self.journey_matched = True

    def journey_was_matched(self) -> bool:
        """
        Checks if the journey was matched during validation.
        
        Returns:
            bool: True if the journey was matched, False otherwise.
        """
        return self.journey_matched
```

import logging
from typing import Optional

from transit_odp.avl.post_publishing_checks.constants import (
    SIRIVM_TO_TXC_MAP,
    ErrorCategory,
    MiscFieldPPC,
    SirivmField,
)

logger = logging.getLogger(__name__)

# For debug (temporary)
logger.setLevel(logging.DEBUG)
logger.addHandler(logging.StreamHandler())


class FieldValidation:
    def __init__(self, sirivm_field: SirivmField, txc_name: Optional[str] = None):
        self.sirivm_field = sirivm_field
        self.sirivm_value = None
        self.sirivm_line_num = None
        self.txc_name = txc_name
        self.txc_value = None
        self.txc_line_num = None
        self.matches = False


class ValidationResult:
    def __init__(self):
        self.validated = []
        for field in SirivmField:
            self.validated.append(FieldValidation(field, SIRIVM_TO_TXC_MAP.get(field)))
        self.misc = {field: None for field in MiscFieldPPC}
        self.errors = {category: [] for category in ErrorCategory}
        self.journey_matched = False
        self.stats = None

    def set_sirivm_value(
        self, sirivm_field: SirivmField, value: str, line_num: int = None
    ):
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                validated_field.sirivm_value = value
                validated_field.sirivm_line_num = line_num
                return
        assert False

    def set_txc_value(
        self, sirivm_field: SirivmField, value: str, line_num: int = None
    ):
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                validated_field.txc_value = value
                validated_field.txc_line_num = line_num
                return
        assert False

    def set_matches(self, sirivm_field: SirivmField):
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                validated_field.matches = True
                return
        assert False

    def add_error(self, category: ErrorCategory, error: str):
        self.errors[category].append(error)
        logger.info(error)

    def sirivm_value(self, sirivm_field: SirivmField) -> Optional[str]:
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.sirivm_value
        assert False

    def sirivm_line_number(self, sirivm_field: SirivmField) -> Optional[int]:
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.sirivm_line_num
        assert False

    def txc_value(self, sirivm_field: SirivmField) -> Optional[str]:
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.txc_value
        assert False

    def txc_line_number(self, sirivm_field: SirivmField) -> Optional[int]:
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.txc_line_num
        assert False

    def matches(self, sirivm_field: SirivmField) -> Optional[bool]:
        for validated_field in self.validated:
            if validated_field.sirivm_field == sirivm_field:
                return validated_field.matches
        assert False

    def set_misc_value(self, misc_field: MiscFieldPPC, value: str):
        self.misc[misc_field] = value

    def misc_value(self, misc_field: MiscFieldPPC) -> str:
        return self.misc[misc_field]

    def set_journey_matched(self):
        self.journey_matched = True

    def journey_was_matched(self) -> bool:
        return self.journey_matched
