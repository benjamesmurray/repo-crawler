```python
import logging
from collections import defaultdict
from datetime import date, timedelta

from django.core.files import File

from transit_odp.avl.models import PostPublishingCheckReport, PPCReportType
from transit_odp.avl.post_publishing_checks.weekly.archiver import (
    WeeklyPPCReportArchiver,
)
from transit_odp.avl.post_publishing_checks.weekly.summary import (
    AggregatedDailyReports,
    PostPublishingChecksSummaryData,
)

logger = logging.getLogger(__name__)


class WeeklyReport:
    """
    WeeklyReport generates a weekly Post Publishing Check (PPC) report by
    aggregating daily PPC reports from the last 7 days. The result is a ZIP
    file containing multiple CSVs with aggregated data.

    Attributes:
        start_date (date): The start date from which to generate the report.
        end_date (date): The end date for the report, calculated as 6 days
                         prior to the start_date.
    """

    def __init__(self, start_date: date = date.today()) -> None:
        """
        Initializes the WeeklyReport with a given start date.

        Parameters:
            start_date (date, optional): The start date for the report.
                                         Defaults to today's date.
        """
        self.start_date = start_date
        self.end_date = start_date - timedelta(days=6)

    def generate(self) -> None:
        """
        Generates the summary PPC report for the week preceding the start_date.
        The report includes data aggregated from the start_date to one week prior.
        """
        logger.info(
            f"Generating PPC weekly report for week {self.end_date} - {self.start_date}"
        )
        weekly_ppc_summary = PostPublishingChecksSummaryData(
            self.start_date, self.end_date
        )

        for feed_id, daily_reports in self._fetch_data().items():
            logger.info(f"Aggregating data for feed_id: {feed_id}")
            summary = weekly_ppc_summary.aggregate_daily_reports(daily_reports)

            logger.debug("Creating ZIP file...")
            zip = self._create_zip(feed_id, summary)

            logger.debug("Saving weekly report in db...")
            self._save_weekly_report(feed_id, summary, zip)

        logger.info("Weekly PPC report done.")

    def _save_weekly_report(
        self, feed_id: int, summary: AggregatedDailyReports, zip_file: File
    ) -> None:
        """
        Saves the weekly PPC report in the database.

        Parameters:
            feed_id (int): The identifier for the feed.
            summary (AggregatedDailyReports): The aggregated report data.
            zip_file (File): The ZIP file containing the report CSVs.
        """
        report, created = PostPublishingCheckReport.objects.get_or_create(
            dataset_id=feed_id,
            created=date.today(),
            granularity=PPCReportType.WEEKLY,
        )
        if not created:
            logger.warning(
                f"Weekly report already exists for week {self.start_date} for "
                f"feed {feed_id}. It's going to be overriden."
            )

        report.vehicle_activities_analysed = summary.total_vehicles_analysed
        report.vehicle_activities_completely_matching = (
            summary.total_vehicles_completely_matching
        )
        report.file = zip_file
        report.save()
        logger.info("Weekly report saved.")

    def _create_zip(self, feed_id: int, summary: AggregatedDailyReports) -> File:
        """
        Creates a ZIP file containing CSVs generated from summary data for a feed.

        Parameters:
            feed_id (int): The identifier for the feed.
            summary (AggregatedDailyReports): The aggregated report data.

        Returns:
            File: A Django File object representing the created ZIP file.
        """
        filename = (
            f"week_{self.start_date.strftime('%d_%m_%Y')}_feed_{feed_id}"
            f"_{summary.all_fields_matching_vehicles_score}.zip"
        )
        archiver = WeeklyPPCReportArchiver()
        archive = archiver.to_zip(summary)
        file_ = File(archive, name=filename)
        logger.info(f"ZIP file: {filename} created.")

        return file_

    def _fetch_data(self) -> dict[int, list[PostPublishingCheckReport]]:
        """
        Fetches daily PPC reports from the database for the last week.

        Returns:
            dict[int, list[PostPublishingCheckReport]]: A dictionary mapping
            feed_ids to lists of daily PPC reports for that feed within the
            last week.
        """
        feeds_in_last_week = PostPublishingCheckReport.objects.filter(
            created__range=[self.end_date, self.start_date],
            granularity=PPCReportType.DAILY,
        )

        response = defaultdict(list)
        for row in feeds_in_last_week:
            response[row.dataset_id].append(row)

        if not response:
            logger.warning("No daily reports found to summarise!")

        return response
```

import logging
from collections import defaultdict
from datetime import date, timedelta

from django.core.files import File

from transit_odp.avl.models import PostPublishingCheckReport, PPCReportType
from transit_odp.avl.post_publishing_checks.weekly.archiver import (
    WeeklyPPCReportArchiver,
)
from transit_odp.avl.post_publishing_checks.weekly.summary import (
    AggregatedDailyReports,
    PostPublishingChecksSummaryData,
)

logger = logging.getLogger(__name__)


class WeeklyReport:
    """
    Generates Weekly PPC report by aggregating daily PPC reports from last 7 days.
    As the result the ZIP file is created which contains multiple CSVs
    with aggregated data.
    """

    def __init__(self, start_date: date = date.today()) -> None:
        self.start_date = start_date
        self.end_date = start_date - timedelta(days=6)

    def generate(self) -> None:
        """Generate summary PPC report based on start_date - 1 week range of data."""

        logger.info(
            f"Generating PPC weekly report for week {self.end_date} - {self.start_date}"
        )
        weekly_ppc_summary = PostPublishingChecksSummaryData(
            self.start_date, self.end_date
        )

        for feed_id, daily_reports in self._fetch_data().items():
            logger.info(f"Aggregating data for feed_id: {feed_id}")
            summary = weekly_ppc_summary.aggregate_daily_reports(daily_reports)

            logger.debug("Creating ZIP file...")
            zip = self._create_zip(feed_id, summary)

            logger.debug("Saving weekly report in db...")
            self._save_weekly_report(feed_id, summary, zip)

        logger.info("Weekly PPC report done.")

    def _save_weekly_report(
        self, feed_id: int, summary: AggregatedDailyReports, zip_file: File
    ) -> None:
        report, created = PostPublishingCheckReport.objects.get_or_create(
            dataset_id=feed_id,
            created=date.today(),
            granularity=PPCReportType.WEEKLY,
        )
        if not created:
            logger.warning(
                f"Weekly report already exists for week {self.start_date} for "
                f"feed {feed_id}. It's going to be overriden."
            )

        report.vehicle_activities_analysed = summary.total_vehicles_analysed
        report.vehicle_activities_completely_matching = (
            summary.total_vehicles_completely_matching
        )
        report.file = zip_file
        report.save()
        logger.info("Weekly report saved.")

    def _create_zip(self, feed_id: int, summary: AggregatedDailyReports) -> File:
        """
        Creates zip file containing bunch of CSVs generated from summary data for feed.
        """
        filename = (
            f"week_{self.start_date.strftime('%d_%m_%Y')}_feed_{feed_id}"
            f"_{summary.all_fields_matching_vehicles_score}.zip"
        )
        archiver = WeeklyPPCReportArchiver()
        archive = archiver.to_zip(summary)
        file_ = File(archive, name=filename)
        logger.info(f"ZIP file: {filename} created.")

        return file_

    def _fetch_data(self) -> dict[int, list[PostPublishingCheckReport]]:
        """
        Returns dictionary with feed_id as a key and list of daily reports
        for that feed done in last week.

        {
            feed_id: [daily_report_monday, daily_report_tuesday, ...],
            ...
        }
        """
        feeds_in_last_week = PostPublishingCheckReport.objects.filter(
            created__range=[self.end_date, self.start_date],
            granularity=PPCReportType.DAILY,
        )

        response = defaultdict(list)
        for row in feeds_in_last_week:
            response[row.dataset_id].append(row)

        if not response:
            logger.warning("No daily reports found to summarise!")

        return response
