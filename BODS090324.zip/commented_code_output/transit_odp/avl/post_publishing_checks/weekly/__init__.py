```python
from .report import WeeklyReport  # noqa

# Import the WeeklyReport class from the report module

class ReportGenerator:
    """
    The ReportGenerator class is responsible for generating various reports.
    """

    def __init__(self, source_data):
        """
        Initialize the ReportGenerator with the source data.

        :param source_data: The data to be used for generating reports.
        """
        self.data = source_data

    def generate_weekly_report(self):
        """
        Generate a weekly report from the source data.

        :return: An instance of WeeklyReport containing the report details.
        """
        weekly_report = WeeklyReport(self.data)
        return weekly_report
```

from .report import WeeklyReport  # noqa
