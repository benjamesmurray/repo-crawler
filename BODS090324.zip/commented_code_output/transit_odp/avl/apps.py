```python
from django.apps import AppConfig

class AvlConfig(AppConfig):
    """
    Configuration class for the AVL (Automatic Vehicle Location) app within the Django project.

    Attributes:
        name (str): The name of the app, used in Django's app registry.
        verbose_name (str): A human-readable name for the app, used in the admin interface.
    """
    name = "transit_odp.avl"
    verbose_name = "Avl"
```

from django.apps import AppConfig


class AvlConfig(AppConfig):
    name = "transit_odp.avl"
    verbose_name = "Avl"
