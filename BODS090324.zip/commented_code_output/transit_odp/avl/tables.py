```python
from math import floor

import django_tables2 as tables

from transit_odp.avl.constants import PENDING
from transit_odp.avl.post_publishing_checks.constants import NO_PPC_DATA
from transit_odp.common.tables import GovUkTable
from transit_odp.organisation.constants import FeedStatus
from transit_odp.organisation.tables import FeedStatusColumn, get_feed_name_linkify

class AVLDataFeedTable(GovUkTable):
    """
    A table for displaying AVL (Automatic Vehicle Location) data feeds within a Django application.
    
    This table inherits from GovUkTable and customizes various columns specific to AVL data feeds,
    such as the status, percent matching, and last automated update time. It also includes
    functionality to render certain columns conditionally based on the data feed's status.
    """

    status = FeedStatusColumn(show_update_link=False, app_name="avl")
    percent_matching = tables.Column(verbose_name="AVL to Timetable matching")
    name = tables.Column(
        verbose_name="Data feed name",
        attrs={
            "a": {"class": "govuk-link"},
            "th": {"class": "govuk-table__header", "width": "25%"},
        },
        linkify=lambda record: get_feed_name_linkify(record, app_name="avl"),
        order_by=("live_revision__name"),
    )
    id = tables.Column(verbose_name="Data feed ID")
    avl_feed_last_checked = tables.Column(verbose_name="Last automated update")
    short_description = tables.Column()

    class Meta(GovUkTable.Meta):
        """
        Meta class options for AVLDataFeedTable, inheriting from GovUkTable.Meta.
        
        This class defines additional attributes for the table, such as classes for the table headers.
        """
        attrs = {"th": {"class": "govuk-table__header"}}

    def render_percent_matching(self, value, record):
        """
        Renders the 'percent_matching' column in the table.

        Parameters:
        - value: the value of percent_matching from the data source.
        - record: the record currently being rendered.

        Returns:
        - A string representation of the percentage matching if the feed status is active and data is available.
        - An empty string if the feed status is expired or inactive.
        - The constant PENDING if no post-publishing check data is available.
        """
        if record.status in [FeedStatus.expired.value, FeedStatus.inactive.value]:
            return ""
        if value == float(NO_PPC_DATA):
            return PENDING
        return str(int(floor(value))) + "%"
```

from math import floor

import django_tables2 as tables

from transit_odp.avl.constants import PENDING
from transit_odp.avl.post_publishing_checks.constants import NO_PPC_DATA
from transit_odp.common.tables import GovUkTable
from transit_odp.organisation.constants import FeedStatus
from transit_odp.organisation.tables import FeedStatusColumn, get_feed_name_linkify


class AVLDataFeedTable(GovUkTable):
    status = FeedStatusColumn(show_update_link=False, app_name="avl")
    percent_matching = tables.Column(verbose_name="AVL to Timetable matching")
    name = tables.Column(
        verbose_name="Data feed name",
        attrs={
            "a": {"class": "govuk-link"},
            "th": {"class": "govuk-table__header", "width": "25%"},
        },
        linkify=lambda record: get_feed_name_linkify(record, app_name="avl"),
        order_by=("live_revision__name"),
    )
    id = tables.Column(verbose_name="Data feed ID")
    avl_feed_last_checked = tables.Column(verbose_name="Last automated update")
    short_description = tables.Column()

    class Meta(GovUkTable.Meta):
        attrs = {"th": {"class": "govuk-table__header"}}

    def render_percent_matching(self, value, record):
        if record.status in [FeedStatus.expired.value, FeedStatus.inactive.value]:
            return ""
        if value == float(NO_PPC_DATA):
            return PENDING
        return str(int(floor(value))) + "%"
