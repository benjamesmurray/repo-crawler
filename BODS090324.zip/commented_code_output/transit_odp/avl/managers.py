```python
from transit_odp.organisation.constants import AVLType
from transit_odp.organisation.managers import DatasetManager, DatasetRevisionManager


class AVLDatasetManager(DatasetManager):
    """
    This manager class is used to interact with AVL dataset instances.
    It extends the DatasetManager to provide a queryset that is specific to AVL datasets.
    """

    def get_queryset(self):
        """
        Overrides the parent method to return a queryset filtered by AVLType.
        
        Returns:
            QuerySet: A QuerySet containing only AVL datasets.
        """
        return super().get_queryset().filter(dataset_type=AVLType)


class AVLDatasetRevisionManager(DatasetRevisionManager):
    """
    This manager class is used to interact with AVL dataset revision instances.
    It extends the DatasetRevisionManager to provide a queryset that is specific to AVL dataset revisions.
    """

    def get_queryset(self):
        """
        Overrides the parent method to return a queryset filtered by the AVLType in the related dataset.
        
        Returns:
            QuerySet: A QuerySet containing only revisions of AVL datasets.
        """
        return super().get_queryset().filter(dataset__dataset_type=AVLType)
```

from transit_odp.organisation.constants import AVLType
from transit_odp.organisation.managers import DatasetManager, DatasetRevisionManager


class AVLDatasetManager(DatasetManager):
    def get_queryset(self):
        return super().get_queryset().filter(dataset_type=AVLType)


class AVLDatasetRevisionManager(DatasetRevisionManager):
    def get_queryset(self):
        return super().get_queryset().filter(dataset__dataset_type=AVLType)
