```python
from django_hosts import reverse

import config.hosts
from transit_odp.common.views import BaseTemplateView
from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.views.base import DeleteRevisionBaseView
from transit_odp.users.views.mixins import OrgUserViewMixin

class RevisionDeleteAVLView(DeleteRevisionBaseView):
    """
    A view for deleting AVL feed revisions.

    This view extends DeleteRevisionBaseView to provide a specific queryset
    for AVL datasets and define success and cancel URLs for the delete operation.
    """
    template_name = "avl/feed_delete.html"

    def get_queryset(self):
        """
        Filters the queryset to return AVL datasets for the organisation.

        Returns:
            QuerySet: A filtered queryset containing only AVL datasets for the
            current organisation.
        """
        return (
            super()
            .get_queryset()
            .filter(
                organisation_id=self.organisation.id,
                dataset_type=DatasetType.AVL.value,
            )
        )

    def get_cancel_url(self, feed_id):
        """
        Determines the URL to redirect to if the delete operation is canceled.

        Parameters:
            feed_id (int): The ID of the feed for which the operation is canceled.

        Returns:
            str: A URL to redirect to if the delete operation is canceled.
        """
        return (
            reverse(
                "avl:revision-publish",
                kwargs={"pk": feed_id, "pk1": self.kwargs["pk1"]},
                host=config.hosts.PUBLISH_HOST,
            )
            if self.object.live_revision is None
            else reverse(
                "avl:revision-update-publish",
                kwargs={"pk": feed_id, "pk1": self.kwargs["pk1"]},
                host=config.hosts.PUBLISH_HOST,
            )
        )

    def get_success_url(self):
        """
        Determines the URL to redirect to after a successful delete operation.

        Returns:
            str: A URL to redirect to after the delete operation is successful.
        """
        return reverse(
            "avl:revision-delete-success",
            kwargs={"pk1": self.kwargs["pk1"]},
            host=config.hosts.PUBLISH_HOST,
        )


class RevisionDeleteSuccessView(OrgUserViewMixin, BaseTemplateView):
    """
    A view to display a success message after an AVL feed revision is deleted.

    This view extends BaseTemplateView and adds the organisation ID to the context.
    """
    template_name = "avl/feed_delete_success.html"

    def get_context_data(self, **kwargs):
        """
        Adds the organisation ID to the template context.

        Returns:
            dict: The context dictionary with the organisation ID added.
        """
        context = super().get_context_data(**kwargs)
        context["pk1"] = self.kwargs["pk1"]
        return context
```

from django_hosts import reverse

import config.hosts
from transit_odp.common.views import BaseTemplateView
from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.views.base import DeleteRevisionBaseView
from transit_odp.users.views.mixins import OrgUserViewMixin


class RevisionDeleteAVLView(DeleteRevisionBaseView):
    template_name = "avl/feed_delete.html"

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .filter(
                organisation_id=self.organisation.id,
                dataset_type=DatasetType.AVL.value,
            )
        )

    def get_cancel_url(self, feed_id):
        return (
            reverse(
                "avl:revision-publish",
                kwargs={"pk": feed_id, "pk1": self.kwargs["pk1"]},
                host=config.hosts.PUBLISH_HOST,
            )
            if self.object.live_revision is None
            else reverse(
                "avl:revision-update-publish",
                kwargs={"pk": feed_id, "pk1": self.kwargs["pk1"]},
                host=config.hosts.PUBLISH_HOST,
            )
        )

    def get_success_url(self):
        return reverse(
            "avl:revision-delete-success",
            kwargs={"pk1": self.kwargs["pk1"]},
            host=config.hosts.PUBLISH_HOST,
        )


class RevisionDeleteSuccessView(OrgUserViewMixin, BaseTemplateView):
    template_name = "avl/feed_delete_success.html"

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context["pk1"] = self.kwargs["pk1"]
        return context
