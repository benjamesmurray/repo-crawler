```python
from transit_odp.browse.views.base_views import OrgChangeLogView
from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.tables import DatasetRevisionTable
from transit_odp.users.views.mixins import OrgUserViewMixin

class AVLChangeLogView(OrgUserViewMixin, OrgChangeLogView):
    """
    A view that displays the change log for AVL datasets.

    Inherits from OrgUserViewMixin and OrgChangeLogView to provide
    a view that is specific to a user's organisation and the AVL dataset type.

    Attributes:
        template_name (str): The path to the HTML template to use for this view.
        table_class (Table): The table class used to render the change log.
        dataset_type (int): The specific type of dataset this view handles.
    """
    template_name = "avl/changelog.html"
    table_class = DatasetRevisionTable
    dataset_type = DatasetType.AVL.value
```

from transit_odp.browse.views.base_views import OrgChangeLogView
from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.tables import DatasetRevisionTable
from transit_odp.users.views.mixins import OrgUserViewMixin


class AVLChangeLogView(OrgUserViewMixin, OrgChangeLogView):
    template_name = "avl/changelog.html"
    table_class = DatasetRevisionTable
    dataset_type = DatasetType.AVL.value
