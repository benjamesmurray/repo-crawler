```python
import logging

from django_hosts import reverse

import config.hosts
from transit_odp.avl.models import CAVLValidationTaskResult

logger = logging.getLogger(__name__)

def get_validation_task_result_from_revision_id(revision_id):
    """
    Fetch the latest CAVLValidationTaskResult for a given revision_id.

    Parameters:
    - revision_id: Integer representing the unique ID of the revision.

    Returns:
    - The latest CAVLValidationTaskResult instance if found, otherwise None.
    """
    try:
        task = CAVLValidationTaskResult.objects.filter(revision_id=revision_id).latest(
            "created"
        )
    except CAVLValidationTaskResult.DoesNotExist:
        logger.warning(
            f"Could not find CAVLValidationTaskResult for revision: {revision_id}",
            exc_info=True,
        )
        return None

    return task

def get_avl_success_url(dataset_id, org_id):
    """
    Construct the URL for the AVL success page.

    Parameters:
    - dataset_id: Integer representing the unique ID of the dataset.
    - org_id: Integer representing the unique ID of the organization.

    Returns:
    - A string of the success URL.
    """
    return reverse(
        "avl:revision-publish-success",
        kwargs={"pk": dataset_id, "pk1": org_id},
        host=config.hosts.PUBLISH_HOST,
    )

def get_avl_failure_url(dataset_id, org_id):
    """
    Construct the URL for the AVL failure page.

    Parameters:
    - dataset_id: Integer representing the unique ID of the dataset.
    - org_id: Integer representing the unique ID of the organization.

    Returns:
    - A string of the failure URL.
    """
    return reverse(
        "avl:revision-publish-error",
        kwargs={"pk": dataset_id, "pk1": org_id},
        host=config.hosts.PUBLISH_HOST,
    )
```

import logging

from django_hosts import reverse

import config.hosts
from transit_odp.avl.models import CAVLValidationTaskResult

logger = logging.getLogger(__name__)


def get_validation_task_result_from_revision_id(revision_id):
    try:
        task = CAVLValidationTaskResult.objects.filter(revision_id=revision_id).latest(
            "created"
        )
    except CAVLValidationTaskResult.DoesNotExist:
        logger.warning(
            f"Could not find CAVLValidationTaskResult for revision: {revision_id}",
            exc_info=True,
        )
        return None

    return task


def get_avl_success_url(dataset_id, org_id):
    return reverse(
        "avl:revision-publish-success",
        kwargs={"pk": dataset_id, "pk1": org_id},
        host=config.hosts.PUBLISH_HOST,
    )


def get_avl_failure_url(dataset_id, org_id):
    return reverse(
        "avl:revision-publish-error",
        kwargs={"pk": dataset_id, "pk1": org_id},
        host=config.hosts.PUBLISH_HOST,
    )
