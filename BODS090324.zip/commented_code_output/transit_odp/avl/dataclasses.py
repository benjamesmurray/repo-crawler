```python
from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from transit_odp.avl.enums import AVLFeedStatus, ValidationTaskResultStatus


class ValidationTaskResult(BaseModel):
    """
    A model representing the result of a validation task for an AVL feed.

    Attributes:
        url (str): The URL of the AVL feed.
        username (str): The username for accessing the AVL feed.
        password (Optional[str]): The password for accessing the AVL feed, if required.
        status (ValidationTaskResultStatus): The status of the validation task.
        created (datetime): The timestamp when the validation task was created.
        version (Optional[str]): The version of the AVL feed, if applicable.
    """
    url: str
    username: str
    password: Optional[str] = None
    status: ValidationTaskResultStatus = ValidationTaskResultStatus.DEPLOYING.value
    created: datetime
    version: Optional[str] = None


class Feed(BaseModel):
    """
    A model representing an AVL feed.

    Attributes:
        id (int): The unique identifier of the feed.
        publisher_id (int): The identifier of the publisher of the feed.
        url (str): The URL of the AVL feed.
        username (str): The username for accessing the AVL feed.
        password (Optional[str]): The password for accessing the AVL feed, if required.
        status (AVLFeedStatus): The current status of the AVL feed.
        created (Optional[datetime]): The timestamp when the feed was created.
        modified (Optional[datetime]): The timestamp when the feed was last modified.
        model_config (ConfigDict): Configuration dictionary to populate model by name.
    """
    id: int
    publisher_id: int = Field(alias="publisherId")
    url: str
    username: str
    password: Optional[str] = None
    status: AVLFeedStatus = AVLFeedStatus.DEPLOYING.value
    created: Optional[datetime] = None
    modified: Optional[datetime] = None
    model_config = ConfigDict(populate_by_name=True)
```

from datetime import datetime
from typing import Optional

from pydantic import BaseModel, ConfigDict, Field

from transit_odp.avl.enums import AVLFeedStatus, ValidationTaskResultStatus


class ValidationTaskResult(BaseModel):
    url: str
    username: str
    password: Optional[str] = None
    status: ValidationTaskResultStatus = ValidationTaskResultStatus.DEPLOYING.value
    created: datetime
    version: Optional[str] = None


class Feed(BaseModel):
    id: int
    publisher_id: int = Field(alias="publisherId")
    url: str
    username: str
    password: Optional[str] = None
    status: AVLFeedStatus = AVLFeedStatus.DEPLOYING.value
    created: Optional[datetime] = None
    modified: Optional[datetime] = None
    model_config = ConfigDict(populate_by_name=True)
