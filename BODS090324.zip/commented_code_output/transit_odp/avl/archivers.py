```python
import io
import time
from logging import getLogger
from zipfile import ZIP_DEFLATED, ZipFile

import requests
from django.core.files import File
from django.utils import timezone
from requests import RequestException

from transit_odp.avl.models import CAVLDataArchive

logger = getLogger(__name__)


class ArchivingError(Exception):
    """Custom exception class for archiving errors."""
    pass


class ConsumerAPIArchiver:
    """
    Base class for archiving data fetched from a consumer API.

    Attributes:
        data_format: The format of the data being archived.
        extension: The file extension for the archive.
        url: The URL to fetch data from.

    Methods:
        archive: Archives the fetched content into a zip file and saves it to the database.
        get_file: Compresses the content into a zip file.
        get_object: Retrieves or initializes a CAVLDataArchive object.
        save_to_database: Saves the zip file to the database.
    """
    data_format = CAVLDataArchive.SIRIVM
    extension = ".xml"

    def __init__(self, url):
        """Initializes the archiver with a URL and retrieves the archive object."""
        self.url = url
        self._archive = self.get_object()
        self._access_time = None
        self._content = None

    @property
    def filename(self):
        """Generates a filename for the zip archive based on the current time."""
        now = self.access_time.strftime("%Y-%m-%d_%H%M%S")
        return self.data_format_value + "_" + now + ".zip"

    @property
    def data_format_value(self):
        """Returns a lowercase, space-free string representation of the data format."""
        return self._archive.get_data_format_display().lower().replace(" ", "")

    @property
    def access_time(self):
        """Returns the time the content was accessed, raising an error if not set."""
        if self._content is None:
            raise ValueError("`content` has not been fetched yet.")

        if self._access_time is None:
            raise ValueError("`access_time` has not been set.")

        return self._access_time

    @property
    def content(self):
        """Fetches the content from the URL if not already fetched."""
        if self._content is None:
            self._content = self._get_content()
        return self._content

    @property
    def content_filename(self):
        """Returns the filename for the content to be stored in the zip archive."""
        return self.data_format_value + self.extension

    def archive(self):
        """Fetches content, creates a zip file, and saves it to the database."""
        file_ = self.get_file(self.content)
        self.save_to_database(file_)

    def _get_content(self):
        """Fetches the content from the URL and records the access time."""
        try:
            response = requests.get(self.url)
        except RequestException:
            msg = f"Unable to retrieve data from {self.url}"
            logger.error(msg)
            raise ArchivingError(msg)
        else:
            self._access_time = timezone.now()
            logger.info(
                f"Total time elapsed to get response from {self.url} is {response.elapsed.total_seconds()} for job-task_create_gtfsrt_zipfile"
            )
            return response.content

    def get_file(self, content):
        """Compresses the content into a zip file and returns a BytesIO object."""
        start_get_file_op = time.time()
        bytesio = io.BytesIO()
        with ZipFile(bytesio, mode="w", compression=ZIP_DEFLATED) as zf:
            zf.writestr(self.content_filename, content)
        end_file_op = time.time()
        logger.info(
            f"File operation took {end_file_op-start_get_file_op:.2f} seconds for job-task_create_gtfsrt_zipfile"
        )
        return bytesio

    def get_object(self):
        """Retrieves the last CAVLDataArchive object or initializes one if none exist."""
        start_db_op = time.time()
        archive = CAVLDataArchive.objects.filter(data_format=self.data_format).last()
        if archive is None:
            archive = CAVLDataArchive(data_format=self.data_format)
        end_db_op = time.time()
        logger.info(
            f"File operation took {end_db_op-start_db_op:.2f} seconds for job-task_create_gtfsrt_zipfile"
        )
        return archive

    def save_to_database(self, bytesio):
        """Saves the zip file to the database."""
        start_s3_op = time.time()
        file_ = File(bytesio, name=self.filename)
        self._archive.data = file_
        self._archive.save()
        end_s3_op = time.time()
        logger.info(
            f"S3 archive operation took {end_s3_op-start_s3_op:.2f} seconds for job-task_create_gtfsrt_zipfile"
        )


class SiriVMArchiver(ConsumerAPIArchiver):
    """
    Archiver for SIRI VM data format.
    Inherits from ConsumerAPIArchiver and sets specific data format and file extension.
    """
    data_format = CAVLDataArchive.SIRIVM
    extension = ".xml"


class GTFSRTArchiver(ConsumerAPIArchiver):
    """
    Archiver for GTFS RT data format.
    Inherits from ConsumerAPIArchiver and sets specific data format and file extension.
    """
    data_format = CAVLDataArchive.GTFSRT
    extension = ".bin"
```

import io
import time
from logging import getLogger
from zipfile import ZIP_DEFLATED, ZipFile

import requests
from django.core.files import File
from django.utils import timezone
from requests import RequestException

from transit_odp.avl.models import CAVLDataArchive

logger = getLogger(__name__)


class ArchivingError(Exception):
    pass


class ConsumerAPIArchiver:
    data_format = CAVLDataArchive.SIRIVM
    extension = ".xml"

    def __init__(self, url):
        self.url = url
        self._archive = self.get_object()
        self._access_time = None
        self._content = None

    @property
    def filename(self):
        now = self.access_time.strftime("%Y-%m-%d_%H%M%S")
        return self.data_format_value + "_" + now + ".zip"

    @property
    def data_format_value(self):
        return self._archive.get_data_format_display().lower().replace(" ", "")

    @property
    def access_time(self):
        if self._content is None:
            raise ValueError("`content` has not been fetched yet.")

        if self._access_time is None:
            raise ValueError("`access_time` has not been set.")

        return self._access_time

    @property
    def content(self):
        if self._content is None:
            self._content = self._get_content()
        return self._content

    @property
    def content_filename(self):
        return self.data_format_value + self.extension

    def archive(self):
        file_ = self.get_file(self.content)
        self.save_to_database(file_)

    def _get_content(self):
        try:
            response = requests.get(self.url)
        except RequestException:
            msg = f"Unable to retrieve data from {self.url}"
            logger.error(msg)
            raise ArchivingError(msg)
        else:
            self._access_time = timezone.now()
            logger.info(
                f"Total time elapsed to get response from {self.url} is {response.elapsed.total_seconds()} for job-task_create_gtfsrt_zipfile"
            )
            return response.content

    def get_file(self, content):
        start_get_file_op = time.time()
        bytesio = io.BytesIO()
        with ZipFile(bytesio, mode="w", compression=ZIP_DEFLATED) as zf:
            zf.writestr(self.content_filename, content)
        end_file_op = time.time()
        logger.info(
            f"File operation took {end_file_op-start_get_file_op:.2f} seconds for job-task_create_gtfsrt_zipfile"
        )
        return bytesio

    def get_object(self):
        start_db_op = time.time()
        archive = CAVLDataArchive.objects.filter(data_format=self.data_format).last()
        if archive is None:
            archive = CAVLDataArchive(data_format=self.data_format)
        end_db_op = time.time()
        logger.info(
            f"File operation took {end_db_op-start_db_op:.2f} seconds for job-task_create_gtfsrt_zipfile"
        )
        return archive

    def save_to_database(self, bytesio):
        start_s3_op = time.time()
        file_ = File(bytesio, name=self.filename)
        self._archive.data = file_
        self._archive.save()
        end_s3_op = time.time()
        logger.info(
            f"S3 archive operation took {end_s3_op-start_s3_op:.2f} seconds for job-task_create_gtfsrt_zipfile"
        )


class SiriVMArchiver(ConsumerAPIArchiver):
    data_format = CAVLDataArchive.SIRIVM
    extension = ".xml"


class GTFSRTArchiver(ConsumerAPIArchiver):
    data_format = CAVLDataArchive.GTFSRT
    extension = ".bin"
