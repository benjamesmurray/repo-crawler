```python
import logging
import csv
from io import StringIO

from transit_odp.pipelines.exceptions import PipelineException
from transit_odp.pipelines.models import DatasetETLTaskResult
from transit_odp.common.utils.s3_bucket_connection import get_s3_bucket_storage

logger = logging.getLogger(__name__)

def get_etl_task_or_pipeline_exception(pk) -> DatasetETLTaskResult:
    """
    Retrieve a DatasetETLTaskResult object based on its primary key (pk).
    
    If the object does not exist, a PipelineException is raised.
    
    Parameters:
    - pk: The primary key of the DatasetETLTaskResult to retrieve.
    
    Returns:
    - A DatasetETLTaskResult object.
    
    Raises:
    - PipelineException: If the DatasetETLTaskResult with the given pk does not exist.
    """
    try:
        task = DatasetETLTaskResult.objects.get(pk=pk)
    except DatasetETLTaskResult.DoesNotExist as exc:
        message = f"DatasetETLTaskResult {pk} does not exist."
        logger.exception(message, exc_info=True)
        raise PipelineException(message) from exc
    else:
        return task

def read_fares_validator_rerun_datasets_file_from_s3():
    """
    Reads a CSV file from an S3 bucket containing dataset IDs to be rerun by the fares validator.
    
    The function will log a warning if the file does not exist or is empty, and will
    log an info message with the count of read dataset IDs if successful.
    
    Returns:
    - A list of dataset IDs (integers) extracted from the CSV file.
    
    Raises:
    - Exception: If there is any error reading the file from S3.
    """
    try:
        storage = get_s3_bucket_storage()
        file_name = "rerun_fares_validator.csv"

        if not storage.exists(file_name):
            logger.warning(f"{file_name} does not exist in the S3 bucket.")
            return []

        file = storage._open(file_name)
        content = file.read().decode()
        file.close()

        # Remove BOM character if present
        if content.startswith("\ufeff"):
            content = content.lstrip("\ufeff")

        csv_file = StringIO(content)
        reader = csv.DictReader(csv_file)
        dataset_ids = [
            int(row["Dataset ID"]) for row in reader if row["Dataset ID"].strip()
        ]

        if dataset_ids:
            logger.info(
                f"Successfully read {len(dataset_ids)} dataset IDs from {file_name} in S3."
            )
        else:
            logger.warning(
                f"{file_name} in S3 is empty or does not contain valid dataset IDs."
            )

        return dataset_ids
    except Exception as e:
        logger.error(f"Error reading {file_name} from S3: {str(e)}")
        raise
```

import logging
import csv
from io import StringIO

from transit_odp.pipelines.exceptions import PipelineException
from transit_odp.pipelines.models import DatasetETLTaskResult
from transit_odp.common.utils.s3_bucket_connection import get_s3_bucket_storage


logger = logging.getLogger(__name__)


def get_etl_task_or_pipeline_exception(pk) -> DatasetETLTaskResult:
    try:
        task = DatasetETLTaskResult.objects.get(pk=pk)
    except DatasetETLTaskResult.DoesNotExist as exc:
        message = f"DatasetETLTaskResult {pk} does not exist."
        logger.exception(message, exc_info=True)
        raise PipelineException(message) from exc
    else:
        return task


def read_fares_validator_rerun_datasets_file_from_s3():
    try:
        storage = get_s3_bucket_storage()
        file_name = "rerun_fares_validator.csv"

        if not storage.exists(file_name):
            logger.warning(f"{file_name} does not exist in the S3 bucket.")
            return []

        file = storage._open(file_name)
        content = file.read().decode()
        file.close()

        # Remove BOM character if present
        if content.startswith("\ufeff"):
            content = content.lstrip("\ufeff")

        csv_file = StringIO(content)
        reader = csv.DictReader(csv_file)
        dataset_ids = [
            int(row["Dataset ID"]) for row in reader if row["Dataset ID"].strip()
        ]

        if dataset_ids:
            logger.info(
                f"Successfully read {len(dataset_ids)} dataset IDs from {file_name} in S3."
            )
        else:
            logger.warning(
                f"{file_name} in S3 is empty or does not contain valid dataset IDs."
            )

        return dataset_ids
    except Exception as e:
        logger.error(f"Error reading {file_name} from S3: {str(e)}")
        raise
