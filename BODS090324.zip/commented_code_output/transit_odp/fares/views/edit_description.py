```python
import config.hosts
from django_hosts import reverse

from transit_odp.fares.forms import EditFeedDescriptionForm
from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.views.base import EditDescriptionBaseView

class EditLiveRevisionDescriptionView(EditDescriptionBaseView):
    """
    A view for editing the description of a live dataset revision.
    
    Attributes:
        template_name (str): The path to the template to use for rendering the view.
        form_class (EditFeedDescriptionForm): The form class to use for editing the description.
        dataset_type (int): The type of dataset being edited, e.g., fares data.
    """
    template_name = "fares/feed_description_edit.html"
    form_class = EditFeedDescriptionForm
    dataset_type = DatasetType.FARES.value

    def get_object(self, queryset=None):
        """
        Retrieves the live revision of the dataset.
        
        Parameters:
            queryset (QuerySet, optional): A QuerySet to retrieve the object from.
                                           If None, the base queryset is used.
        
        Returns:
            The live revision of the dataset.
        """
        dataset = super().get_object()
        self.object = dataset.live_revision
        return self.object

    def get_context_data(self, **kwargs):
        """
        Returns the context data for rendering the template.
        
        Parameters:
            kwargs: Keyword arguments containing context data.
        
        Returns:
            A dictionary containing context data for the template.
        """
        context = super().get_context_data(**kwargs)
        context.update({"is_live": True})
        return context

    def get_dataset_url(self):
        """
        Constructs the URL for the dataset detail view.
        
        Returns:
            A string representing the URL to the dataset's detail view.
        """
        self.object = self.get_object()
        org_id = self.kwargs.get("pk1", None)
        return reverse(
            "fares:feed-detail",
            kwargs={"pk": self.object.dataset_id, "pk1": org_id},
            host=config.hosts.PUBLISH_HOST,
        )

class EditDraftRevisionDescriptionView(EditDescriptionBaseView):
    """
    A view for editing the description of a draft dataset revision.
    
    Attributes:
        template_name (str): The path to the template to use for rendering the view.
        form_class (EditFeedDescriptionForm): The form class to use for editing the description.
        dataset_type (int): The type of dataset being edited, e.g., fares data.
    """
    template_name = "fares/feed_description_edit.html"
    form_class = EditFeedDescriptionForm
    dataset_type = DatasetType.FARES.value

    def get_object(self, queryset=None):
        """
        Retrieves the latest draft revision of the dataset.
        
        Parameters:
            queryset (QuerySet, optional): A QuerySet to retrieve the object from.
                                           If None, the base queryset is used.
        
        Returns:
            The latest draft revision of the dataset.
        """
        dataset = super().get_object()
        self.object = dataset.revisions.latest("id")
        return self.object

    def get_context_data(self, **kwargs):
        """
        Returns the context data for rendering the template.
        
        Parameters:
            kwargs: Keyword arguments containing context data.
        
        Returns:
            A dictionary containing context data for the template.
        """
        context = super().get_context_data(**kwargs)
        is_revision_update = False
        if self.object.dataset.live_revision is not None:
            is_revision_update = True
        context.update({"is_revision_update": is_revision_update})
        return context

    def get_dataset_url(self):
        """
        Constructs the URL for the dataset review or update view depending on the state of the dataset.
        
        Returns:
            A string representing the URL to the appropriate view for the dataset's state.
        """
        self.object = self.get_object()
        org_id = self.kwargs.get("pk1", None)
        dataset = self.object.dataset

        if dataset.live_revision is None:
            # go to publish review page
            return reverse(
                "fares:revision-publish",
                kwargs={"pk": self.object.dataset_id, "pk1": org_id},
                host=config.hosts.PUBLISH_HOST,
            )
        else:
            # go to update review page
            return reverse(
                "fares:revision-update-publish",
                kwargs={"pk": self.object.dataset_id, "pk1": org_id},
                host=config.hosts.PUBLISH_HOST,
            )
```

import config.hosts
from django_hosts import reverse

from transit_odp.fares.forms import EditFeedDescriptionForm
from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.views.base import EditDescriptionBaseView


class EditLiveRevisionDescriptionView(EditDescriptionBaseView):
    template_name = "fares/feed_description_edit.html"
    form_class = EditFeedDescriptionForm
    dataset_type = DatasetType.FARES.value

    def get_object(self, queryset=None):
        dataset = super().get_object()
        self.object = dataset.live_revision
        return self.object

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        context.update({"is_live": True})
        return context

    def get_dataset_url(self):
        self.object = self.get_object()
        org_id = self.kwargs.get("pk1", None)
        return reverse(
            "fares:feed-detail",
            kwargs={"pk": self.object.dataset_id, "pk1": org_id},
            host=config.hosts.PUBLISH_HOST,
        )


class EditDraftRevisionDescriptionView(EditDescriptionBaseView):
    template_name = "fares/feed_description_edit.html"
    form_class = EditFeedDescriptionForm
    dataset_type = DatasetType.FARES.value

    def get_object(self, queryset=None):
        dataset = super().get_object()
        self.object = dataset.revisions.latest("id")
        return self.object

    def get_context_data(self, **kwargs):
        context = super().get_context_data(**kwargs)
        is_revision_update = False
        if self.object.dataset.live_revision is not None:
            is_revision_update = True
        context.update({"is_revision_update": is_revision_update})
        return context

    def get_dataset_url(self):
        self.object = self.get_object()
        org_id = self.kwargs.get("pk1", None)
        dataset = self.object.dataset

        if dataset.live_revision is None:
            # go to publish review page
            return reverse(
                "fares:revision-publish",
                kwargs={"pk": self.object.dataset_id, "pk1": org_id},
                host=config.hosts.PUBLISH_HOST,
            )
        else:
            # go to update review page
            return reverse(
                "fares:revision-update-publish",
                kwargs={"pk": self.object.dataset_id, "pk1": org_id},
                host=config.hosts.PUBLISH_HOST,
            )
