```python
from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.views.timetable.download import DatasetDownloadView

class DownloadFaresFileView(DatasetDownloadView):
    """
    View for downloading fare dataset files.
    
    This view inherits from DatasetDownloadView and sets the dataset_type to
    FARES, which is used to specify the type of dataset to be downloaded.
    """
    dataset_type = DatasetType.FARES.value
```

from transit_odp.organisation.constants import DatasetType
from transit_odp.publish.views.timetable.download import DatasetDownloadView


class DownloadFaresFileView(DatasetDownloadView):
    dataset_type = DatasetType.FARES.value
