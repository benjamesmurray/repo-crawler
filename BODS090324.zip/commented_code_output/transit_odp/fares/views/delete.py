```python
from django.views.generic.detail import DetailView
from django_hosts import reverse

from config.hosts import PUBLISH_HOST
from transit_odp.organisation.constants import EXPIRED, FaresType
from transit_odp.organisation.models import Dataset
from transit_odp.publish.views.base import DeleteRevisionBaseView
from transit_odp.users.views.mixins import OrgUserViewMixin


class RevisionDeleteFaresView(DeleteRevisionBaseView):
    """
    A view for deleting a fares revision.
    
    Attributes:
        template_name (str): The path to the template used for the delete confirmation page.
    
    Methods:
        get_queryset: Filters the queryset to revisions associated with the current organisation and fares datasets.
        get_success_url: Returns the URL to redirect to upon successful deletion.
        get_cancel_url: Returns the URL to redirect to if the deletion is cancelled.
    """
    template_name = "fares/feed_delete.html"

    def get_queryset(self):
        """
        Filters the queryset to include only fares datasets for the current organisation.

        Returns:
            QuerySet: A QuerySet of Dataset objects filtered by organisation and dataset type.
        """
        return (
            super()
            .get_queryset()
            .filter(organisation_id=self.organisation.id, dataset_type=FaresType)
        )

    def get_success_url(self):
        """
        Constructs the URL to redirect to after a successful deletion.

        Returns:
            str: URL to redirect to after deletion.
        """
        kwargs = {"pk1": self.kwargs["pk1"], "pk": self.kwargs["pk"]}
        return reverse(
            "fares:revision-delete-success",
            kwargs=kwargs,
            host=PUBLISH_HOST,
        )

    def get_cancel_url(self, feed_id: int):
        """
        Constructs the URL to redirect to if the user cancels the deletion.

        Args:
            feed_id (int): The ID of the feed for which deletion is being cancelled.

        Returns:
            str: URL to redirect to if deletion is cancelled.
        """
        kwargs = {"pk": feed_id, "pk1": self.kwargs["pk1"]}
        if self.object.live_revision is None:
            viewname = "fares:revision-publish"
        elif self.object.live_revision.status == EXPIRED:
            viewname = "fares:feed-detail"
        else:
            viewname = "fares:revision-update-publish"

        return reverse(viewname=viewname, kwargs=kwargs, host=PUBLISH_HOST)


class RevisionDeleteSuccessView(OrgUserViewMixin, DetailView):
    """
    A view that is displayed upon the successful deletion of a fares revision.
    
    Attributes:
        template_name (str): The path to the template used for the success message page.
        model (Model): The model associated with this view, which is Dataset.
    """
    template_name = "fares/feed_delete_success.html"
    model = Dataset
```

from django.views.generic.detail import DetailView
from django_hosts import reverse

from config.hosts import PUBLISH_HOST
from transit_odp.organisation.constants import EXPIRED, FaresType
from transit_odp.organisation.models import Dataset
from transit_odp.publish.views.base import DeleteRevisionBaseView
from transit_odp.users.views.mixins import OrgUserViewMixin


class RevisionDeleteFaresView(DeleteRevisionBaseView):
    template_name = "fares/feed_delete.html"

    def get_queryset(self):
        return (
            super()
            .get_queryset()
            .filter(organisation_id=self.organisation.id, dataset_type=FaresType)
        )

    def get_success_url(self):
        kwargs = {"pk1": self.kwargs["pk1"], "pk": self.kwargs["pk"]}
        return reverse(
            "fares:revision-delete-success",
            kwargs=kwargs,
            host=PUBLISH_HOST,
        )

    def get_cancel_url(self, feed_id: int):
        kwargs = {"pk": feed_id, "pk1": self.kwargs["pk1"]}
        if self.object.live_revision is None:
            viewname = "fares:revision-publish"
        elif self.object.live_revision.status == EXPIRED:
            viewname = "fares:feed-detail"
        else:
            viewname = "fares:revision-update-publish"

        return reverse(viewname=viewname, kwargs=kwargs, host=PUBLISH_HOST)


class RevisionDeleteSuccessView(OrgUserViewMixin, DetailView):
    template_name = "fares/feed_delete_success.html"
    model = Dataset
