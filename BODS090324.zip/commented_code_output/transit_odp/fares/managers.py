```python
from transit_odp.organisation.constants import FaresType
from transit_odp.organisation.managers import DatasetManager, DatasetRevisionManager

class FaresDatasetManager(DatasetManager):
    """
    Custom manager for FaresDataset that filters the queryset to return only fares datasets.
    Inherits from DatasetManager.
    """
    def get_queryset(self):
        """
        Overrides the parent method to return a queryset filtered by fares dataset type.
        
        Returns:
            QuerySet: A Django QuerySet filtered to include only fares datasets.
        """
        return super().get_queryset().filter(dataset_type=FaresType)


class FaresDatasetRevisionManager(DatasetRevisionManager):
    """
    Custom manager for FaresDatasetRevision that filters the queryset to return only revisions of fares datasets.
    Inherits from DatasetRevisionManager.
    """
    def get_queryset(self):
        """
        Overrides the parent method to return a queryset filtered to include only dataset revisions for fares datasets.
        
        Returns:
            QuerySet: A Django QuerySet filtered to include only dataset revisions for fares datasets.
        """
        return super().get_queryset().filter(dataset__dataset_type=FaresType)
```

from transit_odp.organisation.constants import FaresType
from transit_odp.organisation.managers import DatasetManager, DatasetRevisionManager


class FaresDatasetManager(DatasetManager):
    def get_queryset(self):
        return super().get_queryset().filter(dataset_type=FaresType)


class FaresDatasetRevisionManager(DatasetRevisionManager):
    def get_queryset(self):
        return super().get_queryset().filter(dataset__dataset_type=FaresType)
