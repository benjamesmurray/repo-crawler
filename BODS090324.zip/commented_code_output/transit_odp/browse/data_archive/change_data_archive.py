```python
import os
from datetime import datetime, timedelta

from celery.utils.log import get_task_logger
from django.core.files import File
from django.db.models.functions import TruncDate
from django.utils import timezone

from transit_odp.browse.data_archive.bulk_data_archive import get_datasets, zip_datasets
from transit_odp.organisation.constants import DatasetType
from transit_odp.pipelines.models import ChangeDataArchive

logger = get_task_logger(__name__)


def get_outpath(date: datetime):
    """
    Generates a file path for the output zip file based on the given date.

    :param date: The date for which to generate the file path.
    :return: A string representing the file path for the output zip file.
    """
    datestr = date.strftime("%Y%m%d")
    return f"/tmp/bodds_updates_{datestr}.zip"


def get_datasets_published_at(date: datetime):
    """
    Retrieves datasets that were published on a given date.

    :param date: The date for which to retrieve published datasets.
    :return: A queryset of datasets that were published on the specified date.
    """
    # Get all active datasets (are published and not expired)
    datasets = get_datasets(dataset_type=DatasetType.TIMETABLE.value)

    # Filter datasets to those which were published yesterday. Note this task
    # is intended to be run at night and produce an archive of all the changes for
    # the day before.
    datasets = datasets.annotate(
        date_published_at=TruncDate("live_revision__published_at")
    ).filter(date_published_at=date)

    return datasets


def upload_change_data_archive(outpath, published_at):
    """
    Uploads the zip file to the ChangeDataArchive model and saves it to the MEDIA_ROOT.

    :param outpath: The file path of the zip file to be uploaded.
    :param published_at: The date associated with the archive.
    :return: The created ChangeDataArchive instance.
    """
    logger.info("[change_data_archive] creating ChangeDataArchive record")
    with open(outpath, "rb") as fin:
        archive = ChangeDataArchive.objects.create(
            data=File(fin, name=os.path.basename(outpath)), published_at=published_at
        )
    return archive


def run():
    """
    Main function to create a change data archive for datasets published the day before.

    This function checks if an archive for the previous day already exists, and if not,
    it creates a new archive containing all datasets published on that day.
    """
    logger.info("[change_data_archive] called")

    # Get date to build archive
    yesterday = timezone.now().date() - timedelta(days=1)

    if ChangeDataArchive.objects.filter(published_at=yesterday).count() > 0:
        logger.info(
            f"[change_data_archive] Archive already exists for {yesterday}. "
            "No new archive will be created."
        )
        return

    # Get active datasets
    datasets = get_datasets_published_at(yesterday)

    if len(datasets) == 0:
        logger.info(
            "[change_data_archive] found no datasets that were published "
            f"on {yesterday}. No archive will be created."
        )
        return

    # Get local path to create zip file
    output = get_outpath(yesterday)

    # Write copy each dataset's upload_file into the zip
    zip_datasets(datasets, output)

    # Create BulkDataArchive
    archive = upload_change_data_archive(output, yesterday)

    logger.info(f"[change_data_archive] created {archive}")
```

import os
from datetime import datetime, timedelta

from celery.utils.log import get_task_logger
from django.core.files import File
from django.db.models.functions import TruncDate
from django.utils import timezone

from transit_odp.browse.data_archive.bulk_data_archive import get_datasets, zip_datasets
from transit_odp.organisation.constants import DatasetType
from transit_odp.pipelines.models import ChangeDataArchive

logger = get_task_logger(__name__)


def get_outpath(date: datetime):
    datestr = date.strftime("%Y%m%d")
    return f"/tmp/bodds_updates_{datestr}.zip"


def get_datasets_published_at(date: datetime):
    # Get all active datasets (are published and not expired)
    datasets = get_datasets(dataset_type=DatasetType.TIMETABLE.value)

    # Filter datasets to those which were published yesterday. Note this task
    # is intended to be run at night and produce an archive of all the changes for
    # the day before.
    datasets = datasets.annotate(
        date_published_at=TruncDate("live_revision__published_at")
    ).filter(date_published_at=date)

    return datasets


def upload_change_data_archive(outpath, published_at):
    """Saves the zip file at `outpath` to the BulkDataArchive model and uploads the
    zip to the MEDIA_ROOT"""
    logger.info("[change_data_archive] creating ChangeDataArchive record")
    with open(outpath, "rb") as fin:
        archive = ChangeDataArchive.objects.create(
            data=File(fin, name=os.path.basename(outpath)), published_at=published_at
        )
    return archive


def run():
    logger.info("[change_data_archive] called")

    # Get date to build archive
    yesterday = timezone.now().date() - timedelta(days=1)

    if ChangeDataArchive.objects.filter(published_at=yesterday).count() > 0:
        logger.info(
            f"[change_data_archive] Archive already exists for {yesterday}. "
            "No new archive will be created."
        )
        return

    # Get active datasets
    datasets = get_datasets_published_at(yesterday)

    if len(datasets) == 0:
        logger.info(
            "[change_data_archive] found no datasets that were published "
            f"on {yesterday}. No archive will be created."
        )
        return

    # Get local path to create zip file
    output = get_outpath(yesterday)

    # Write copy each dataset's upload_file into the zip
    zip_datasets(datasets, output)

    # Create BulkDataArchive
    archive = upload_change_data_archive(output, yesterday)

    logger.info(f"[change_data_archive] created {archive}")
