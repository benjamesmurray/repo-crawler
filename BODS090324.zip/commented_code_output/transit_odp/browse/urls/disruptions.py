```python
from django.urls import include, path
from transit_odp.browse.views.disruptions_views import (
    DisruptionOrganisationDetailView,
    DisruptionsDataView,
    DownloadDisruptionsDataArchiveView,
    DownloadDisruptionsView,
    DisruptionDetailView,
)

# URL configuration for disruption-related views.
urlpatterns = [
    # Routes for downloading disruptions data.
    path(
        "download/",
        include(
            [
                # Endpoint for downloading individual disruptions.
                path(
                    "",
                    view=DownloadDisruptionsView.as_view(),
                    name="download-disruptions",
                ),
                # Endpoint for downloading a bulk archive of disruptions data.
                path(
                    "bulk_archive",
                    view=DownloadDisruptionsDataArchiveView.as_view(),
                    name="downloads-disruptions-bulk",
                ),
            ]
        ),
    ),
    # Routes for accessing disruptions data related to organisations.
    path(
        "organisations/",
        include(
            [
                # Endpoint for listing disruptions data.
                path(
                    "",
                    view=DisruptionsDataView.as_view(),
                    name="disruptions-data",
                ),
                # Nested routes for organisation-specific disruptions detail.
                path(
                    "<uuid:orgId>/",
                    include(
                        [
                            # Endpoint for viewing details of an organisation's disruptions.
                            path(
                                "",
                                view=DisruptionOrganisationDetailView.as_view(),
                                name="org-detail",
                            ),
                            # Endpoint for viewing details of a specific disruption by ID.
                            path(
                                "disruption-detail/<uuid:disruptionId>/",
                                view=DisruptionDetailView.as_view(),
                                name="disruption-detail",
                            ),
                        ]
                    ),
                ),
            ]
        ),
    ),
]
```

from django.urls import include, path
from transit_odp.browse.views.disruptions_views import (
    DisruptionOrganisationDetailView,
    DisruptionsDataView,
    DownloadDisruptionsDataArchiveView,
    DownloadDisruptionsView,
    DisruptionDetailView,
)

urlpatterns = [
    path(
        "download/",
        include(
            [
                path(
                    "",
                    view=DownloadDisruptionsView.as_view(),
                    name="download-disruptions",
                ),
                path(
                    "bulk_archive",
                    view=DownloadDisruptionsDataArchiveView.as_view(),
                    name="downloads-disruptions-bulk",
                ),
            ]
        ),
    ),
    path(
        "organisations/",
        include(
            [
                path(
                    "",
                    view=DisruptionsDataView.as_view(),
                    name="disruptions-data",
                ),
                path(
                    "<uuid:orgId>/",
                    include(
                        [
                            path(
                                "",
                                view=DisruptionOrganisationDetailView.as_view(),
                                name="org-detail",
                            ),
                            path(
                                "disruption-detail/<uuid:disruptionId>/",
                                view=DisruptionDetailView.as_view(),
                                name="disruption-detail",
                            ),
                        ]
                    ),
                ),
            ]
        ),
    ),
]
