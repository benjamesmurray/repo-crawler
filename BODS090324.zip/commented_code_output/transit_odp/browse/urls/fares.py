```python
from django.urls import include, path

from transit_odp.browse.views.fares_views import (
    DownloadFaresBulkDataArchiveView,
    DownloadFaresView,
    FaresChangeLogView,
    FaresDatasetDetailView,
    FaresDatasetDownloadView,
    FaresSearchView,
    FaresSubscriptionSuccessView,
    FaresSubscriptionView,
    FaresUserFeedbackSuccessView,
    FaresUserFeedbackView,
)

# URL patterns for the fares-related views within a Django application.
urlpatterns = [
    # URL pattern for searching fares.
    path(
        "",
        view=FaresSearchView.as_view(),
        name="search-fares",
    ),
    # URL pattern for downloading fares.
    path("download/", view=DownloadFaresView.as_view(), name="download-fares"),
    # URL pattern for downloading a bulk data archive of fares.
    path(
        "download/bulk_archive",
        view=DownloadFaresBulkDataArchiveView.as_view(),
        name="downloads-fares-bulk",
    ),
    # URL pattern for fares dataset details, including nested resources.
    path(
        "dataset/",
        include(
            [
                # URL pattern for a specific fares dataset, identified by its primary key.
                path(
                    "<int:pk>/",
                    include(
                        [
                            # URL pattern for viewing details of a specific fares dataset.
                            path(
                                "",
                                view=FaresDatasetDetailView.as_view(),
                                name="fares-feed-detail",
                            ),
                            # URL pattern for downloading a specific fares dataset.
                            path(
                                "download/",
                                view=FaresDatasetDownloadView.as_view(),
                                name="fares-feed-download",
                            ),
                            # URL pattern for viewing the changelog of a fares dataset.
                            path(
                                "changelog/",
                                view=FaresChangeLogView.as_view(),
                                name="fares-feed-changelog",
                            ),
                            # URL pattern for subscribing to updates for a fares dataset.
                            path(
                                "subscription/",
                                view=FaresSubscriptionView.as_view(),
                                name="fares-feed-subscription",
                            ),
                            # URL pattern for the subscription success page.
                            path(
                                "subscription/success/",
                                view=FaresSubscriptionSuccessView.as_view(),
                                name="fares-feed-subscription-success",
                            ),
                            # URL pattern for submitting feedback on a fares dataset.
                            path(
                                "feedback/",
                                view=FaresUserFeedbackView.as_view(),
                                name="fares-feed-feedback",
                            ),
                            # URL pattern for the feedback submission success page.
                            path(
                                "feedback/success",
                                view=FaresUserFeedbackSuccessView.as_view(),
                                name="fares-feed-feedback-success",
                            ),
                        ]
                    ),
                )
            ]
        ),
    ),
]
```

from django.urls import include, path

from transit_odp.browse.views.fares_views import (
    DownloadFaresBulkDataArchiveView,
    DownloadFaresView,
    FaresChangeLogView,
    FaresDatasetDetailView,
    FaresDatasetDownloadView,
    FaresSearchView,
    FaresSubscriptionSuccessView,
    FaresSubscriptionView,
    FaresUserFeedbackSuccessView,
    FaresUserFeedbackView,
)

urlpatterns = [
    path(
        "",
        view=FaresSearchView.as_view(),
        name="search-fares",
    ),
    path("download/", view=DownloadFaresView.as_view(), name="download-fares"),
    path(
        "download/bulk_archive",
        view=DownloadFaresBulkDataArchiveView.as_view(),
        name="downloads-fares-bulk",
    ),
    path(
        "dataset/",
        include(
            [
                path(
                    "<int:pk>/",
                    include(
                        [
                            path(
                                "",
                                view=FaresDatasetDetailView.as_view(),
                                name="fares-feed-detail",
                            ),
                            path(
                                "download/",
                                view=FaresDatasetDownloadView.as_view(),
                                name="fares-feed-download",
                            ),
                            path(
                                "changelog/",
                                view=FaresChangeLogView.as_view(),
                                name="fares-feed-changelog",
                            ),
                            path(
                                "subscription/",
                                view=FaresSubscriptionView.as_view(),
                                name="fares-feed-subscription",
                            ),
                            path(
                                "subscription/success/",
                                view=FaresSubscriptionSuccessView.as_view(),
                                name="fares-feed-subscription-success",
                            ),
                            path(
                                "feedback/",
                                view=FaresUserFeedbackView.as_view(),
                                name="fares-feed-feedback",
                            ),
                            path(
                                "feedback/success",
                                view=FaresUserFeedbackSuccessView.as_view(),
                                name="fares-feed-feedback-success",
                            ),
                        ]
                    ),
                )
            ]
        ),
    ),
]
