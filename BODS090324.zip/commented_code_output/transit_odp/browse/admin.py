```python
# Register your models here.

def register_model(admin_site, model_cls, admin_cls=None):
    """
    Registers a given model with a given admin site.
    
    :param admin_site: The admin site instance where the model will be registered
    :param model_cls: The model class that is to be registered
    :param admin_cls: (Optional) The admin class that customizes the model's admin interface
    """
    if admin_cls is None:
        admin_site.register(model_cls)
    else:
        admin_site.register(model_cls, admin_cls)
```

# Register your models here.
