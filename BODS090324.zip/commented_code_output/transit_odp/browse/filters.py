```python
import django_filters as filters
from django.db.models import Q

from transit_odp.browse.forms import (
    AVLSearchFilterForm,
    FaresSearchFilterForm,
    TimetableSearchFilterForm,
)
from transit_odp.naptan.models import AdminArea
from transit_odp.organisation.constants import SEARCH_STATUS_CHOICES, FeedStatus
from transit_odp.organisation.models import DatasetRevision, Organisation

class TimetableSearchFilter(filters.FilterSet):
    """
    A FilterSet for searching Timetable datasets based on various criteria.
    
    Attributes:
        area (ModelChoiceFilter): Filter by administrative area.
        organisation (ModelChoiceFilter): Filter by organisation, excluding inactive ones.
        status (ChoiceFilter): Filter by the status of the dataset.
        start (DateTimeFilter): Filter by the earliest start date of service.
        published_at (DateTimeFilter): Filter by the earliest publication date.
        is_pti_compliant (BooleanFilter): Filter by PTI compliance status.
    """
    area = filters.ModelChoiceFilter(
        field_name="admin_areas",
        queryset=AdminArea.objects.all(),
        method="admin_areas_filter",
    )
    organisation = filters.ModelChoiceFilter(
        queryset=Organisation.objects.exclude(is_active=False)
    )

    status = filters.ChoiceFilter(choices=SEARCH_STATUS_CHOICES)
    start = filters.DateTimeFilter(field_name="first_service_start", lookup_expr="gte")
    published_at = filters.DateTimeFilter(field_name="published_at", lookup_expr="gte")

    is_pti_compliant = filters.BooleanFilter()

    class Meta:
        form = TimetableSearchFilterForm

    def get_form_class(self):
        """
        Returns the form class associated with this FilterSet to workaround a bug.
        
        Returns:
            Form class associated with this FilterSet.
        """
        return self._meta.form

    def admin_areas_filter(self, queryset, name, value):
        """
        Custom filter method to filter datasets by annotated admin area names.
        
        Parameters:
            queryset: The initial queryset.
            name: The name of the filter field.
            value: The selected admin area to filter by.
        
        Returns:
            A queryset filtered by the selected admin area.
        """
        if value:
            value = value.name
            queryset = queryset.filter(Q(admin_area_names__contains=value))
        return queryset


class AVLSearchFilter(filters.FilterSet):
    """
    A FilterSet for searching AVL datasets based on various criteria.
    
    Attributes:
        organisation (ModelChoiceFilter): Filter by organisation, excluding inactive ones.
        status (ChoiceFilter): Filter by the status of the dataset, with custom choices.
    """
    organisation = filters.ModelChoiceFilter(
        queryset=Organisation.objects.exclude(is_active=False)
    )

    status = filters.ChoiceFilter(
        choices=(
            ("", "All statuses"),
            (FeedStatus.live.value, "Published"),
            (FeedStatus.inactive.value, "Inactive"),
        ),
    )

    class Meta:
        form = AVLSearchFilterForm

    def get_form_class(self):
        """
        Returns the form class associated with this FilterSet to workaround a bug.
        
        Returns:
            Form class associated with this FilterSet.
        """
        return self._meta.form


class FaresSearchFilter(filters.FilterSet):
    """
    A FilterSet for searching Fares datasets based on various criteria.
    
    Attributes:
        area (ModelChoiceFilter): Filter by administrative area.
        organisation (ModelChoiceFilter): Filter by organisation, excluding inactive ones.
        status (ChoiceFilter): Filter by the status of the dataset.
        is_fares_compliant (BooleanFilter): Filter by fares compliance status.
    """
    area = filters.ModelChoiceFilter(
        field_name="admin_areas",
        queryset=AdminArea.objects.all(),
        method="admin_areas_filter",
    )
    organisation = filters.ModelChoiceFilter(
        queryset=Organisation.objects.exclude(is_active=False)
    )

    status = filters.ChoiceFilter(choices=DatasetRevision.STATUS_CHOICES)

    is_fares_compliant = filters.BooleanFilter()

    class Meta:
        form = FaresSearchFilterForm

    def get_form_class(self):
        """
        Returns the form class associated with this FilterSet to workaround a bug.
        
        Returns:
            Form class associated with this FilterSet.
        """
        return self._meta.form

    def admin_areas_filter(self, queryset, name, value):
        """
        Custom filter method to filter fares datasets by admin area name.
        
        Parameters:
            queryset: The initial queryset.
            name: The name of the filter field.
            value: The selected admin area to filter by.
        
        Returns:
            A queryset filtered by the selected admin area.
        """
        if value:
            value = value.name
            queryset = queryset.filter(
                live_revision__metadata__faresmetadata__stops__admin_area__name=value
            ).distinct()
        return queryset
```

import django_filters as filters
from django.db.models import Q

from transit_odp.browse.forms import (
    AVLSearchFilterForm,
    FaresSearchFilterForm,
    TimetableSearchFilterForm,
)
from transit_odp.naptan.models import AdminArea
from transit_odp.organisation.constants import SEARCH_STATUS_CHOICES, FeedStatus
from transit_odp.organisation.models import DatasetRevision, Organisation


class TimetableSearchFilter(filters.FilterSet):
    area = filters.ModelChoiceFilter(
        field_name="admin_areas",
        queryset=AdminArea.objects.all(),
        method="admin_areas_filter",
    )
    organisation = filters.ModelChoiceFilter(
        queryset=Organisation.objects.exclude(is_active=False)
    )

    status = filters.ChoiceFilter(choices=SEARCH_STATUS_CHOICES)
    start = filters.DateTimeFilter(field_name="first_service_start", lookup_expr="gte")
    published_at = filters.DateTimeFilter(field_name="published_at", lookup_expr="gte")

    is_pti_compliant = filters.BooleanFilter()

    class Meta:
        form = TimetableSearchFilterForm

    def get_form_class(self):
        # bug in base class expects to find form at self._form but it is unset
        return self._meta.form

    def admin_areas_filter(self, queryset, name, value):
        # admin_area_names have been annotated onto the dataset

        if value:
            value = value.name
            queryset = queryset.filter(Q(admin_area_names__contains=value))
        return queryset


class AVLSearchFilter(filters.FilterSet):
    organisation = filters.ModelChoiceFilter(
        queryset=Organisation.objects.exclude(is_active=False)
    )

    status = filters.ChoiceFilter(
        choices=(
            ("", "All statuses"),
            (FeedStatus.live.value, "Published"),
            (FeedStatus.inactive.value, "Inactive"),
        ),
    )

    class Meta:
        form = AVLSearchFilterForm

    def get_form_class(self):
        # bug in base class expects to find form at self._form but it is unset
        return self._meta.form


class FaresSearchFilter(filters.FilterSet):
    area = filters.ModelChoiceFilter(
        field_name="admin_areas",
        queryset=AdminArea.objects.all(),
        method="admin_areas_filter",
    )
    organisation = filters.ModelChoiceFilter(
        queryset=Organisation.objects.exclude(is_active=False)
    )

    status = filters.ChoiceFilter(choices=DatasetRevision.STATUS_CHOICES)

    is_fares_compliant = filters.BooleanFilter()

    class Meta:
        form = FaresSearchFilterForm

    def get_form_class(self):
        # bug in base class expects to find form at self._form but it is unset
        return self._meta.form

    def admin_areas_filter(self, queryset, name, value):
        # admin_area_names have been annotated onto the dataset

        if value:
            value = value.name
            queryset = queryset.filter(
                live_revision__metadata__faresmetadata__stops__admin_area__name=value
            ).distinct()
        return queryset
