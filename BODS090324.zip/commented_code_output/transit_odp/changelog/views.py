```python
from django.views.generic import ListView

from transit_odp.changelog.constants import ConsumerIssue, PublisherIssue
from transit_odp.changelog.models import HighLevelRoadMap, KnownIssues


class ChangelogView(ListView):
    """
    View for displaying the changelog of known issues and the high-level roadmap.

    Attributes:
        model: The model that this view will display.
        template_name: The path to the template this view will use.
    """
    model = KnownIssues
    template_name = "changelog/changelog.html"

    def get_queryset(self):
        """
        Get the queryset for the view, ordering it by the 'modified' field in descending order.

        Returns:
            A queryset of KnownIssues objects ordered by the 'modified' field in descending order.
        """
        return super().get_queryset().order_by("-modified")

    def get_context_data(self, **kwargs):
        """
        Build the context for the template to render the changelog page.

        It includes the known issues grouped by category, the last updated time, and the high-level roadmap.

        Parameters:
            **kwargs: Keyword arguments from the parent class's method.

        Returns:
            A dictionary representing the context with known issues, last updated time, and roadmap.
        """
        # Retrieve the first roadmap object or None if it doesn't exist
        roadmap = HighLevelRoadMap.objects.first()

        # Prepare to group issues by their category
        grouped_issues = {PublisherIssue: [], ConsumerIssue: []}
        for issue in self.object_list:
            # This will avoid doing two separate queries
            if not issue.deleted:
                grouped_issues[issue.category].append(issue)

        # Get the first issue in the list or None if the list is empty
        last_modified_issue = self.object_list.first()

        # Determine the last modified time
        if not last_modified_issue:
            last_modified_time = roadmap.modified
        else:
            last_modified_time = max([last_modified_issue.modified, roadmap.modified])

        # Get the default context data from the parent class
        context = super().get_context_data(**kwargs)
        # Update the context with the changelog specific data
        context.update(
            {
                "known_issues": grouped_issues,
                "last_updated": last_modified_time,
                "roadmap": roadmap,
            }
        )
        return context
```

from django.views.generic import ListView

from transit_odp.changelog.constants import ConsumerIssue, PublisherIssue
from transit_odp.changelog.models import HighLevelRoadMap, KnownIssues


class ChangelogView(ListView):
    model = KnownIssues
    template_name = "changelog/changelog.html"

    def get_queryset(self):
        return super().get_queryset().order_by("-modified")

    def get_context_data(self, **kwargs):
        roadmap = HighLevelRoadMap.objects.first()

        grouped_issues = {PublisherIssue: [], ConsumerIssue: []}
        for issue in self.object_list:
            # This will avoid doing two separate queries
            if not issue.deleted:
                grouped_issues[issue.category].append(issue)

        last_modified_issue = self.object_list.first()

        if not last_modified_issue:
            last_modified_time = roadmap.modified
        else:
            last_modified_time = max([last_modified_issue.modified, roadmap.modified])

        context = super().get_context_data(**kwargs)
        context.update(
            {
                "known_issues": grouped_issues,
                "last_updated": last_modified_time,
                "roadmap": roadmap,
            }
        )
        return context
