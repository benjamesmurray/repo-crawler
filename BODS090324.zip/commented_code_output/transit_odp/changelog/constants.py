```python
from django.db.models import TextChoices
from django.utils.translation import gettext_lazy as _

class KnownIssueStatus(TextChoices):
    """
    This class defines status choices for known issues using Django's TextChoices.
    
    Attributes:
        PENDING (str): A choice representing a pending issue.
        FIXED (str): A choice representing a fixed issue.
    """
    PENDING = ("pending", _("Pending"))
    FIXED = ("fixed", _("Fixed"))

class KnownIssueCategory(TextChoices):
    """
    This class defines category choices for known issues using Django's TextChoices.
    
    Attributes:
        CONSUMER (str): A choice representing an issue related to consumers.
        PUBLISHER (str): A choice representing an issue related to publishers.
    """
    CONSUMER = ("consumer", _("Consumer"))
    PUBLISHER = ("publisher", _("Publisher"))

# Constants for easy access to the KnownIssueStatus values
PendingStatus = KnownIssueStatus.PENDING.value
FixedStatus = KnownIssueStatus.FIXED.value

# Constants for easy access to the KnownIssueCategory values
ConsumerIssue = KnownIssueCategory.CONSUMER.value
PublisherIssue = KnownIssueCategory.PUBLISHER.value
```

from django.db.models import TextChoices
from django.utils.translation import gettext_lazy as _


class KnownIssueStatus(TextChoices):
    PENDING = ("pending", _("Pending"))
    FIXED = ("fixed", _("Fixed"))


class KnownIssueCategory(TextChoices):
    CONSUMER = ("consumer", _("Consumer"))
    PUBLISHER = ("publisher", _("Publisher"))


PendingStatus = KnownIssueStatus.PENDING.value
FixedStatus = KnownIssueStatus.FIXED.value

ConsumerIssue = KnownIssueCategory.CONSUMER.value
PublisherIssue = KnownIssueCategory.PUBLISHER.value
