```python
from transit_odp.changelog.constants import ConsumerIssue, PublisherIssue
from transit_odp.changelog.managers import (
    ConsumerKnownIssueManager,
    PublisherKnownIssueManager,
)
from transit_odp.changelog.models import KnownIssues


class ConsumerKnownIssues(KnownIssues):
    """
    A proxy model for KnownIssues specific to consumer-related issues.
    
    Attributes:
        objects (ConsumerKnownIssueManager): The manager that handles consumer known issues.
    """

    class Meta:
        proxy = True
        verbose_name = "Consumer Known Issues"
        verbose_name_plural = "Consumer Known Issues"

    objects = ConsumerKnownIssueManager()

    def __init__(self, *args, **kwargs):
        """
        Initializes a ConsumerKnownIssues instance, setting the category to ConsumerIssue.
        
        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        super().__init__(*args, category=ConsumerIssue, **kwargs)


class PublisherKnownIssues(KnownIssues):
    """
    A proxy model for KnownIssues specific to publisher-related issues.
    
    Attributes:
        objects (PublisherKnownIssueManager): The manager that handles publisher known issues.
    """

    class Meta:
        proxy = True
        verbose_name = "Publisher Known Issues"
        verbose_name_plural = "Publisher Known Issues"

    objects = PublisherKnownIssueManager()

    def __init__(self, *args, **kwargs):
        """
        Initializes a PublisherKnownIssues instance, setting the category to PublisherIssue.
        
        Args:
            *args: Variable length argument list.
            **kwargs: Arbitrary keyword arguments.
        """
        super().__init__(*args, category=PublisherIssue, **kwargs)
```

from transit_odp.changelog.constants import ConsumerIssue, PublisherIssue
from transit_odp.changelog.managers import (
    ConsumerKnownIssueManager,
    PublisherKnownIssueManager,
)
from transit_odp.changelog.models import KnownIssues


class ConsumerKnownIssues(KnownIssues):
    class Meta:
        proxy = True
        verbose_name = "Consumer Known Issues"
        verbose_name_plural = "Consumer Known Issues"

    objects = ConsumerKnownIssueManager()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, category=ConsumerIssue, **kwargs)


class PublisherKnownIssues(KnownIssues):
    class Meta:
        proxy = True
        verbose_name = "Publisher Known Issues"
        verbose_name_plural = "Publisher Known Issues"

    objects = PublisherKnownIssueManager()

    def __init__(self, *args, **kwargs):
        super().__init__(*args, category=PublisherIssue, **kwargs)
