```python
from django.apps import AppConfig

class ChangelogConfig(AppConfig):
    """
    Configuration class for the 'changelog' app within the Django project.
    
    Attributes:
        name (str): The full Python path to the application.
        verbose_name (str): The human-readable name for the application.
    """
    name = "transit_odp.changelog"
    verbose_name = "Changelog"
```

from django.apps import AppConfig


class ChangelogConfig(AppConfig):
    name = "transit_odp.changelog"
    verbose_name = "Changelog"
