```python
import factory

from transit_odp.changelog.constants import ConsumerIssue, PendingStatus
from transit_odp.changelog.models import KnownIssues
from factory.django import DjangoModelFactory


class KnownIssueFactory(DjangoModelFactory):
    """
    Factory class for creating KnownIssues instances for testing purposes.

    This class is a subclass of DjangoModelFactory and is meant to be used
    when a test requires a KnownIssues object without having to manually
    create one in the test database.

    Attributes:
        deleted (bool): A flag indicating whether the issue is considered deleted.
        status (str): The status of the known issue, typically a pending status.
        category (str): The category of the known issue, usually a consumer issue.
        description (str): A fake paragraph generated to describe the known issue.

    The Meta class within defines the model that this factory is associated with.
    """

    class Meta:
        model = KnownIssues

    deleted = False
    status = PendingStatus
    category = ConsumerIssue
    description = factory.Faker("paragraph")
```

import factory

from transit_odp.changelog.constants import ConsumerIssue, PendingStatus
from transit_odp.changelog.models import KnownIssues
from factory.django import DjangoModelFactory


class KnownIssueFactory(DjangoModelFactory):
    class Meta:
        model = KnownIssues

    deleted = False
    status = PendingStatus
    category = ConsumerIssue
    description = factory.Faker("paragraph")
