```python
from django.db import models

from transit_odp.changelog.constants import ConsumerIssue, PublisherIssue

class ConsumerKnownIssueManager(models.Manager):
    """
    Custom manager for handling known issues related to consumers.
    It filters and creates issue records specifically categorized under ConsumerIssue.
    """
    
    def get_queryset(self):
        """Overrides the default queryset to return issues filtered by the ConsumerIssue category."""
        return super().get_queryset().filter(category=ConsumerIssue)

    def create(self, **kwargs):
        """
        Overrides the default create method to automatically set the category to ConsumerIssue
        when creating a new issue record.

        :param kwargs: Arbitrary keyword arguments passed to create a new issue record.
        :return: The newly created ConsumerIssue instance.
        """
        kwargs.update({"category": ConsumerIssue})
        return super().create(**kwargs)


class PublisherKnownIssueManager(models.Manager):
    """
    Custom manager for handling known issues related to publishers.
    It filters and creates issue records specifically categorized under PublisherIssue.
    """
    
    def get_queryset(self):
        """Overrides the default queryset to return issues filtered by the PublisherIssue category."""
        return super().get_queryset().filter(category=PublisherIssue)

    def create(self, **kwargs):
        """
        Overrides the default create method to automatically set the category to PublisherIssue
        when creating a new issue record.

        :param kwargs: Arbitrary keyword arguments passed to create a new issue record.
        :return: The newly created PublisherIssue instance.
        """
        kwargs.update({"category": PublisherIssue})
        return super().create(**kwargs)
```

from django.db import models

from transit_odp.changelog.constants import ConsumerIssue, PublisherIssue


class ConsumerKnownIssueManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(category=ConsumerIssue)

    def create(self, **kwargs):
        kwargs.update({"category": ConsumerIssue})
        return super().create(**kwargs)


class PublisherKnownIssueManager(models.Manager):
    def get_queryset(self):
        return super().get_queryset().filter(category=PublisherIssue)

    def create(self, **kwargs):
        kwargs.update({"category": PublisherIssue})
        return super().create(**kwargs)
