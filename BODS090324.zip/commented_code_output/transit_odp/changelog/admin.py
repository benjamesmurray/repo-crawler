```python
from django.contrib import admin
from transit_odp.changelog.models import HighLevelRoadMap
from transit_odp.changelog.proxies import ConsumerKnownIssues, PublisherKnownIssues

class KnownIssueAdmin(admin.ModelAdmin):
    """
    Custom admin interface for known issues.

    This admin interface customizes the view in the Django admin panel for known issue models.
    It specifies the fields to be displayed in the list view, which fields can be linked to the
    edit page, which fields can be searched, and which filters are available. It also removes
    delete permissions for these objects.
    """
    list_display = ["status", "description", "modified", "created", "deleted"]
    list_display_links = ["description"]
    search_fields = ["description"]
    list_filter = ["status", "deleted"]
    exclude = ["category"]
    actions = None

    def has_delete_permission(self, request, obj=None):
        """
        Disable delete permission for known issues.

        Args:
            request: HttpRequest object representing the current request.
            obj: The object for which the permission is being checked (optional).

        Returns:
            False to indicate that delete permission is not granted.
        """
        return False

@admin.register(HighLevelRoadMap)
class HighLevelRoadMapAdmin(admin.ModelAdmin):
    """
    Custom admin interface for the HighLevelRoadMap model.

    This admin interface customizes the view in the Django admin panel for the HighLevelRoadMap
    model. It specifies the fields to be displayed in the list view and removes add and delete
    permissions for these objects.
    """
    list_display = ["description", "modified", "created"]
    actions = None

    def has_add_permission(self, request, obj=None):
        """
        Disable add permission for HighLevelRoadMap objects.

        Args:
            request: HttpRequest object representing the current request.
            obj: The object for which the permission is being checked (optional).

        Returns:
            False to indicate that add permission is not granted.
        """
        return False

    def has_delete_permission(self, request, obj=None):
        """
        Disable delete permission for HighLevelRoadMap objects.

        Args:
            request: HttpRequest object representing the current request.
            obj: The object for which the permission is being checked (optional).

        Returns:
            False to indicate that delete permission is not granted.
        """
        return False

# Register the KnownIssueAdmin with the ConsumerKnownIssues and PublisherKnownIssues models.
admin.site.register(ConsumerKnownIssues, KnownIssueAdmin)
admin.site.register(PublisherKnownIssues, KnownIssueAdmin)
```

from django.contrib import admin

from transit_odp.changelog.models import HighLevelRoadMap
from transit_odp.changelog.proxies import ConsumerKnownIssues, PublisherKnownIssues


class KnownIssueAdmin(admin.ModelAdmin):
    list_display = ["status", "description", "modified", "created", "deleted"]
    list_display_links = ["description"]
    search_fields = ["description"]
    list_filter = ["status", "deleted"]
    exclude = ["category"]
    actions = None

    def has_delete_permission(self, request, obj=None):
        return False


@admin.register(HighLevelRoadMap)
class HighLevelRoadMapAdmin(admin.ModelAdmin):
    list_display = ["description", "modified", "created"]
    actions = None

    def has_add_permission(self, request, obj=None):
        return False

    def has_delete_permission(self, request, obj=None):
        return False


admin.site.register(ConsumerKnownIssues, KnownIssueAdmin)
admin.site.register(PublisherKnownIssues, KnownIssueAdmin)
